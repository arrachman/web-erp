﻿Public Class JournalUlang

    Dim userid As String = ""   'User Id diisi dengan user yang melakukan proses transaksi
    Dim formatTglDB = "yyyy-MM-dd"
    Dim formatTglWaktuDB = "yyyy-MM-dd H:mm:ss"

    Public Function M0_JournalUlang(ByVal param As String) As String

        Dim paramSplit(6) As String     'WebsiteAccessKey(0), paket(1), paging(2), userid(3), isUpdate(4), data(5)
        Dim pagingSplit(6) As String    'pageNumber(0), itemLimit(1), strFilter(2), strSort(3), formatTgl(4), formatTglWaktu(5)
        Dim dataUtama() As String

        Dim result(5) As String         'target(0), success(1), errmessage(2), errstep(3), idtransaksi(4)
        Dim resultPaging(5) As String   'ispaging(0), isNext(1), isPrev(2), countPage(3), countRow(4)

        Dim wsResult As String = ""
        Dim strResult, strResultPaging, strResultData As String

        Dim isUpdate As Boolean, sql As String = "", stepKe As Double = 0
        Dim tglAwal As String = "", tglAkhir As String = "", sumber As String = ""
        Dim notransaksiAwal As String = "", notransaksiAkhir As String = ""
        Dim tidakAdaJurnal As Boolean = False, jurnalHpp As Boolean = False, hitungUlang As Boolean = False

        'SET DEFAULT RESULT
        result(0) = System.Reflection.MethodBase.GetCurrentMethod.Name 'Mengambil nama method
        result(1) = 0 : result(2) = "" : result(3) = 0 : result(4) = 0

        'SET DEFAULT PAGING
        resultPaging(0) = 0 : resultPaging(1) = 0 : resultPaging(2) = 0 : resultPaging(3) = 0 : resultPaging(4) = 0


        'VALIDASI PARAMETER GLOBAL =========================================================
        'SPILIT PARAM
        paramSplit = param.Split(sptParam)

        'CEK ARRAY PARAM
        If (paramSplit.Length <> 6) Then
            result(2) = "Invalid parameter." : GoTo selesai
        End If
        'END OF VALIDASI PARAMETER GLOBAL ==================================================


        ''VALIDASI WEBSITEACCESSKEY =========================================================
        'If Len(paramSplit(0)) = 0 Then
        '    result(2) = "WebsiteAccessKey can't be empty." : GoTo selesai
        'End If

        ''Cek apakah WebsiteAccessKey valid
        'Dim ClsValidKey As New ClsSecurity
        'Dim validKey As RsValidKey
        'validKey = ValidateKey(paramSplit(0))
        'If Not validKey.success Then result(2) = validKey.errmessage : GoTo selesai

        ''///Validasi Hak akses. Cek ModuleID dan MenuID
        'If ClsValidKey.ApaBisaAkses(1, 1, 1) = False Then
        '    result(2) = "Access denied for insert/update data"
        'End If
        ''END OF VALIDASI WEBSITEACCESSKEY ==================================================


        'VALIDASI DAN SET USERID ===========================================================
        'CEK USERID
        If (IsNumeric(paramSplit(3)) = False) Then
            result(2) = "userid required numeric." : GoTo selesai
        End If

        'SET USERID
        userid = paramSplit(3)
        'END OF VALIDASI DAN SET USERID ====================================================


        'VALIDASI DAN SET ISUPDATE =========================================================
        'CEK ISUPDATE
        If (IsNumeric(paramSplit(4)) = False) Then
            result(2) = "isupdate required numeric." : GoTo selesai
        Else
            'SET ISUPDATE
            If (Val(paramSplit(4)) = 1) Then
                isUpdate = True
            Else
                isUpdate = False
            End If
        End If
        'END OF VALIDASI DAN SET USERID ====================================================


        'MAPPING BUAT WS ----------------------------------------------------------
        'tglAwal(0) As Date, tglAkhir(1) As Date, sumber(2) As String, notransaksiAwal(3) As String, notransaksiAkhir(4) As String, 
        'tidakAdaJurnal(5) As Integer, jurnalHpp(6) As Integer, hitungUlang(7) As Integer

        'MAPPING BUAT FLEX --------------------------------------------------------
        'tglAwal, tglAkhir, sumber, notransaksiAwal, notransaksiAkhir, tidakAdaJurnal, jurnalHpp, hitungUlang


        'VALIDASI DAN SET DATA =======================================================
        'SPILIT PARAMETER DATA
        dataUtama = paramSplit(5).Split(sptField)

        'CEK ARRAY DATA
        If (dataUtama.Length <> 8) Then
            result(2) = "Invalid data parameter." : GoTo selesai
        End If
        'END OF VALIDASI DAN SET DATA ================================================


        'VALIDASI TIPE DATA ==========================================================
        'tglAwal(0) As Date
        If (IsDate(dataUtama(0)) = False) Then
            result(2) = "tglAwal required date." : GoTo selesai
        Else
            tglAwal = AsFormatTanggal(dataUtama(0))
        End If

        'tglAkhir(1) As Date
        If (IsDate(dataUtama(1)) = False) Then
            result(2) = "tglAkhir required date." : GoTo selesai
        Else
            tglAkhir = AsFormatTanggal(dataUtama(1))
        End If

        'sumber(2) As String
        If Len(dataUtama(2)) > 0 Then
            sumber = dataUtama(2)
        End If

        'notransaksiAwal(3) As String
        If Len(dataUtama(3)) > 0 Then
            notransaksiAwal = dataUtama(3)
        End If

        'notransaksiAkhir(4) As String
        If Len(dataUtama(4)) > 0 Then
            notransaksiAkhir = dataUtama(4)
        End If

        'tidakAdaJurnal(5) As Integer
        If (IsNumeric(dataUtama(5)) = False) Then
            result(2) = "tidakAdaJurnal required numeric." : GoTo selesai
        Else
            If dataUtama(5) = 1 Then
                'jika 1, maka = true (filter untuk transaksi yang tidak ada jurnal saja)
                tidakAdaJurnal = True
            Else
                'jika 0, maka = false (filter untuk semua transaksi)
                tidakAdaJurnal = False
            End If
        End If

        'jurnalHpp(6) As Integer
        If (IsNumeric(dataUtama(6)) = False) Then
            result(2) = "jurnalHpp required numeric." : GoTo selesai
        Else
            If dataUtama(6) = 1 Then
                'jika 1, maka = true (filter untuk transaksi hpp saja)
                jurnalHpp = True
            Else
                'jika 0, maka = false (filter untuk semua transaksi)
                jurnalHpp = False
            End If
        End If

        'hitungUlang(7) As Integer
        If (IsNumeric(dataUtama(7)) = False) Then
            result(2) = "hitungUlang required numeric." : GoTo selesai
        Else
            If dataUtama(7) = 1 Then
                'jika 1, maka = true (filter untuk transaksi yang telah hitung ulang hpp saja)
                hitungUlang = True
            Else
                'jika 0, maka = false (filter untuk semua transaksi)
                hitungUlang = False
            End If
        End If
        'END OF VALIDASI TIPE DATA ===================================================


        'PROSES JURNAL ULANG =========================================================
        Con1 = New MySql.Data.MySqlClient.MySqlConnection(strCon)
        Con1.Open()


        'CEK PERIODE AKUNTANSI ==================================
        Dim arrCekPeriode(2) As String 'success(0), errmessage(1)
        Dim rsCekPeriode As String = M2_Accounting_PeriodeCheck(AsFormatTanggal(tglAwal), AsFormatTanggal(tglAkhir))
        arrCekPeriode = rsCekPeriode.Split(sptSubParam)
        If arrCekPeriode(0) = 0 Then result(2) = arrCekPeriode(1) : GoTo selesai
        'END OF CEK PERIODE AKUNTANSI ===========================


        'AMBIL SUMBER TRANSAKSI
        Dim jmlSumber As Double = 0, arrSumber(25) As String


        If Len(sumber) > 0 Then
            'JIKA SUMBER DIISI MAKA SET SUMBER SESUAI INPUTAN
            'ISI DATA SUMBER
            arrSumber(0) = sumber
            'SET JML SUMBER
            jmlSumber = 1

        Else
            'JIKA SUMBER TIDAK DIISI MAKA SET SUMBER BERDASARKAN JURNAL HPP ATAU SEMUA TRANSAKSI
            If jurnalHpp Then
                'JIKA JURNAL HPP, MAKA JURNAL ULANG TRANSAKSI HPP SAJA
                'ISI DATA SUMBER
                'M3
                arrSumber(0) = "SA" : arrSumber(1) = "IB"
                'M4
                arrSumber(2) = "GRN" : arrSumber(3) = "PRT"
                'M5
                arrSumber(4) = "SI" : arrSumber(5) = "SR"
                'M6
                arrSumber(6) = "PD"

                'SET JML SUMBER
                jmlSumber = arrSumber.Length

            Else
                'JIKA BUKAN JURNAL HPP, MAKA JURNAL ULANG SEMUA TRANSAKSI
                'ISI DATA SUMBER
                'M2
                arrSumber(0) = "CR" : arrSumber(1) = "CD" : arrSumber(2) = "RM" : arrSumber(3) = "SM" : arrSumber(4) = "AJ"
                arrSumber(5) = "GJ" : arrSumber(6) = "RG" : arrSumber(7) = "SG" : arrSumber(8) = "RGC" : arrSumber(9) = "SGC"
                arrSumber(10) = "CB" : arrSumber(10) = "JM"
                'M3
                arrSumber(11) = "SA" : arrSumber(12) = "IB"
                'M4
                arrSumber(13) = "AP" : arrSumber(14) = "GRN" : arrSumber(15) = "RI" : arrSumber(16) = "PRT" : arrSumber(17) = "VP"
                'M5
                arrSumber(18) = "AS" : arrSumber(19) = "IP" : arrSumber(20) = "SI" : arrSumber(21) = "RP" : arrSumber(22) = "SR"
                arrSumber(23) = "PV"
                'M6
                arrSumber(24) = "PD"
                'M7
                arrSumber(25) = "DA"

                'SET JML SUMBER
                jmlSumber = arrSumber.Length
            End If

        End If


        'PROSES JURNAL PER SUMBER
        Dim dtTransaksi As New DataTable
        Dim ModuleID As Integer = 0, jGrup As Integer = 0, idTransaksi As String = ""
        Dim strJournal As String = "", rsJournal() As String, rsResult() As String

        For i = 1 To jmlSumber
            'TAMBAHKAN STEPKE, RESET GRUP
            stepKe += 1 : jGrup = 0
            'SET SUMBER
            sumber = arrSumber(i - 1)

            'SET MODULEID BERDASARKAN SUMBER
            '**************** M2 ****************
            If sumber.ToUpper = "CR" _
                Or sumber.ToUpper = "CD" _
                Or sumber.ToUpper = "RM" _
                Or sumber.ToUpper = "SM" _
                Or sumber.ToUpper = "AJ" _
                Or sumber.ToUpper = "GJ" _
                Or sumber.ToUpper = "RG" _
                Or sumber.ToUpper = "SG" _
                Or sumber.ToUpper = "RGC" _
                Or sumber.ToUpper = "SGC" _
                Or sumber.ToUpper = "CB" _
                Or sumber.ToUpper = "JM" _
                Then
                ModuleID = 2

                '************ M3 ****************
            ElseIf sumber.ToUpper = "SA" _
                Or sumber.ToUpper = "IB" _
                Then
                ModuleID = 3

                '************ M4 ****************
            ElseIf sumber.ToUpper = "AP" _
                Or sumber.ToUpper = "GRN" _
                Or sumber.ToUpper = "RI" _
                Or sumber.ToUpper = "PRT" _
                Or sumber.ToUpper = "VP" _
                Then
                ModuleID = 4

                'SET GRUP UNTUK PRT
                If sumber.ToUpper = "PRT" Then jGrup = 1

                '************ M5 ****************
            ElseIf sumber.ToUpper = "AS" _
                Or sumber.ToUpper = "IP" _
                Or sumber.ToUpper = "SI" _
                Or sumber.ToUpper = "RP" _
                Or sumber.ToUpper = "SR" _
                Or sumber.ToUpper = "PV" _
                Then
                ModuleID = 5

                'SET GRUP UNTUK SI ATAU SR
                If sumber.ToUpper = "SI" Or sumber.ToUpper = "SR" Then jGrup = 1

                '************ M6 ****************
            ElseIf sumber.ToUpper = "PD" _
                Then
                ModuleID = 6

                '************ M7 ****************
            ElseIf sumber.ToUpper = "DA" _
                Then
                ModuleID = 7

            Else
                result(2) = "Invalid Packet. (" & sumber & ")" : GoTo selesai
            End If

            'SUSUN SQL PENGAMBILAN DATA
            If jurnalHpp Then

                'SQL UNTUK JURNAL TRANSAKSI HPP SAJA
                If hitungUlang Then
                    'JIKA HITUNG ULANG, MAKA JURNAL ULANG UNTUK TRANSAKSI HPP YANG SUDAH HITUNG ULANG HPP SAJA
                    sql = "  SELECT idutama"
                    sql &= " FROM M1_Item_Transaction"
                    sql &= " WHERE sumber = '" & FixQuotes(sumber) & "'"
                    sql &= " AND hppfix = 1"
                    sql &= " AND jurnalfix = 0"

                    'TAMBAHKAN FILTER TANGGAL
                    If Len(tglAwal) > 0 And Len(tglAkhir) > 0 Then
                        sql &= " AND tgl BETWEEN '" & FixQuotes(tglAwal) & "' AND '" & FixQuotes(tglAkhir) & "'"
                    ElseIf Len(tglAwal) > 0 Then
                        sql &= " AND tgl >= '" & FixQuotes(tglAwal) & "'"
                    ElseIf Len(tglAkhir) > 0 Then
                        sql &= " AND tgl <= '" & FixQuotes(tglAkhir) & "'"
                    End If

                    'TAMBAHKAN FILTER NOTRANSAKSI
                    If Len(notransaksiAwal) > 0 And Len(notransaksiAkhir) > 0 Then
                        sql &= " AND notransaksi BETWEEN '" & FixQuotes(notransaksiAwal) & "' AND '" & FixQuotes(notransaksiAkhir) & "'"
                    ElseIf Len(notransaksiAwal) > 0 Then
                        sql &= " AND notransaksi >= '" & FixQuotes(notransaksiAwal) & "'"
                    ElseIf Len(notransaksiAkhir) > 0 Then
                        sql &= " AND notransaksi <= '" & FixQuotes(notransaksiAkhir) & "'"
                    End If

                    'TAMBAHKAN GROUP BY
                    sql &= " GROUP BY sumber, idutama"

                    'TAMBAHKAN ORDER BY
                    sql &= " ORDER BY tgl, notransaksi, idutama"

                Else
                    'JIKA TIDAK HITUNG ULANG, MAKA JURNAL ULANG UNTUK SEMUA TRANSAKSI HPP
                    sql = "  SELECT " & sumber & "id"
                    sql &= " FROM M" & ModuleID & "_" & sumber & ""
                    sql &= " WHERE " & sumber & "status IN(2,3,4,7)"

                    'TAMBAHKAN FILTER TANGGAL
                    If Len(tglAwal) > 0 And Len(tglAkhir) > 0 Then
                        sql &= " AND " & sumber & "tgl BETWEEN '" & FixQuotes(tglAwal) & "' AND '" & FixQuotes(tglAkhir) & "'"
                    ElseIf Len(tglAwal) > 0 Then
                        sql &= " AND " & sumber & "tgl >= '" & FixQuotes(tglAwal) & "'"
                    ElseIf Len(tglAkhir) > 0 Then
                        sql &= " AND " & sumber & "tgl <= '" & FixQuotes(tglAkhir) & "'"
                    End If

                    'TAMBAHKAN FILTER NOTRANSAKSI
                    If Len(notransaksiAwal) > 0 And Len(notransaksiAkhir) > 0 Then
                        sql &= " AND " & sumber & "notransaksi BETWEEN '" & FixQuotes(notransaksiAwal) & "' AND '" & FixQuotes(notransaksiAkhir) & "'"
                    ElseIf Len(notransaksiAwal) > 0 Then
                        sql &= " AND " & sumber & "notransaksi >= '" & FixQuotes(notransaksiAwal) & "'"
                    ElseIf Len(notransaksiAkhir) > 0 Then
                        sql &= " AND " & sumber & "notransaksi <= '" & FixQuotes(notransaksiAkhir) & "'"
                    End If

                    'TAMBAHKAN GROUP BY
                    sql &= " GROUP BY " & sumber & "id"

                    'TAMBAHKAN ORDER BY
                    sql &= " ORDER BY " & sumber & "tgl, " & sumber & "notransaksi, " & sumber & "id"

                End If

            Else
                'SQL UNTUK SEMUA TRANSAKSI
                If tidakAdaJurnal Then
                    'JIKA TRANSAKSI YANG TIDAK PUNYA JURNAL SAJA
                    sql = "  SELECT " & sumber & "id"
                    sql &= " FROM M" & ModuleID & "_" & sumber & ""
                    sql &= " LEFT JOIN M2_Transaction_Journal ON " & sumber & "sumber = tsumber AND " & sumber & "id = tidtransaksi AND " & sumber & "notransaksi = tnotransaksi"
                    sql &= " WHERE " & sumber & "status IN(2,3,4,7)"
                    sql &= " AND tid IS NULL"

                Else
                    'SEMUA TRANSAKSI
                    sql = "  SELECT " & sumber & "id"
                    sql &= " FROM M" & ModuleID & "_" & sumber & ""
                    sql &= " WHERE " & sumber & "status IN(2,3,4,7)"
                End If

                'TAMBAHKAN FILTER TANGGAL
                If Len(tglAwal) > 0 And Len(tglAkhir) > 0 Then
                    sql &= " AND " & sumber & "tgl BETWEEN '" & FixQuotes(tglAwal) & "' AND '" & FixQuotes(tglAkhir) & "'"
                ElseIf Len(tglAwal) > 0 Then
                    sql &= " AND " & sumber & "tgl >= '" & FixQuotes(tglAwal) & "'"
                ElseIf Len(tglAkhir) > 0 Then
                    sql &= " AND " & sumber & "tgl <= '" & FixQuotes(tglAkhir) & "'"
                End If

                'TAMBAHKAN FILTER NOTRANSAKSI
                If Len(notransaksiAwal) > 0 And Len(notransaksiAkhir) > 0 Then
                    sql &= " AND " & sumber & "notransaksi BETWEEN '" & FixQuotes(notransaksiAwal) & "' AND '" & FixQuotes(notransaksiAkhir) & "'"
                ElseIf Len(notransaksiAwal) > 0 Then
                    sql &= " AND " & sumber & "notransaksi >= '" & FixQuotes(notransaksiAwal) & "'"
                ElseIf Len(notransaksiAkhir) > 0 Then
                    sql &= " AND " & sumber & "notransaksi <= '" & FixQuotes(notransaksiAkhir) & "'"
                End If

                'TAMBAHKAN GROUP BY
                sql &= " GROUP BY " & sumber & "id"

                'TAMBAHKAN ORDER BY
                sql &= " ORDER BY " & sumber & "tgl, " & sumber & "notransaksi, " & sumber & "id"

            End If


            'result(2) = sql : GoTo selesai
            'AMBIL DATA TRANSAKSI
            dtTransaksi = AsDataTableAmbilDariDB(sql, strCon)
            If dtTransaksi.Rows.Count > 0 Then
                For Each dr1 As DataRow In dtTransaksi.Rows
                    'SET IDTRANSAKSI
                    If jurnalHpp And hitungUlang Then
                        idTransaksi = dr1("idutama")
                    Else
                        idTransaksi = dr1(sumber & "id")
                    End If

                    'PANGGIL FUNGSI JURNAL - mapping fungsi yg dikirim = idmsmq, sumber, idtransaksi
                    strJournal = M0_Journal(paramSplit(0) & "★M0_Journal★0△0△△△dd/MM/yyyy△dd/MM/yyyy H:mm:ss★0★1★M0_Journal△" & sumber & "△" & idTransaksi & "")

                    '// FORMAT kembalian fungsi jurnal = result★paging★data, yg diambil bagian result saja. 
                    rsJournal = strJournal.Split(sptParam)

                    '// JIKA KEMBALIAN FUNGSI JURNAL <> 3 MAKA SALAH
                    If rsJournal.Length = 3 Then
                        '// AMBIL BAGIAN RESULT DARI FUNGSI JURNAL - result = target(0)△success(2)△errmessage(2)△errstep(3)△idtransaksi(4)
                        rsResult = rsJournal(0).Split(sptSubParam)
                        '// JIKA BAGIAN RESULT DARI FUNGSI JURNAL <> 5 MAKA SALAH
                        If rsResult.Length = 5 Then
                            If rsResult(1) <> 1 And rsResult(1) <> 4 Then '// JIKA GAGAL - KIRIM INFORMASI PROSES GAGAL, TAMPILKAN ERRMESSAGE
                                result(2) = "Journal proccess failed. " & sumber & " : " & idTransaksi & ". " & rsResult(2) & "" : GoTo selesai
                            End If
                        Else
                            result(2) = "Journal proccess failed. " & sumber & " : " & idTransaksi & ". Invalid result data #2'" : GoTo selesai
                        End If

                    Else
                        result(2) = "Journal proccess failed. " & sumber & " : " & idTransaksi & ". Invalid result data #1'" : GoTo selesai
                    End If

                Next
            End If

        Next

        result(1) = 1
        result(2) = ""
        result(3) = stepKe
        result(4) = result(4)
        'END OF PROSES JURNAL ULANG ==================================================


selesai:

        'SET ERR STEPKE
        result(3) = stepKe

        If result(1) = 0 Then
            If Len(result(2)) = 0 Then result(2) = "Nomor : " & Err.Number & ". Sumber : " & Err.Source & ".  Fungsi : " & System.Reflection.MethodBase.GetCurrentMethod.Name & ". Uraian : " & Err.Description & ". "
        End If

        strResult = String.Join(sptSubParam, result)
        strResultPaging = String.Join(sptSubParam, resultPaging)
        strResultData = ""
        wsResult = String.Concat(strResult.Substring(0, strResult.Length - 1), sptParam, strResultPaging.Substring(0, strResultPaging.Length - 1), sptParam, strResultData)

        Return wsResult
    End Function

    Public Function M0_Journal(ByVal param As String) As String

        Dim objCmd As MySql.Data.MySqlClient.MySqlCommand
        Dim Trans As MySql.Data.MySqlClient.MySqlTransaction

        Dim paramSplit(6) As String     'WebsiteAccessKey(0), paket(1), paging(2), userid(3), isUpdate(4), data(5)
        Dim pagingSplit(6) As String    'pageNumber(0), itemLimit(1), strFilter(2), strSort(3), formatTgl(4), formatTglWaktu(5)
        Dim idSplit(1) As String

        Dim result(5) As String         'target(0), success(1), errmessage(2), errstep(3), idtransaksi(4)
        Dim resultPaging(5) As String   'ispaging(0), isNext(1), isPrev(2), countPage(3), countRow(4)

        Dim wsResult As String = ""
        Dim strResult, strResultPaging As String

        Dim sql As String = ""

        Dim pg1 As New RsPaging

        'SET DEFAULT RESULT
        result(0) = System.Reflection.MethodBase.GetCurrentMethod.Name 'Mengambil nama method
        result(1) = 0 : result(2) = "" : result(3) = 0 : result(4) = 0

        'SET DEFAULT PAGING
        resultPaging(0) = 0 : resultPaging(1) = 0 : resultPaging(2) = 0 : resultPaging(3) = 0 : resultPaging(4) = 0

        'VALIDASI PARAMETER GLOBAL =========================================================
        'SPILIT PARAM
        paramSplit = param.Split(sptParam)

        'CEK ARRAY PARAM
        If (paramSplit.Length <> 6) Then
            result(2) = "Invalid parameter." : GoTo selesai
        End If
        'END OF VALIDASI PARAMETER GLOBAL ==================================================

        ''VALIDASI WEBSITEACCESSKEY =========================================================
        'If Len(paramSplit(0)) = 0 Then
        '    result(2) = "WebsiteAccessKey can't be empty." : GoTo selesai
        'End If

        ''Cek apakah WebsiteAccessKey valid
        'Dim ClsValidKey As New ClsSecurity
        'Dim validKey As RsValidKey
        'validKey = ValidateKey(paramSplit(0))
        'If Not validKey.success Then result(2) = validKey.errmessage : GoTo selesai

        ''///Validasi Hak akses. Cek ModuleID dan MenuID
        'If ClsValidKey.ApaBisaAkses(1, 1, 1) = False Then
        '    result(2) = "Access denied for insert/update data"
        'End If
        ''END OF VALIDASI WEBSITEACCESSKEY ==================================================

        'VALIDASI DAN SET USERID ===========================================================
        'CEK USERID
        If (IsNumeric(paramSplit(3)) = False) Then
            result(2) = "userid required numeric." : GoTo selesai
        End If

        'SET USERID
        userid = paramSplit(3)
        'END OF VALIDASI DAN SET USERID ====================================================

        'VALIDASI DAN SET IDTRANSAKSI ======================================================
        'CEK IDMSMQ, SUMBER DAN IDTRANSAKSI
        Dim msmqId As String = "", sumber As String = "", idtransaksi As String = ""
        Dim idtrans(3) As String
        idtrans = paramSplit(5).Split(sptSubParam)
        If (idtrans.Length <> 3) Then
            result(2) = "Invalid key parameter." : GoTo selesai
        Else
            'CEK IDMSMQ
            If (Len(idtrans(0)) = 0) Then
                result(2) = "MSMQ ID can't be empty." : GoTo selesai
            Else
                msmqId = idtrans(0)
            End If
            'CEK SUMBER
            If (Len(idtrans(1)) = 0) Then
                result(2) = "Sumber can't be empty." : GoTo selesai
            Else
                sumber = idtrans(1)
            End If
            'CEK IDTRANSAKSI
            If (IsNumeric(idtrans(2)) = False) Then
                result(2) = "ID Transaksi required numeric." : GoTo selesai
            Else
                idtransaksi = idtrans(2)
            End If
        End If
        'END OF VALIDASI DAN SET IDTRANSAKSI ===============================================


        'SIMPAN KE DATABASE ================================================================

        Con1 = New MySql.Data.MySqlClient.MySqlConnection(strCon)
        Con1.Open()

        Dim rsJurnal As String = "" 'progress△errMessage△sqljurnal▲sqlupdateposting
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = ""

        'PANGGIL JURNAL BERDASARKAN SUMBER
        Select Case sumber.ToUpper
            '**************** M2 ****************
            Case "CR" : rsJurnal = M2_Cr(idtransaksi)
            Case "CD" : rsJurnal = M2_Cd(idtransaksi)
            Case "RM" : rsJurnal = M2_Rm(idtransaksi)
            Case "SM" : rsJurnal = M2_Sm(idtransaksi)
            Case "AJ" : rsJurnal = M2_Aj(idtransaksi)
            Case "GJ" : rsJurnal = M2_Gj(idtransaksi)
            Case "RG" : rsJurnal = M2_Rg(idtransaksi)
            Case "SG" : rsJurnal = M2_Sg(idtransaksi)
            Case "RGC" : rsJurnal = M2_Rgc(idtransaksi)
            Case "SGC" : rsJurnal = M2_Sgc(idtransaksi)
            Case "CB" : rsJurnal = M2_Cb(idtransaksi)
            Case "JM" : rsJurnal = M2_Jm(idtransaksi)

                '************ M3 ****************
            Case "SA" : rsJurnal = M3_Sa(idtransaksi)
            Case "IB" : rsJurnal = M3_Ib(idtransaksi)

                '************ M4 ****************
            Case "AP" : rsJurnal = M4_Ap(idtransaksi)
            Case "GRN" : rsJurnal = M4_Grn(idtransaksi)
            Case "RI" : rsJurnal = M4_Ri(idtransaksi)
            Case "RI_B" : rsJurnal = M4_RiBalance(idtransaksi)
            Case "PRT" : rsJurnal = M4_Prt(idtransaksi)
            Case "PRT_B" : rsJurnal = M4_PrtBalance(idtransaksi)
            Case "VP" : rsJurnal = M4_Vp(idtransaksi)

                '************ M5 ****************
            Case "IP" : rsJurnal = M5_Ip(idtransaksi)
            Case "AS" : rsJurnal = M5_As(idtransaksi)
            Case "SI" : rsJurnal = M5_Si(idtransaksi)
            Case "SI_B" : rsJurnal = M5_SiBalance(idtransaksi)
            Case "RP" : rsJurnal = M5_Rp(idtransaksi)
            Case "SR" : rsJurnal = M5_Sr(idtransaksi)
            Case "SR_B" : rsJurnal = M5_SrBalance(idtransaksi)
            Case "PV" : rsJurnal = M5_Pv(idtransaksi)

                '************ M6 ****************
            Case "PD" : rsJurnal = M6_Pd(idtransaksi)

                '************ M7 ****************
            Case "DA" : rsJurnal = M7_Da(idtransaksi)

                '************ M11 ****************
            Case "LU" : rsJurnal = M11_Lu(idtransaksi)
            Case "KM" : rsJurnal = M11_Km(idtransaksi)
            Case "LB" : rsJurnal = M11_Lb(idtransaksi)
            Case "AK" : rsJurnal = M11_Ak(idtransaksi)
            Case "RK" : rsJurnal = M11_Rk(idtransaksi)
            Case "PB" : rsJurnal = M11_Pb(idtransaksi)
            Case "RO" : rsJurnal = M11_Ro(idtransaksi)
            Case "KW" : rsJurnal = M11_Kw(idtransaksi)

            Case Else
                result(2) = "Invalid Packet." : GoTo selesai
        End Select

        'SPLIT HASIL JURNAL (progress, errmessage, sql)
        Dim sptRsJurnal() As String = rsJurnal.Split(sptSubParam)
        If sptRsJurnal.Length <> 3 Then
            result(2) = "Invalid journal result." : GoTo selesai
        Else
            rsProgress = sptRsJurnal(0)
            rsErrMessage = sptRsJurnal(1)
            rsSql = sptRsJurnal(2)
        End If

        'JIKA HASIL JURNAL TIDAK ERROR MAKA EKSEKUSI SQL
        'If rsProgress = 1 Then

        '*** Start Transaction ***'  
        Trans = Con1.BeginTransaction(IsolationLevel.ReadCommitted)

        Try
            'EKSEKUSI SQL SESUAI BANYAKNYA QUERY HASIL JURNAL
            Dim sptRsSql() As String = rsSql.Split(sptRow)
            For i As Integer = 1 To sptRsSql.Length
                sql = sptRsSql(i - 1)
                'JIKA SQL TERISI MAKA DI EKSEKUSI
                If Len(sql) > 0 Then
                    objCmd = New MySql.Data.MySqlClient.MySqlCommand()
                    With objCmd
                        .Connection = Con1
                        .Transaction = Trans
                        .CommandType = CommandType.Text
                        .CommandText = sql
                    End With
                    objCmd.ExecuteNonQuery()
                    'Else
                    '    result(2) = "Invalid journal : " & i - 1 & "." : Trans.Rollback() : GoTo selesai
                End If
            Next

            'JIKA HASIL JURNAL TIDAK ERROR MAKA UPDATE STATUS TABEL MSQMQ JURNAL = SUKSES(2), ELSE = GAGAL(3)
            Dim mjprogress As Integer = 0
            If rsProgress = 1 Then
                'JIKA 1 MAKA SUKSES(2)
                mjprogress = 2
            ElseIf rsProgress = 4 Then
                'JIKA 4 MAKA TRANSAKSI TDK APPROVED(4)
                mjprogress = 4
            Else
                'SELAIN 1 DAN 4 MAKA GAGAL(3)
                mjprogress = 3
            End If


            'UPDATE STATUS TABEL MSQMQ JURNAL
            sql = "UPDATE m0_msmq_journal SET mjprogress = '" & mjprogress & "', mjpesan = '" & FixQuotes(rsErrMessage) & "', mjtglselesai = NOW() WHERE mjid = '" & msmqId & "'"
            objCmd = New MySql.Data.MySqlClient.MySqlCommand()
            With objCmd
                .Connection = Con1
                .Transaction = Trans
                .CommandType = CommandType.Text
                .CommandText = sql
            End With
            objCmd.ExecuteNonQuery()

            Trans.Commit()  '*** Commit Transaction ***'
            result(1) = rsProgress
            result(2) = rsErrMessage
            result(3) = 0
            result(4) = result(4)

        Catch ex As Exception

            Trans.Rollback() '*** RollBack Transaction ***'  
            result(1) = 0
            result(2) = "Transaction Rollback : " & ex.Message
            result(3) = 0
            result(4) = result(4)

        End Try

        objCmd = Nothing
        'Con1.Close()
        'END OF SIMPAN KE DATABASE =========================================================

        'Else
        'result(2) = rsErrMessage : GoTo selesai
        'End If

selesai:
        If result(1) = 0 Then
            If Len(result(2)) = 0 Then result(2) = "Nomor : " & Err.Number & ". Sumber : " & Err.Source & ".  Fungsi : " & System.Reflection.MethodBase.GetCurrentMethod.Name & ". Uraian : " & Err.Description & ". "
        End If

        strResult = String.Join(sptSubParam, result)
        strResultPaging = String.Join(sptSubParam, resultPaging)
        wsResult = String.Concat(strResult.Substring(0, strResult.Length - 1), sptParam, strResultPaging.Substring(0, strResultPaging.Length - 1), sptParam)

        Return wsResult
    End Function

    '********************************************** M2 **********************************************

#Region "M2_Cr"
    Public Function M2_Cr(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'KAS (+D)
        '         AKUN LAWAN (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT cr.* FROM m2_cr cr WHERE (cr.crstatus = 2 OR cr.crstatus = 3 OR cr.crstatus = 4 OR cr.crstatus = 7) AND cr.crid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT crd.* FROM m2_cr_detail crd JOIN m2_cr cr ON crd.idcr = cr.crid WHERE (cr.crstatus = 2 OR cr.crstatus = 3 OR cr.crstatus = 4 OR cr.crstatus = 7) AND cr.crid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("crsumber")
            noTransaksi = drutama("crnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT ------------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI UTAMA
            debitkredit = 0
            urutan = 1
            If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                  String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("crnorek").ToString, "KAS", Double.Parse(drutama("crjumlah")), Double.Parse(drutama("crjumlahvalas")), debitkredit, drutama("crcatatan").ToString, "", "", "", "", urutan)) = False Then
                rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            End If
            'END OF AKUN DEBIT -----------------------------------

            'AKUN KREDIT -----------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            debitkredit = 1
            For Each drdetail As DataRow In dtdetail.Rows
                urutan = Val(drdetail("urutan")) + 1
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("norek").ToString, "AKUN LAWAN", Double.Parse(drdetail("jumlah")), Double.Parse(drdetail("jumlahvalas")), debitkredit, drutama("crcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If
            Next
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("crcabang")) & "', '" & FixQuotes(drutama("crlokasi")) & "', '" & FixQuotes(drutama("crsumber")) & "', " & 0 & ", " & drutama("crid") & ", '" & FixQuotes(drutama("crnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("crtgl"))) & "', " & drutama("crkodepa") & ", " & drutama("crkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("cruraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("crmatauang")) & "', '" & FixDouble(drutama("crkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("crtgllunas"))) & "', " & drutama("crstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("crjumlahbayar")) & "', " & drutama("crstatusbayar") & ", " & drutama("crstatus") & ", 1, NOW(), " & drutama("crjmlrevisi") & ", " & drutama("crcetakanke") & ", " & drutama("crinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("crinputtgl"), formatTglWaktuDB)) & "', " & drutama("crmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("crmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("crcabang")) & "', '" & FixQuotes(drutama("crlokasi")) & "', '" & FixQuotes(drutama("crsumber")) & "', " & 0 & ", " & drutama("crid") & ", '" & FixQuotes(drutama("crnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("crtgl"))) & "', " & drutama("crkodepa") & ", " & drutama("crkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("cruraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("crmatauang")) & "', '" & FixDouble(drutama("crkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("crtgllunas"))) & "', " & drutama("crstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("crjumlahbayar")) & "', " & drutama("crstatusbayar") & ", " & drutama("crstatus") & ", 1, NOW(), " & drutama("crjmlrevisi") & ", " & drutama("crcetakanke") & ", " & drutama("crinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("crinputtgl"), formatTglWaktuDB)) & "', " & drutama("crmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("crmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'CR' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING CR
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m2_cr SET crposting = 1, crpostingtgl = NOW() WHERE crid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M2_Cd"
    Public Function M2_Cd(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'AKUN LAWAN (D)
        '         KAS (-K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT cd.* FROM m2_cd cd WHERE (cd.cdstatus = 2 OR cd.cdstatus = 3 OR cd.cdstatus = 4 OR cd.cdstatus = 7) AND cd.cdid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT cdd.* FROM m2_cd_detail cdd JOIN m2_cd cd ON cdd.idcd = cd.cdid WHERE (cd.cdstatus = 2 OR cd.cdstatus = 3 OR cd.cdstatus = 4 OR cd.cdstatus = 7) AND cd.cdid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("cdsumber")
            noTransaksi = drutama("cdnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT ------------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            debitkredit = 0
            For Each drdetail As DataRow In dtdetail.Rows
                urutan = Val(drdetail("urutan"))
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("norek").ToString, "AKUN LAWAN", Double.Parse(drdetail("jumlah")), Double.Parse(drdetail("jumlahvalas")), debitkredit, drutama("cdcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If
            Next
            'END OF AKUN DEBIT -----------------------------------

            'AKUN KREDIT -----------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI UTAMA
            debitkredit = 1
            urutan = urutan + 1
            If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                  String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("cdnorek").ToString, "KAS", Double.Parse(drutama("cdjumlah")), Double.Parse(drutama("cdjumlahvalas")), debitkredit, drutama("cdcatatan").ToString, "", "", "", "", urutan)) = False Then
                rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            End If
            'END OF AKUN KREDIT ----------------------------------
        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("cdcabang")) & "', '" & FixQuotes(drutama("cdlokasi")) & "', '" & FixQuotes(drutama("cdsumber")) & "', " & 0 & ", " & drutama("cdid") & ", '" & FixQuotes(drutama("cdnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("cdtgl"))) & "', " & drutama("cdkodepa") & ", " & drutama("cdkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("cduraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("cdmatauang")) & "', '" & FixDouble(drutama("cdkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("cdtgllunas"))) & "', " & drutama("cdstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("cdjumlahbayar")) & "', " & drutama("cdstatusbayar") & ", " & drutama("cdstatus") & ", 1, NOW(), " & drutama("cdjmlrevisi") & ", " & drutama("cdcetakanke") & ", " & drutama("cdinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("cdinputtgl"), formatTglWaktuDB)) & "', " & drutama("cdmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("cdmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("cdcabang")) & "', '" & FixQuotes(drutama("cdlokasi")) & "', '" & FixQuotes(drutama("cdsumber")) & "', " & 0 & ", " & drutama("cdid") & ", '" & FixQuotes(drutama("cdnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("cdtgl"))) & "', " & drutama("cdkodepa") & ", " & drutama("cdkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("cduraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("cdmatauang")) & "', '" & FixDouble(drutama("cdkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("cdtgllunas"))) & "', " & drutama("cdstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("cdjumlahbayar")) & "', " & drutama("cdstatusbayar") & ", " & drutama("cdstatus") & ", 1, NOW(), " & drutama("cdjmlrevisi") & ", " & drutama("cdcetakanke") & ", " & drutama("cdinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("cdinputtgl"), formatTglWaktuDB)) & "', " & drutama("cdmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("cdmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'CD' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING CD
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m2_cd SET cdposting = 1, cdpostingtgl = NOW() WHERE cdid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================


        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M2_Rm"
    Public Function M2_Rm(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'BANK/PIUTANG GIRO (+D)
        '         AKUN LAWAN (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT rm.* FROM m2_rm rm WHERE (rm.rmstatus = 2 OR rm.rmstatus = 3 OR rm.rmstatus = 4 OR rm.rmstatus = 7) AND rm.rmid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT rmd.* FROM m2_rm_detail rmd JOIN m2_rm rm ON rmd.idrm = rm.rmid WHERE (rm.rmstatus = 2 OR rm.rmstatus = 3 OR rm.rmstatus = 4 OR rm.rmstatus = 7) AND rm.rmid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("rmsumber")
            noTransaksi = drutama("rmnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT ------------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI UTAMA
            debitkredit = 0
            urutan = 1
            If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                  String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("rmnorek").ToString, "BANK/PIUTANG GIRO", Double.Parse(drutama("rmjumlah")), Double.Parse(drutama("rmjumlahvalas")), debitkredit, drutama("rmcatatan").ToString, "", "", "", "", urutan)) = False Then
                rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            End If
            'END OF AKUN DEBIT -----------------------------------

            'AKUN KREDIT -----------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            debitkredit = 1
            For Each drdetail As DataRow In dtdetail.Rows
                urutan = Val(drdetail("urutan")) + 1
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("norek").ToString, "AKUN LAWAN", Double.Parse(drdetail("jumlah")), Double.Parse(drdetail("jumlahvalas")), debitkredit, drutama("rmcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If
            Next
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("rmcabang")) & "', '" & FixQuotes(drutama("rmlokasi")) & "', '" & FixQuotes(drutama("rmsumber")) & "', " & 0 & ", " & drutama("rmid") & ", '" & FixQuotes(drutama("rmnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("rmtgl"))) & "', " & drutama("rmkodepa") & ", " & drutama("rmkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("rmuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("rmmatauang")) & "', '" & FixDouble(drutama("rmkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("rmtgllunas"))) & "', " & drutama("rmstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("rmjumlahbayar")) & "', " & drutama("rmstatusbayar") & ", " & drutama("rmstatus") & ", 1, NOW(), " & drutama("rmjmlrevisi") & ", " & drutama("rmcetakanke") & ", " & drutama("rminputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rminputtgl"), formatTglWaktuDB)) & "', " & drutama("rmmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rmmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("rmcabang")) & "', '" & FixQuotes(drutama("rmlokasi")) & "', '" & FixQuotes(drutama("rmsumber")) & "', " & 0 & ", " & drutama("rmid") & ", '" & FixQuotes(drutama("rmnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("rmtgl"))) & "', " & drutama("rmkodepa") & ", " & drutama("rmkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("rmuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("rmmatauang")) & "', '" & FixDouble(drutama("rmkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("rmtgllunas"))) & "', " & drutama("rmstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("rmjumlahbayar")) & "', " & drutama("rmstatusbayar") & ", " & drutama("rmstatus") & ", 1, NOW(), " & drutama("rmjmlrevisi") & ", " & drutama("rmcetakanke") & ", " & drutama("rminputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rminputtgl"), formatTglWaktuDB)) & "', " & drutama("rmmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rmmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'RM' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING RM
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m2_rm SET rmposting = 1, rmpostingtgl = NOW() WHERE rmid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================


        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M2_Sm"
    Public Function M2_Sm(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'AKUN LAWAN (D)
        '         BANK/HUTANG GIRO (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT sm.* FROM m2_sm sm WHERE (sm.smstatus = 2 OR sm.smstatus = 3 OR sm.smstatus = 4 OR sm.smstatus = 7) AND sm.smid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT smd.* FROM m2_sm_detail smd JOIN m2_sm sm ON smd.idsm = sm.smid WHERE (sm.smstatus = 2 OR sm.smstatus = 3 OR sm.smstatus = 4 OR sm.smstatus = 7) AND sm.smid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("smsumber")
            noTransaksi = drutama("smnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT ------------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            debitkredit = 0
            For Each drdetail As DataRow In dtdetail.Rows
                urutan = Val(drdetail("urutan"))
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("norek").ToString, "AKUN LAWAN", Double.Parse(drdetail("jumlah")), Double.Parse(drdetail("jumlahvalas")), debitkredit, drutama("smcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If
            Next
            'END OF AKUN DEBIT -----------------------------------

            'AKUN KREDIT -----------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI UTAMA
            debitkredit = 1
            urutan = urutan + 1
            If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                  String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("smnorek").ToString, "BANK/HUTANG GIRO", Double.Parse(drutama("smjumlah")), Double.Parse(drutama("smjumlahvalas")), debitkredit, drutama("smcatatan").ToString, "", "", "", "", urutan)) = False Then
                rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            End If
            'END OF AKUN KREDIT ----------------------------------
        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("smcabang")) & "', '" & FixQuotes(drutama("smlokasi")) & "', '" & FixQuotes(drutama("smsumber")) & "', " & 0 & ", " & drutama("smid") & ", '" & FixQuotes(drutama("smnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("smtgl"))) & "', " & drutama("smkodepa") & ", " & drutama("smkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("smuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("smmatauang")) & "', '" & FixDouble(drutama("smkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("smtgllunas"))) & "', " & drutama("smstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("smjumlahbayar")) & "', " & drutama("smstatusbayar") & ", " & drutama("smstatus") & ", 1, NOW(), " & drutama("smjmlrevisi") & ", " & drutama("smcetakanke") & ", " & drutama("sminputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("sminputtgl"), formatTglWaktuDB)) & "', " & drutama("smmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("smmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("smcabang")) & "', '" & FixQuotes(drutama("smlokasi")) & "', '" & FixQuotes(drutama("smsumber")) & "', " & 0 & ", " & drutama("smid") & ", '" & FixQuotes(drutama("smnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("smtgl"))) & "', " & drutama("smkodepa") & ", " & drutama("smkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("smuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("smmatauang")) & "', '" & FixDouble(drutama("smkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("smtgllunas"))) & "', " & drutama("smstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("smjumlahbayar")) & "', " & drutama("smstatusbayar") & ", " & drutama("smstatus") & ", 1, NOW(), " & drutama("smjmlrevisi") & ", " & drutama("smcetakanke") & ", " & drutama("sminputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("sminputtgl"), formatTglWaktuDB)) & "', " & drutama("smmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("smmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'SM' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SM
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m2_sm SET smposting = 1, smpostingtgl = NOW() WHERE smid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M2_Aj"
    Public Function M2_Aj(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'AKUN DEBIT (D)
        '         AKUN KREDIT (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT aj.* FROM m2_aj aj WHERE (aj.ajstatus = 2 OR aj.ajstatus = 3 OR aj.ajstatus = 4 OR aj.ajstatus = 7) AND aj.ajid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT ajd.* FROM m2_aj_detail ajd JOIN m2_aj aj ON ajd.idaj = aj.ajid WHERE (aj.ajstatus = 2 OR aj.ajstatus = 3 OR aj.ajstatus = 4 OR aj.ajstatus = 7) AND aj.ajid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("ajsumber")
            noTransaksi = drutama("ajnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT & KREDIT ---------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            For Each drdetail As DataRow In dtdetail.Rows
                urutan = Val(drdetail("urutan"))
                'JIKA DEBIT <> 0 MAKA JURNAL SISI DEBIT
                If Double.Parse(drdetail("debit")) <> 0 Then
                    debitkredit = 0
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("norek").ToString, "AKUN DEBIT", Double.Parse(drdetail("debit")), Double.Parse(drdetail("debitvalas")), debitkredit, drutama("ajcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If

                    'JIKA KREDIT <> 0 MAKA JURNAL SISI KREDIT
                Else
                    debitkredit = 1
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("norek").ToString, "AKUN KREDIT", Double.Parse(drdetail("kredit")), Double.Parse(drdetail("kreditvalas")), debitkredit, drutama("ajcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If

                End If
            Next
            'END OF AKUN DEBIT & KREDIT --------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("ajcabang")) & "', '" & FixQuotes(drutama("ajlokasi")) & "', '" & FixQuotes(drutama("ajsumber")) & "', " & 0 & ", " & drutama("ajid") & ", '" & FixQuotes(drutama("ajnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("ajtgl"))) & "', " & drutama("ajkodepa") & ", " & drutama("ajkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("ajuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("ajmatauang")) & "', '" & FixDouble(drutama("ajkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("ajtgllunas"))) & "', " & drutama("ajstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("ajjumlahbayar")) & "', " & drutama("ajstatusbayar") & ", " & drutama("ajstatus") & ", 1, NOW(), " & drutama("ajjmlrevisi") & ", " & drutama("ajcetakanke") & ", " & drutama("ajinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("ajinputtgl"), formatTglWaktuDB)) & "', " & drutama("ajmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("ajmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("ajcabang")) & "', '" & FixQuotes(drutama("ajlokasi")) & "', '" & FixQuotes(drutama("ajsumber")) & "', " & 0 & ", " & drutama("ajid") & ", '" & FixQuotes(drutama("ajnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("ajtgl"))) & "', " & drutama("ajkodepa") & ", " & drutama("ajkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("ajuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("ajmatauang")) & "', '" & FixDouble(drutama("ajkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("ajtgllunas"))) & "', " & drutama("ajstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("ajjumlahbayar")) & "', " & drutama("ajstatusbayar") & ", " & drutama("ajstatus") & ", 1, NOW(), " & drutama("ajjmlrevisi") & ", " & drutama("ajcetakanke") & ", " & drutama("ajinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("ajinputtgl"), formatTglWaktuDB)) & "', " & drutama("ajmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("ajmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'AJ' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING AJ
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m2_aj SET ajposting = 1, ajpostingtgl = NOW() WHERE ajid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M2_Gj"
    Public Function M2_Gj(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'AKUN DEBIT (D)
        '         AKUN KREDIT (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT gj.* FROM m2_gj gj WHERE (gj.gjstatus = 2 OR gj.gjstatus = 3 OR gj.gjstatus = 4 OR gj.gjstatus = 7) AND gj.gjid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT gjd.* FROM m2_gj_detail gjd JOIN m2_gj gj ON gjd.idgj = gj.gjid WHERE (gj.gjstatus = 2 OR gj.gjstatus = 3 OR gj.gjstatus = 4 OR gj.gjstatus = 7) AND gj.gjid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("gjsumber")
            noTransaksi = drutama("gjnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT & KREDIT ---------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            For Each drdetail As DataRow In dtdetail.Rows
                urutan = Val(drdetail("urutan"))
                'JIKA DEBIT <> 0 MAKA JURNAL SISI DEBIT
                If Double.Parse(drdetail("debit")) <> 0 Then
                    debitkredit = 0
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("norek").ToString, "AKUN DEBIT", Double.Parse(drdetail("debit")), Double.Parse(drdetail("debitvalas")), debitkredit, drutama("gjcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If

                    'JIKA KREDIT <> 0 MAKA JURNAL SISI KREDIT
                Else
                    debitkredit = 1
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("norek").ToString, "AKUN KREDIT", Double.Parse(drdetail("kredit")), Double.Parse(drdetail("kreditvalas")), debitkredit, drutama("gjcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If

                End If
            Next
            'END OF AKUN DEBIT & KREDIT --------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("gjcabang")) & "', '" & FixQuotes(drutama("gjlokasi")) & "', '" & FixQuotes(drutama("gjsumber")) & "', " & 0 & ", " & drutama("gjid") & ", '" & FixQuotes(drutama("gjnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("gjtgl"))) & "', " & drutama("gjkodepa") & ", " & drutama("gjkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("gjuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("gjmatauang")) & "', '" & FixDouble(drutama("gjkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("gjtgllunas"))) & "', " & drutama("gjstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("gjjumlahbayar")) & "', " & drutama("gjstatusbayar") & ", " & drutama("gjstatus") & ", 1, NOW(), " & drutama("gjjmlrevisi") & ", " & drutama("gjcetakanke") & ", " & drutama("gjinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("gjinputtgl"), formatTglWaktuDB)) & "', " & drutama("gjmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("gjmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("gjcabang")) & "', '" & FixQuotes(drutama("gjlokasi")) & "', '" & FixQuotes(drutama("gjsumber")) & "', " & 0 & ", " & drutama("gjid") & ", '" & FixQuotes(drutama("gjnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("gjtgl"))) & "', " & drutama("gjkodepa") & ", " & drutama("gjkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("gjuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("gjmatauang")) & "', '" & FixDouble(drutama("gjkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("gjtgllunas"))) & "', " & drutama("gjstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("gjjumlahbayar")) & "', " & drutama("gjstatusbayar") & ", " & drutama("gjstatus") & ", 1, NOW(), " & drutama("gjjmlrevisi") & ", " & drutama("gjcetakanke") & ", " & drutama("gjinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("gjinputtgl"), formatTglWaktuDB)) & "', " & drutama("gjmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("gjmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'GJ' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING GJ
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m2_gj SET gjposting = 1, gjpostingtgl = NOW() WHERE gjid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M2_Rg"
    Public Function M2_Rg(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'BANK (+D)
        '   PIUTANG GIRO/BATAL/TOLAKAN (-K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT rg.* FROM m2_rg rg WHERE (rg.rgstatus = 2 OR rg.rgstatus = 3 OR rg.rgstatus = 4 OR rg.rgstatus = 7) AND rg.rgid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT rgd.*, gl.glrekgiro FROM m2_rg_detail rgd JOIN m2_giro_list gl ON rgd.nogiro = gl.glnogiro JOIN m2_rg rg ON rgd.idrg = rg.rgid WHERE (rg.rgstatus = 2 OR rg.rgstatus = 3 OR rg.rgstatus = 4 OR rg.rgstatus = 7) AND rg.rgid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("rgsumber")
            noTransaksi = drutama("rgnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'PROSES JURNAL ---------------------------------------
            For Each drdetail As DataRow In dtdetail.Rows
                'AKUN DEBIT ~~~~~~~~~~~~~~~~~~~~~~~~~
                'DATA DIAMBILKAN DARI TRANSAKSI DETAIL (rekbank)
                debitkredit = 0

                'GROUPING AKUN DEBIT
                filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekbank").ToString & "'"
                nominal = Double.Parse(drdetail("jumlah"))
                nominalvalas = Double.Parse(drdetail("jumlahvalas"))
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If

                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekbank").ToString, "BANK", nominal, nominalvalas, debitkredit, drutama("rgcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
                'END OF AKUN DEBIT ~~~~~~~~~~~~~~~~~~

                'AKUN KREDIT ~~~~~~~~~~~~~~~~~~~~~~~~
                'DATA DIAMBILKAN DARI TRANSAKSI DETAIL (glrekgiro)
                debitkredit = 1

                'GROUPING AKUN KREDIT
                filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("glrekgiro").ToString & "'"
                nominal = Double.Parse(drdetail("jumlah"))
                nominalvalas = Double.Parse(drdetail("jumlahvalas"))
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("glrekgiro").ToString, "PIUTANG GIRO/BATAL/TOLAKAN", nominal, nominalvalas, debitkredit, drutama("rgcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
                'END OF AKUN KREDIT ~~~~~~~~~~~~~~~~~
            Next
            'END OF PROSES JURNAL --------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit asc, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("rgcabang")) & "', '" & FixQuotes(drutama("rglokasi")) & "', '" & FixQuotes(drutama("rgsumber")) & "', " & 0 & ", " & drutama("rgid") & ", '" & FixQuotes(drutama("rgnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("rgtgl"))) & "', " & drutama("rgkodepa") & ", " & drutama("rgkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("rguraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("rgmatauang")) & "', '" & FixDouble(drutama("rgkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & 0 & "', " & 0 & ", " & drutama("rgstatus") & ", 1, NOW(), " & drutama("rgjmlrevisi") & ", " & drutama("rgcetakanke") & ", " & drutama("rginputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rginputtgl"), formatTglWaktuDB)) & "', " & drutama("rgmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rgmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("rgcabang")) & "', '" & FixQuotes(drutama("rglokasi")) & "', '" & FixQuotes(drutama("rgsumber")) & "', " & 0 & ", " & drutama("rgid") & ", '" & FixQuotes(drutama("rgnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("rgtgl"))) & "', " & drutama("rgkodepa") & ", " & drutama("rgkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("rguraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("rgmatauang")) & "', '" & FixDouble(drutama("rgkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & 0 & "', " & 0 & ", " & drutama("rgstatus") & ", 1, NOW(), " & drutama("rgjmlrevisi") & ", " & drutama("rgcetakanke") & ", " & drutama("rginputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rginputtgl"), formatTglWaktuDB)) & "', " & drutama("rgmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rgmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'RG' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING RG
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m2_rg SET rgposting = 1, rgpostingtgl = NOW() WHERE rgid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M2_Sg"
    Public Function M2_Sg(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'HUTANG GIRO/BATAL/TOLAKAN (-D)
        '                           BANK (-K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT sg.* FROM m2_sg sg WHERE (sg.sgstatus = 2 OR sg.sgstatus = 3 OR sg.sgstatus = 4 OR sg.sgstatus = 7) AND sg.sgid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT sgd.*, gl.glrekgiro FROM m2_sg_detail sgd JOIN m2_giro_list gl ON sgd.nogiro = gl.glnogiro JOIN m2_sg sg ON sgd.idsg = sg.sgid WHERE (sg.sgstatus = 2 OR sg.sgstatus = 3 OR sg.sgstatus = 4 OR sg.sgstatus = 7) AND sg.sgid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("sgsumber")
            noTransaksi = drutama("sgnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'PROSES JURNAL ---------------------------------------
            For Each drdetail As DataRow In dtdetail.Rows
                'AKUN DEBIT ~~~~~~~~~~~~~~~~~~~~~~~~~
                'DATA DIAMBILKAN DARI TRANSAKSI DETAIL (glrekgiro)
                debitkredit = 0

                'GROUPING AKUN DEBIT
                filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("glrekgiro").ToString & "'"
                nominal = Double.Parse(drdetail("jumlah"))
                nominalvalas = Double.Parse(drdetail("jumlahvalas"))
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("glrekgiro").ToString, "HUTANG GIRO/BATAL/TOLAKAN", nominal, nominalvalas, debitkredit, drutama("sgcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
                'END OF AKUN DEBIT ~~~~~~~~~~~~~~~~~~

                'AKUN KREDIT ~~~~~~~~~~~~~~~~~~~~~~~~
                'DATA DIAMBILKAN DARI TRANSAKSI DETAIL (rekbank)
                debitkredit = 1

                'GROUPING AKUN KREDIT
                filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekbank").ToString & "'"
                nominal = Double.Parse(drdetail("jumlah"))
                nominalvalas = Double.Parse(drdetail("jumlahvalas"))
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekbank").ToString, "BANK", nominal, nominalvalas, debitkredit, drutama("sgcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
                'END OF AKUN KREDIT ~~~~~~~~~~~~~~~~~
            Next
            'END OF PROSES JURNAL --------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("sgcabang")) & "', '" & FixQuotes(drutama("sglokasi")) & "', '" & FixQuotes(drutama("sgsumber")) & "', " & 0 & ", " & drutama("sgid") & ", '" & FixQuotes(drutama("sgnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("sgtgl"))) & "', " & drutama("sgkodepa") & ", " & drutama("sgkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("sguraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("sgmatauang")) & "', '" & FixDouble(drutama("sgkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & 0 & "', " & 0 & ", " & drutama("sgstatus") & ", 1, NOW(), " & drutama("sgjmlrevisi") & ", " & drutama("sgcetakanke") & ", " & drutama("sginputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("sginputtgl"), formatTglWaktuDB)) & "', " & drutama("sgmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("sgmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("sgcabang")) & "', '" & FixQuotes(drutama("sglokasi")) & "', '" & FixQuotes(drutama("sgsumber")) & "', " & 0 & ", " & drutama("sgid") & ", '" & FixQuotes(drutama("sgnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("sgtgl"))) & "', " & drutama("sgkodepa") & ", " & drutama("sgkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("sguraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("sgmatauang")) & "', '" & FixDouble(drutama("sgkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & 0 & "', " & 0 & ", " & drutama("sgstatus") & ", 1, NOW(), " & drutama("sgjmlrevisi") & ", " & drutama("sgcetakanke") & ", " & drutama("sginputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("sginputtgl"), formatTglWaktuDB)) & "', " & drutama("sgmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("sgmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'SG' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SG
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m2_sg SET sgposting = 1, sgpostingtgl = NOW() WHERE sgid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M2_Rgc"
    Public Function M2_Rgc(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'PIUTANG GIRO BATAL/TOLAKAN (+D)
        '                       PIUTANG GIRO (-K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT rgc.* FROM m2_rgc rgc WHERE (rgc.rgcstatus = 2 OR rgc.rgcstatus = 3 OR rgc.rgcstatus = 4 OR rgc.rgcstatus = 7) AND rgc.rgcid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT rgcd.* FROM m2_rgc_detail rgcd JOIN m2_rgc rgc ON rgcd.idrgc = rgc.rgcid WHERE (rgc.rgcstatus = 2 OR rgc.rgcstatus = 3 OR rgc.rgcstatus = 4 OR rgc.rgcstatus = 7) AND rgc.rgcid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("rgcsumber")
            noTransaksi = drutama("rgcnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT ------------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            debitkredit = 0
            For Each drdetail As DataRow In dtdetail.Rows
                'GROUPING AKUN DEBIT
                filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekgiro").ToString & "'"
                nominal = Double.Parse(drdetail("jumlah"))
                nominalvalas = Double.Parse(drdetail("jumlahvalas"))
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    urutan = urutan + 1
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekgiro").ToString, "PIUTANG GIRO BATAL/TOLAKAN", nominal, nominalvalas, debitkredit, drutama("rgccatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            Next
            'END OF AKUN DEBIT -----------------------------------

            'AKUN KREDIT -----------------------------------------
            'AMBIL REKENING GIRO MASUK DARI M0_SETTING UNTUK JURNAL SISI KREDIT
            Dim dtRekPiutangGiro As DataTable = AsDataTableAmbilDariDB("SELECT snilai FROM m0_setting WHERE smodule=0 AND sgrup='akun' AND skode='GiroMasuk'", strCon)
            Dim rekPiutangGiro As String = ""
            If dtRekPiutangGiro.Rows.Count > 0 Then
                rekPiutangGiro = dtRekPiutangGiro.Rows(0)(0).ToString
            Else
                rsErrMessage = "Setting Giro Out CoA not found." : GoTo selesai
            End If

            'DATA DIAMBILKAN DARI TRANSAKSI UTAMA
            debitkredit = 1
            urutan = urutan + 1
            If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                  String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekPiutangGiro, "PIUTANG GIRO", Double.Parse(drutama("rgcjumlah")), Double.Parse(drutama("rgcjumlahvalas")), debitkredit, drutama("rgccatatan").ToString, "", "", "", "", urutan)) = False Then
                rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            End If
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("rgccabang")) & "', '" & FixQuotes(drutama("rgclokasi")) & "', '" & FixQuotes(drutama("rgcsumber")) & "', " & 0 & ", " & drutama("rgcid") & ", '" & FixQuotes(drutama("rgcnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("rgctgl"))) & "', " & drutama("rgckodepa") & ", " & drutama("rgckontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("rgcuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("rgcmatauang")) & "', '" & FixDouble(drutama("rgckurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', " & 0 & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & 0 & "', " & 0 & ", " & drutama("rgcstatus") & ", 1, NOW(), " & drutama("rgcjmlrevisi") & ", " & drutama("rgccetakanke") & ", " & drutama("rgcinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rgcinputtgl"), formatTglWaktuDB)) & "', " & drutama("rgcmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rgcmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("rgccabang")) & "', '" & FixQuotes(drutama("rgclokasi")) & "', '" & FixQuotes(drutama("rgcsumber")) & "', " & 0 & ", " & drutama("rgcid") & ", '" & FixQuotes(drutama("rgcnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("rgctgl"))) & "', " & drutama("rgckodepa") & ", " & drutama("rgckontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("rgcuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("rgcmatauang")) & "', '" & FixDouble(drutama("rgckurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', " & 0 & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & 0 & "', " & 0 & ", " & drutama("rgcstatus") & ", 1, NOW(), " & drutama("rgcjmlrevisi") & ", " & drutama("rgccetakanke") & ", " & drutama("rgcinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rgcinputtgl"), formatTglWaktuDB)) & "', " & drutama("rgcmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rgcmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'RGC' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING RGC
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m2_rgc SET rgcposting = 1, rgcpostingtgl = NOW() WHERE rgcid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M2_Sgc"
    Public Function M2_Sgc(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'HUTANG GIRO (-D)
        '       HUTANG GIRO BATAL/TOLAKAN (+K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT sgc.* FROM m2_sgc sgc WHERE (sgc.sgcstatus = 2 OR sgc.sgcstatus = 3 OR sgc.sgcstatus = 4 OR sgc.sgcstatus = 7) AND sgc.sgcid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT sgcd.* FROM m2_sgc_detail sgcd JOIN m2_sgc sgc ON sgcd.idsgc = sgc.sgcid WHERE (sgc.sgcstatus = 2 OR sgc.sgcstatus = 3 OR sgc.sgcstatus = 4 OR sgc.sgcstatus = 7) AND sgc.sgcid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("sgcsumber")
            noTransaksi = drutama("sgcnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT ------------------------------------------
            'AMBIL REKENING GIRO KELUAR DARI M0_SETTING UNTUK JURNAL SISI DEBIT
            Dim dtRekHutangGiro As DataTable = AsDataTableAmbilDariDB("SELECT snilai FROM m0_setting WHERE smodule=0 AND sgrup='akun' AND skode='GiroKeluar'", strCon)
            Dim rekHutangGiro As String = ""
            If dtRekHutangGiro.Rows.Count > 0 Then
                rekHutangGiro = dtRekHutangGiro.Rows(0)(0).ToString
            Else
                rsErrMessage = "Setting Giro Out CoA not found." : GoTo selesai
            End If

            'DATA DIAMBILKAN DARI TRANSAKSI UTAMA
            debitkredit = 0
            urutan = 1
            If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                  String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekHutangGiro, "HUTANG GIRO", Double.Parse(drutama("sgcjumlah")), Double.Parse(drutama("sgcjumlahvalas")), debitkredit, drutama("sgccatatan").ToString, "", "", "", "", urutan)) = False Then
                rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            End If
            'END OF AKUN DEBIT -----------------------------------

            'AKUN KREDIT -----------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            debitkredit = 1
            For Each drdetail As DataRow In dtdetail.Rows

                'GROUPING AKUN KREDIT
                filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekgiro").ToString & "'"
                nominal = Double.Parse(drdetail("jumlah"))
                nominalvalas = Double.Parse(drdetail("jumlahvalas"))
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    urutan = urutan + 1
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekgiro").ToString, "HUTANG GIRO BATAL/TOLAKAN", nominal, nominalvalas, debitkredit, drutama("sgccatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            Next
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("sgccabang")) & "', '" & FixQuotes(drutama("sgclokasi")) & "', '" & FixQuotes(drutama("sgcsumber")) & "', " & 0 & ", " & drutama("sgcid") & ", '" & FixQuotes(drutama("sgcnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("sgctgl"))) & "', " & drutama("sgckodepa") & ", " & drutama("sgckontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("sgcuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("sgcmatauang")) & "', '" & FixDouble(drutama("sgckurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', " & 0 & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & 0 & "', " & 0 & ", " & drutama("sgcstatus") & ", 1, NOW(), " & drutama("sgcjmlrevisi") & ", " & drutama("sgccetakanke") & ", " & drutama("sgcinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("sgcinputtgl"), formatTglWaktuDB)) & "', " & drutama("sgcmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("sgcmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("sgccabang")) & "', '" & FixQuotes(drutama("sgclokasi")) & "', '" & FixQuotes(drutama("sgcsumber")) & "', " & 0 & ", " & drutama("sgcid") & ", '" & FixQuotes(drutama("sgcnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("sgctgl"))) & "', " & drutama("sgckodepa") & ", " & drutama("sgckontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("sgcuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("sgcmatauang")) & "', '" & FixDouble(drutama("sgckurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', " & 0 & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & 0 & "', " & 0 & ", " & drutama("sgcstatus") & ", 1, NOW(), " & drutama("sgcjmlrevisi") & ", " & drutama("sgccetakanke") & ", " & drutama("sgcinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("sgcinputtgl"), formatTglWaktuDB)) & "', " & drutama("sgcmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("sgcmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'SGC' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SGC
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m2_sgc SET sgcposting = 1, sgcpostingtgl = NOW() WHERE sgcid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M2_Cb"
    Public Function M2_Cb(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'AKUN DEBIT (D)
        '         AKUN KREDIT (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT cb.* FROM m2_cb cb WHERE (cb.cbstatus = 2 OR cb.cbstatus = 3 OR cb.cbstatus = 4 OR cb.cbstatus = 7) AND cb.cbid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT cbd.* FROM m2_cb_detail cbd JOIN m2_cb cb ON cbd.idcb = cb.cbid WHERE (cb.cbstatus = 2 OR cb.cbstatus = 3 OR cb.cbstatus = 4 OR cb.cbstatus = 7) AND cb.cbid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("cbsumber")
            noTransaksi = drutama("cbnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT & KREDIT ---------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            For Each drdetail As DataRow In dtdetail.Rows
                urutan = Val(drdetail("urutan"))
                'JIKA DEBIT <> 0 MAKA JURNAL SISI DEBIT
                If Double.Parse(drdetail("debit")) <> 0 Then
                    debitkredit = 0
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("norek").ToString, "AKUN DEBIT", Double.Parse(drdetail("debit")), Double.Parse(drdetail("debitvalas")), debitkredit, drutama("cbcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If

                    'JIKA KREDIT <> 0 MAKA JURNAL SISI KREDIT
                Else
                    debitkredit = 1
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("norek").ToString, "AKUN KREDIT", Double.Parse(drdetail("kredit")), Double.Parse(drdetail("kreditvalas")), debitkredit, drutama("cbcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If

                End If
            Next
            'END OF AKUN DEBIT & KREDIT --------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("cbcabang")) & "', '" & FixQuotes(drutama("cblokasi")) & "', '" & FixQuotes(drutama("cbsumber")) & "', " & 0 & ", " & drutama("cbid") & ", '" & FixQuotes(drutama("cbnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("cbtgl"))) & "', " & drutama("cbkodepa") & ", " & drutama("cbkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("cburaian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("cbmatauang")) & "', '" & FixDouble(drutama("cbkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("cbtgllunas"))) & "', " & drutama("cbstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("cbjumlahbayar")) & "', " & drutama("cbstatusbayar") & ", " & drutama("cbstatus") & ", 1, NOW(), " & drutama("cbjmlrevisi") & ", " & drutama("cbcetakanke") & ", " & drutama("cbinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("cbinputtgl"), formatTglWaktuDB)) & "', " & drutama("cbmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("cbmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("cbcabang")) & "', '" & FixQuotes(drutama("cblokasi")) & "', '" & FixQuotes(drutama("cbsumber")) & "', " & 0 & ", " & drutama("cbid") & ", '" & FixQuotes(drutama("cbnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("cbtgl"))) & "', " & drutama("cbkodepa") & ", " & drutama("cbkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("cburaian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("cbmatauang")) & "', '" & FixDouble(drutama("cbkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("cbtgllunas"))) & "', " & drutama("cbstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("cbjumlahbayar")) & "', " & drutama("cbstatusbayar") & ", " & drutama("cbstatus") & ", 1, NOW(), " & drutama("cbjmlrevisi") & ", " & drutama("cbcetakanke") & ", " & drutama("cbinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("cbinputtgl"), formatTglWaktuDB)) & "', " & drutama("cbmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("cbmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'CB' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING CB
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m2_cb SET cbposting = 1, cbpostingtgl = NOW() WHERE cbid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M2_Jm"
    Public Function M2_Jm(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'AKUN DEBIT (D)
        '         AKUN KREDIT (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)
        AsDataTableTambahField(dtjurnal, "kontak", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT jm.* FROM m2_jm jm WHERE (jm.jmstatus = 2 OR jm.jmstatus = 3 OR jm.jmstatus = 4 OR jm.jmstatus = 7) AND jm.jmid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT jmd.* FROM m2_jm_detail jmd JOIN m2_jm jm ON jmd.idjm = jm.jmid WHERE (jm.jmstatus = 2 OR jm.jmstatus = 3 OR jm.jmstatus = 4 OR jm.jmstatus = 7) AND jm.jmid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("jmsumber")
            noTransaksi = drutama("jmnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT & KREDIT ---------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            For Each drdetail As DataRow In dtdetail.Rows
                urutan = Val(drdetail("urutan"))
                'JIKA DEBIT <> 0 MAKA JURNAL SISI DEBIT
                If Double.Parse(drdetail("debit")) <> 0 Then
                    debitkredit = 0
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan~kontak", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}~{11}", drdetail("norek").ToString, "AKUN DEBIT", Double.Parse(drdetail("debit")), Double.Parse(drdetail("debitvalas")), debitkredit, drutama("jmcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan, Val(drdetail("kontak")))) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If

                    'JIKA KREDIT <> 0 MAKA JURNAL SISI KREDIT
                Else
                    debitkredit = 1
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan~kontak", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}~{11}", drdetail("norek").ToString, "AKUN KREDIT", Double.Parse(drdetail("kredit")), Double.Parse(drdetail("kreditvalas")), debitkredit, drutama("jmcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan, Val(drdetail("kontak")))) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If

                End If
            Next
            'END OF AKUN DEBIT & KREDIT --------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder
        Dim nomer As Integer, drdetail2 As DataRow

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")
        nomer = 0
        For Each drjurnal As DataRow In dtjurnal.Rows
            drdetail2 = dtdetail.Rows(nomer)
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("jmcabang")) & "', '" & FixQuotes(drutama("jmlokasi")) & "', '" & FixQuotes(drutama("jmsumber")) & "', " & 0 & ", " & drutama("jmid") & ", '" & FixQuotes(drutama("jmnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("jmtgl"))) & "', " & drutama("jmkodepa") & ", " & drjurnal("kontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("jmuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("jmmatauang")) & "', '" & FixDouble(drutama("jmkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("jmtgllunas"))) & "', " & drutama("jmstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("jmjumlahbayar")) & "', " & drutama("jmstatusbayar") & ", " & drutama("jmstatus") & ", 1, NOW(), " & drutama("jmjmlrevisi") & ", " & drutama("jmcetakanke") & ", " & drutama("jminputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("jminputtgl"), formatTglWaktuDB)) & "', " & drutama("jmmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("jmmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang, ttgljatuhtempo,                                 ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("jmcabang")) & "', '" & FixQuotes(drutama("jmlokasi")) & "', '" & FixQuotes(drutama("jmsumber")) & "', " & 0 & ", " & drutama("jmid") & ", '" & FixQuotes(drutama("jmnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("jmtgl"))) & "', " & drutama("jmkodepa") & ", " & drjurnal("kontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("jmuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("jmmatauang")) & "', '" & FixDouble(drutama("jmkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '" & FixQuotes(AsFormatTanggal(drutama("jmtgllunas"))) & "', " & drutama("jmstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("jmjumlahbayar")) & "', " & drutama("jmstatusbayar") & ", " & drutama("jmstatus") & ", 1, NOW(), " & drutama("jmjmlrevisi") & ", " & drutama("jmcetakanke") & ", " & drutama("jminputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("jminputtgl"), formatTglWaktuDB)) & "', " & drutama("jmmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("jmmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
            nomer = nomer + 1
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'JM' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING JM
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m2_jm SET jmposting = 1, jmpostingtgl = NOW() WHERE jmid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

    '********************************************** M3 **********************************************

#Region "M3_Sa"
    Public Function M3_Sa(ByVal idtransaksi As Integer) As String 'progress?errMessage?sqljurnal?sqlupdateposting
        'SA MASUK :
        'PERSEDIAAN (D)
        '         AKUN LAWAN (K)
        'SA KELUAR :
        'AKUN LAWAN (D)
        '         PERSEDIAAN (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = ""
        Dim sumber As String = "", noTransaksi As String = "", filter As String = ""
        Dim sql As String = "", idutama As Double = 0, iddetail As Double = 0

        Dim dtutama As New DataTable, dtDetail As New DataTable
        Dim drutama As DataRow, dtSaldo As New DataTable, dt As New DataTable
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0
        Dim sqlPosting As String = "", sqlJurnal As String = ""

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)


        'AMBIL DATA DARI SETTING ---------------------------------
        Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs')", strCon)
        'MATAUANG
        Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
        If matauang = "Not found" Then
            rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
        End If
        'KURS
        Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
        If kurs = "Not found" Then
            rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
        End If
        'END OF AMBIL DATA DARI SETTING --------------------------


        'AMBIL DATA ----------------------------------------------
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT sa.* FROM m3_sa sa WHERE (sa.sastatus = 2 OR sa.sastatus = 3 OR sa.sastatus = 4 OR sa.sastatus = 7) AND sa.said = '" & idtransaksi & "'", strCon)
        'END OF AMBIL DATA ---------------------------------------


        'SET DATA UTAMA ====================================================
        If dtutama.Rows.Count > 0 Then

            'SET DATA UTAMA --------------------------------------
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            idutama = drutama("said")
            sumber = drutama("sasumber")
            noTransaksi = drutama("sanotransaksi")
            'END OF SET DATA UTAMA -------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF SET DATA UTAMA =============================================


        'BUAT JURNAL HPP PERSEDIAAN ========================================
        'AMBIL DATA DETAIL YANG BARU UNTUK UPDATE TRANSAKSI BARANG DAN JURNAL
        dtDetail = AsDataTableAmbilDariDB("SELECT sad.* FROM m3_sa_detail sad JOIN m3_sa sa ON sad.idsa = sa.said WHERE (sa.sastatus = 2 OR sa.sastatus = 3 OR sa.sastatus = 4 OR sa.sastatus = 7) AND sa.said = '" & idtransaksi & "'", strCon)

        If dtDetail.Rows.Count > 0 Then

            'AKUN DEBIT & KREDIT ---------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            For Each drdetail As DataRow In dtDetail.Rows

                'JIKA jmlmasuk > 0 MAKA JURNAL SA MASUK
                If Double.Parse(drdetail("jmlbarangmasuk")) > 0 Then
                    'AKUN DEBIT ~~~~~~~~~~~~~~~~~~~~~~~~~
                    debitkredit = 0
                    'GROUPING AKUN DEBIT (rekpersediaan)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekpersediaan").ToString & "'"
                    'NOMINAL = HPP * JML
                    nominal = Double.Parse(drdetail("hpp")) * Double.Parse(drdetail("jmlbarangmasuk"))
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal", nominal) = False Then
                            rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekpersediaan").ToString, "PERSEDIAAN", nominal, nominalvalas, debitkredit, drutama("sacatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If
                    'END OF AKUN DEBIT ~~~~~~~~~~~~~~~~~~

                    'AKUN KREDIT ~~~~~~~~~~~~~~~~~~~~~~~~
                    debitkredit = 1
                    'GROUPING AKUN KREDIT (reklawan)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("reklawan").ToString & "'"
                    'NOMINAL = HPP * JML
                    nominal = Double.Parse(drdetail("hpp")) * Double.Parse(drdetail("jmlbarangmasuk"))
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal", nominal) = False Then
                            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("reklawan").ToString, "AKUN LAWAN", nominal, nominalvalas, debitkredit, drutama("sacatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If
                    'END OF AKUN KREDIT ~~~~~~~~~~~~~~~~~


                    'JIKA jmlkeluar > 0 MAKA JURNAL SA KELUAR
                Else
                    'AKUN DEBIT ~~~~~~~~~~~~~~~~~~~~~~~~~
                    debitkredit = 0
                    'GROUPING AKUN DEBIT (reklawan)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("reklawan").ToString & "'"
                    'NOMINAL = HPP * JML
                    nominal = Double.Parse(drdetail("hpp")) * Double.Parse(drdetail("jmlbarangkeluar"))
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal", nominal) = False Then
                            rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("reklawan").ToString, "AKUN LAWAN", nominal, nominalvalas, debitkredit, drutama("sacatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If
                    'END OF AKUN DEBIT ~~~~~~~~~~~~~~~~~~

                    'AKUN KREDIT ~~~~~~~~~~~~~~~~~~~~~~~~
                    debitkredit = 1
                    'GROUPING AKUN KREDIT (rekpersediaan)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekpersediaan").ToString & "'"
                    'NOMINAL = HPP * JML
                    nominal = Double.Parse(drdetail("hpp")) * Double.Parse(drdetail("jmlbarangkeluar"))
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal", nominal) = False Then
                            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekpersediaan").ToString, "PERSEDIAAN", nominal, nominalvalas, debitkredit, drutama("sacatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If
                    'END OF AKUN KREDIT ~~~~~~~~~~~~~~~~~

                End If
            Next
            'END OF AKUN DEBIT & KREDIT --------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF BUAT JURNAL HPP PERSEDIAAN =================================


        'BUAT SQL ==========================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,             tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo,   ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("sacabang")) & "', '" & FixQuotes(drutama("salokasi")) & "', '" & FixQuotes(drutama("sasumber")) & "', " & 0 & ", " & drutama("said") & ", '" & FixQuotes(drutama("sanotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("satgl"))) & "', " & drutama("sakodepa") & ", " & drutama("sabagiansa") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("sauraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(matauang) & "', '" & FixDouble(Double.Parse(kurs)) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', 0, '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("sastatus") & ", 1, NOW(), " & drutama("sajmlrevisi") & ", " & drutama("sacetakanke") & ", " & drutama("sainputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("sainputtgl"), formatTglWaktuDB)) & "', " & drutama("samodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("samodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,              tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang, ttgljatuhtempo,  ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("sacabang")) & "', '" & FixQuotes(drutama("salokasi")) & "', '" & FixQuotes(drutama("sasumber")) & "', " & 0 & ", " & drutama("said") & ", '" & FixQuotes(drutama("sanotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("satgl"))) & "', " & drutama("sakodepa") & ", " & drutama("sabagiansa") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("sauraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(matauang) & "', '" & FixDouble(Double.Parse(kurs)) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', 0, '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("sastatus") & ", 1, NOW(), " & drutama("sajmlrevisi") & ", " & drutama("sacetakanke") & ", " & drutama("sainputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("sainputtgl"), formatTglWaktuDB)) & "', " & drutama("samodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("samodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'HAPUS JURNAL LAMA
        Dim sqlHapus As String = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'SA' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'BUAT SQL JURNAL
        If Len(strValue.ToString) > 0 Then
            sqlJurnal = "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & ""
        End If

        'UPDATE STATUS POSTING JURNAL TRANSAKSI BARANG
        Dim sqlPostingIT As String = "UPDATE M1_Item_Transaction SET postingjurnal = 1 WHERE sumber = '" & sumber & "' AND idutama = '" & idutama & "'"

        'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SA
        sqlPosting = "UPDATE m3_sa SET saposting = 1, sapostingtgl = NOW() WHERE said = '" & idtransaksi & "'"


        'GABUNGKAN VALUE SQL
        rsSql = String.Concat(sqlHapus, sptRow, sqlJurnal, sptRow, sqlPostingIT, sptRow, sqlPosting)
        'END OF BUAT SQL ===================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M3_Ib"
    Public Function M3_Ib(ByVal idtransaksi As Integer) As String 'progress?errMessage?sqljurnal?sqlupdateposting
        'PERSEDIAAN (D)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = ""
        Dim sumber As String = "", noTransaksi As String = "", filter As String = ""
        Dim sql As String = "", idutama As Double = 0, iddetail As Double = 0

        Dim dtutama As New DataTable, dtDetail As New DataTable
        Dim drutama As DataRow, dtSaldo As New DataTable, dt As New DataTable
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0
        Dim sqlPosting As String = "", sqlJurnal As String = ""

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)


        'AMBIL DATA DARI SETTING ---------------------------------
        Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs')", strCon)
        'MATAUANG
        Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
        If matauang = "Not found" Then
            rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
        End If
        'KURS
        Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
        If kurs = "Not found" Then
            rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
        End If
        'END OF AMBIL DATA DARI SETTING --------------------------


        'AMBIL DATA ----------------------------------------------
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT Ib.* FROM M3_Ib Ib WHERE (Ib.Ibstatus = 2 OR Ib.Ibstatus = 3 OR Ib.Ibstatus = 4 OR Ib.Ibstatus = 7) AND Ib.Ibid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtDetail = AsDataTableAmbilDariDB("SELECT Ibd.*, i.bhpp FROM M3_Ib_detail Ibd JOIN M3_Ib Ib ON Ibd.idIb = Ib.Ibid JOIN m1_item i ON Ibd.idbarang = i.bid WHERE (Ib.Ibstatus = 2 OR Ib.Ibstatus = 3 OR Ib.Ibstatus = 4 OR Ib.Ibstatus = 7) AND Ib.Ibid = '" & idtransaksi & "'", strCon)


        'SET DATA UTAMA ====================================================
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            idutama = drutama("Ibid")
            sumber = drutama("Ibsumber")
            noTransaksi = drutama("Ibnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF SET DATA UTAMA =============================================


        'PROSES JURNAL BARANG MASUK ========================================
        'JIKA TERDAPAT DATA TRANSAKSI MAKA JURNAL HPP BARANG MASUK
        If dtDetail.Rows.Count > 0 Then

            For Each dr1 As DataRow In dtDetail.Rows

                'PROSES JURNAL ---------------------------------------
                'AKUN DEBIT ~~~~~~~~~~~~~~~~~~~~~~~~~
                debitkredit = 0

                'NOMINAL = jmlbarang * hpp * kurs
                nominal = Double.Parse(dr1("jmlbarang")) * Double.Parse(dr1("hpp")) * Double.Parse(dr1("kurs"))
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If dr1("matauang").ToString <> matauang Then
                    'NOMINAL VALAS = jmlbarang * hpp
                    nominalvalas = Double.Parse(dr1("jmlbarang")) * Double.Parse(dr1("hpp"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING AKUN DEBIT (rekpersediaan)
                filter = "debitkredit=" & debitkredit & " AND norek='" & dr1("rekpersediaan").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", dr1("rekpersediaan").ToString, "PERSEDIAAN", nominal, nominalvalas, debitkredit, drutama("Ibcatatan").ToString, dr1("costcenter").ToString, dr1("divisi").ToString, dr1("subdivisi").ToString, dr1("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
                'END OF AKUN DEBIT ~~~~~~~~~~~~~~~~~~
                'END OF PROSES JURNAL --------------------------------

            Next

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF PROSES JURNAL BARANG MASUK ===================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,ttgljatuhtempo,ttgllunas,tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("Ibcabang")) & "', '" & FixQuotes(drutama("Iblokasi")) & "', '" & FixQuotes(drutama("Ibsumber")) & "', " & 0 & ", " & drutama("Ibid") & ", '" & FixQuotes(drutama("Ibnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("Ibtgl"))) & "', " & drutama("Ibkodepa") & ", " & drutama("Ibbagianib") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("Iburaian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("Ibmatauang")) & "', '" & FixDouble(drutama("Ibkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("Ibstatus") & ", 1, NOW(), " & drutama("Ibjmlrevisi") & ", " & drutama("Ibcetakanke") & ", " & drutama("Ibinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("Ibinputtgl"), formatTglWaktuDB)) & "', " & drutama("Ibmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("Ibmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,ttgljatuhtempo,ttgllunas,tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("Ibcabang")) & "', '" & FixQuotes(drutama("Iblokasi")) & "', '" & FixQuotes(drutama("Ibsumber")) & "', " & 0 & ", " & drutama("Ibid") & ", '" & FixQuotes(drutama("Ibnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("Ibtgl"))) & "', " & drutama("Ibkodepa") & ", " & drutama("Ibbagianib") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("Iburaian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("Ibmatauang")) & "', '" & FixDouble(drutama("Ibkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("Ibstatus") & ", 1, NOW(), " & drutama("Ibjmlrevisi") & ", " & drutama("Ibcetakanke") & ", " & drutama("Ibinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("Ibinputtgl"), formatTglWaktuDB)) & "', " & drutama("Ibmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("Ibmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'HAPUS JURNAL LAMA
        Dim sqlHapus As String = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'IB' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'BUAT SQL JURNAL
        If Len(strValue.ToString) > 0 Then
            sqlJurnal = "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & ""
        End If

        'UPDATE STATUS POSTING JURNAL TRANSAKSI BARANG
        Dim sqlPostingIT As String = "UPDATE M1_Item_Transaction SET postingjurnal = 1, postinghpp = 1 WHERE sumber = '" & sumber & "' AND idutama = '" & idutama & "'"

        'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING
        sqlPosting = "UPDATE M3_Ib SET Ibposting = 1, Ibpostingtgl = NOW() WHERE Ibid = '" & idtransaksi & "'"

        'GABUNGKAN VALUE SQL
        rsSql = String.Concat(sqlHapus, sptRow, sqlJurnal, sptRow, sqlPostingIT, sptRow, sqlPosting)
        'END OF BUAT SQL ================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

    '********************************************** M4 **********************************************

#Region "M4_Ap"
    Public Function M4_Ap(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'AKUN UM PEMBELIAN (D)
        '           AKUN BAYAR (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT ap.* FROM m4_ap ap WHERE (ap.apstatus = 2 OR ap.apstatus = 3 OR ap.apstatus = 4 OR ap.apstatus = 7) AND ap.apid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT apd.* FROM m4_ap_pay apd JOIN m4_ap ap ON apd.idap = ap.apid WHERE (ap.apstatus = 2 OR ap.apstatus = 3 OR ap.apstatus = 4 OR ap.apstatus = 7) AND ap.apid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("apsumber")
            noTransaksi = drutama("apnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT ------------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI UTAMA
            debitkredit = 0
            urutan = 1
            If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                  String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("apnorek").ToString, "AKUN UM PEMBELIAN", Double.Parse(drutama("apjumlah")), Double.Parse(drutama("apjumlahvalas")), debitkredit, drutama("apcatatan").ToString, drutama("apcostcenter").ToString, drutama("apdivisi").ToString, drutama("apsubdivisi").ToString, drutama("approyek").ToString, urutan)) = False Then
                rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            End If
            'END OF AKUN DEBIT -----------------------------------

            'AKUN KREDIT -----------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            debitkredit = 1
            Dim rekBayar As String = ""
            For Each drdetail As DataRow In dtdetail.Rows
                urutan = Val(drdetail("urutan")) + 1

                'JIKA CARABAYAR GIRO(2) MAKA AMBIL AKUN BAYAR AMBIL DARI rekgiro, ELSE AKUN BAYAR AMBIL DARI rekbank
                If Double.Parse(drdetail("carabayar")) = 2 Then rekBayar = drdetail("rekgiro").ToString Else rekBayar = drdetail("rekbank").ToString

                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekBayar, "AKUN BAYAR", Double.Parse(drdetail("jumlah")), Double.Parse(drdetail("jumlahvalas")), debitkredit, drutama("apcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If
            Next
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                   ttgljatuhtempo,                                                   ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("apcabang")) & "', '" & FixQuotes(drutama("aplokasi")) & "', '" & FixQuotes(drutama("apsumber")) & "', " & 0 & ", " & drutama("apid") & ", '" & FixQuotes(drutama("apnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("aptgl"))) & "', " & drutama("apkodepa") & ", " & drutama("apkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("apuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("apmatauang")) & "', '" & FixDouble(drutama("apkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("aptgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("aptgllunas"))) & "', " & drutama("apstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("apjumlahbayar")) & "', " & drutama("apstatusbayar") & ", " & drutama("apstatus") & ", 1, NOW(), " & drutama("apjmlrevisi") & ", " & drutama("apcetakanke") & ", " & drutama("apinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("apinputtgl"), formatTglWaktuDB)) & "', " & drutama("apmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("apmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                   ttgljatuhtempo,                                                   ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("apcabang")) & "', '" & FixQuotes(drutama("aplokasi")) & "', '" & FixQuotes(drutama("apsumber")) & "', " & 0 & ", " & drutama("apid") & ", '" & FixQuotes(drutama("apnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("aptgl"))) & "', " & drutama("apkodepa") & ", " & drutama("apkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("apuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("apmatauang")) & "', '" & FixDouble(drutama("apkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("aptgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("aptgllunas"))) & "', " & drutama("apstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("apjumlahbayar")) & "', " & drutama("apstatusbayar") & ", " & drutama("apstatus") & ", 1, NOW(), " & drutama("apjmlrevisi") & ", " & drutama("apcetakanke") & ", " & drutama("apinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("apinputtgl"), formatTglWaktuDB)) & "', " & drutama("apmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("apmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'AP' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING AP
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m4_ap SET apposting = 1, appostingtgl = NOW() WHERE apid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M4_Grn"
    Public Function M4_Grn(ByVal idtransaksi As Integer) As String 'progress?errMessage?sqljurnal?sqlupdateposting
        'PERSEDIAAN (D)
        '         HUTANG SEMENTARA (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = ""
        Dim sumber As String = "", noTransaksi As String = "", filter As String = ""
        Dim sql As String = "", idutama As Double = 0, iddetail As Double = 0

        Dim dtutama As New DataTable, dtDetail As New DataTable
        Dim drutama As DataRow, dtSaldo As New DataTable, dt As New DataTable
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0
        Dim sqlPosting As String = "", sqlJurnal As String = ""

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)


        'AMBIL DATA DARI SETTING ---------------------------------
        Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'HutangSementara')", strCon)
        'MATAUANG
        Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
        If matauang = "Not found" Then
            rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
        End If
        'KURS
        Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
        If kurs = "Not found" Then
            rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
        End If
        'AKUN HUTANG SEMENTARA
        Dim rekHutangSementara As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'akun' AND skode = 'HutangSementara'", "Not found")
        If rekHutangSementara = "Not found" Then
            rsErrMessage = "Setting Temporary Account Payable CoA not found." : GoTo selesai
        End If
        'END OF AMBIL DATA DARI SETTING --------------------------


        'AMBIL DATA ----------------------------------------------
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT grn.* FROM m4_grn grn WHERE (grn.grnstatus = 2 OR grn.grnstatus = 3 OR grn.grnstatus = 4 OR grn.grnstatus = 7) AND grn.grnid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtDetail = AsDataTableAmbilDariDB("SELECT grnd.*, i.bhpp FROM m4_grn_detail grnd JOIN m4_grn grn ON grnd.idgrn = grn.grnid JOIN m1_item i ON grnd.idbarang = i.bid WHERE (grn.grnstatus = 2 OR grn.grnstatus = 3 OR grn.grnstatus = 4 OR grn.grnstatus = 7) AND grn.grnid = '" & idtransaksi & "'", strCon)


        'SET DATA UTAMA ====================================================
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            idutama = drutama("grnid")
            sumber = drutama("grnsumber")
            noTransaksi = drutama("grnnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF SET DATA UTAMA =============================================


        'PROSES JURNAL BARANG MASUK ========================================
        'JIKA TERDAPAT DATA TRANSAKSI MAKA SET JURNAL BARANG MASUK
        If dtDetail.Rows.Count > 0 Then

            For Each dr1 As DataRow In dtDetail.Rows

                'PROSES JURNAL ---------------------------------------
                'AKUN DEBIT ~~~~~~~~~~~~~~~~~~~~~~~~~
                debitkredit = 0

                'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                nominal = ((Double.Parse(dr1("jml")) * Double.Parse(dr1("harga"))) - Double.Parse(dr1("jmldiskon"))) * Double.Parse(dr1("kurs"))
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If dr1("matauang").ToString <> matauang Then
                    'NOMINAL VALAS = (((jml * harga) - jmldiskon)
                    nominalvalas = ((Double.Parse(dr1("jml")) * Double.Parse(dr1("harga"))) - Double.Parse(dr1("jmldiskon")))
                Else
                    nominalvalas = 0
                End If

                'GROUPING AKUN DEBIT (rekpersediaan)
                filter = "debitkredit=" & debitkredit & " AND norek='" & dr1("rekpersediaan").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", dr1("rekpersediaan").ToString, "PERSEDIAAN", nominal, nominalvalas, debitkredit, drutama("grncatatan").ToString, dr1("costcenter").ToString, dr1("divisi").ToString, dr1("subdivisi").ToString, dr1("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
                'END OF AKUN DEBIT ~~~~~~~~~~~~~~~~~~

                'AKUN KREDIT ~~~~~~~~~~~~~~~~~~~~~~~~
                debitkredit = 1

                'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                nominal = ((Double.Parse(dr1("jml")) * Double.Parse(dr1("harga"))) - Double.Parse(dr1("jmldiskon"))) * Double.Parse(dr1("kurs"))
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If dr1("matauang").ToString <> matauang Then
                    'NOMINAL VALAS = (((jml * harga) - jmldiskon)
                    nominalvalas = ((Double.Parse(dr1("jml")) * Double.Parse(dr1("harga"))) - Double.Parse(dr1("jmldiskon")))
                Else
                    nominalvalas = 0
                End If

                'GROUPING AKUN KREDIT (rekhutangsementara)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekHutangSementara & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekHutangSementara, "HUTANG SEMENTARA", nominal, nominalvalas, debitkredit, drutama("grncatatan").ToString, dr1("costcenter").ToString, dr1("divisi").ToString, dr1("subdivisi").ToString, dr1("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
                'END OF AKUN KREDIT ~~~~~~~~~~~~~~~~~
                'END OF PROSES JURNAL --------------------------------

            Next

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF PROSES JURNAL BARANG MASUK ===================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,ttgljatuhtempo,ttgllunas,tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("grncabang")) & "', '" & FixQuotes(drutama("grnlokasi")) & "', '" & FixQuotes(drutama("grnsumber")) & "', " & 0 & ", " & drutama("grnid") & ", '" & FixQuotes(drutama("grnnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("grntgl"))) & "', " & drutama("grnkodepa") & ", " & drutama("grnsupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("grnuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("grnmatauang")) & "', '" & FixDouble(drutama("grnkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("grnstatus") & ", 1, NOW(), " & drutama("grnjmlrevisi") & ", " & drutama("grncetakanke") & ", " & drutama("grninputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("grninputtgl"), formatTglWaktuDB)) & "', " & drutama("grnmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("grnmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,ttgljatuhtempo,ttgllunas,tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("grncabang")) & "', '" & FixQuotes(drutama("grnlokasi")) & "', '" & FixQuotes(drutama("grnsumber")) & "', " & 0 & ", " & drutama("grnid") & ", '" & FixQuotes(drutama("grnnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("grntgl"))) & "', " & drutama("grnkodepa") & ", " & drutama("grnsupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("grnuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("grnmatauang")) & "', '" & FixDouble(drutama("grnkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("grnstatus") & ", 1, NOW(), " & drutama("grnjmlrevisi") & ", " & drutama("grncetakanke") & ", " & drutama("grninputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("grninputtgl"), formatTglWaktuDB)) & "', " & drutama("grnmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("grnmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'HAPUS JURNAL LAMA
        Dim sqlHapus As String = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'GRN' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'BUAT SQL JURNAL
        If Len(strValue.ToString) > 0 Then
            sqlJurnal = "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & ""
        End If

        'UPDATE STATUS POSTING JURNAL TRANSAKSI BARANG
        Dim sqlPostingIT As String = "UPDATE M1_Item_Transaction SET postingjurnal = 1 WHERE sumber = '" & sumber & "' AND idutama = '" & idutama & "'"

        'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING
        sqlPosting = "UPDATE M4_Grn SET grnposting = 1, grnpostingtgl = NOW() WHERE grnid = '" & idtransaksi & "'"


        'GABUNGKAN VALUE SQL
        rsSql = String.Concat(sqlHapus, sptRow, sqlJurnal, sptRow, sqlPostingIT, sptRow, sqlPosting)
        'END OF BUAT SQL ================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M4_Ri"
    Public Function M4_Ri(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'HUTANG SEMENTARA (-D) ATAU PERSEDIAAN (D)
        'PPN MASUKAN1     (+D)
        'PPN MASUKAN2     (+D)
        'BIAYA LAIN       (+D)
        '           DISKON       (+K)
        '           HUTANG USAHA (+K)
        '           UM PEMBELIAN (-K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0, selisihKurs As Double = 0

        Dim rekSelisihKurs As String = "", matauang As String = "", kurs As String = ""

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT ri.* FROM m4_ri ri WHERE (ri.ristatus = 2 OR ri.ristatus = 3 OR ri.ristatus = 4 OR ri.ristatus = 7) AND ri.riid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT rid.*, i.brekpersediaan, IFNULL(pod.kurs,0) as pokurs, IFNULL(grnd.kurs,0) as grnkurs FROM m4_ri_detail rid JOIN m4_ri ri ON rid.idri = ri.riid JOIN m1_item i ON rid.idbarang = i.bid LEFT JOIN m4_po_detail pod ON rid.idpodetail=pod.idpodetail LEFT JOIN m4_grn_detail grnd ON rid.idgrndetail=grnd.idgrndetail WHERE (ri.ristatus = 2 OR ri.ristatus = 3 OR ri.ristatus = 4 OR ri.ristatus = 7) AND ri.riid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        'If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("risumber")
            noTransaksi = drutama("rinotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'HutangSementara') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'HutangUsaha') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'SelisihKurs')", strCon)
            'MATAUANG
            matauang = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            kurs = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN HUTANG SEMENTARA
            Dim rekHutangSementara As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'akun' AND skode = 'HutangSementara'", "Not found")
            If rekHutangSementara = "Not found" Then
                rsErrMessage = "Setting Temporary Account Payable CoA not found." : GoTo selesai
            End If
            'AKUN HUTANG USAHA
            Dim rekHutangUsaha As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'akun' AND skode = 'HutangUsaha'", "Not found")
            If rekHutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Payable CoA not found." : GoTo selesai
            End If
            'AKUN SELISIH KURS
            rekSelisihKurs = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'akun' AND skode = 'SelisihKurs'", "Not found")
            If rekSelisihKurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Difference CoA not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------

            Dim akunDebit As String = ""

            'AKUN DEBIT ------------------------------------------
            'HUTANG SEMENTARA DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            If dtdetail.Rows.Count > 0 Then
                For Each drdetail As DataRow In dtdetail.Rows
                    'AKUN HUTANG SEMENTARA ~~~~~~~~~~~~~~~~~~~~~
                    debitkredit = 0

                    'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                    If drutama("rimatauang").ToString <> matauang Then
                        'JIKA RI AMBIL DARI PO MAKA AMBIL KURS PO, JIKA RI AMBIL DARI GRN MAKA AMBIL KURS GRN
                        If Double.Parse(drdetail("idpodetail")) > 0 Then
                            'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                            nominal = ((Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))) * Double.Parse(drdetail("pokurs"))
                            'AKUN DEBIT = REKPERSEDIAAN
                            akunDebit = drdetail("brekpersediaan")

                        ElseIf Double.Parse(drdetail("idgrndetail")) > 0 Then
                            'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                            nominal = ((Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))) * Double.Parse(drdetail("grnkurs"))
                            'AKUN DEBIT = HUTANGSEMENTARA
                            akunDebit = rekHutangSementara

                        Else
                            'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                            nominal = ((Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))) * Double.Parse(drdetail("kurs"))
                            'AKUN DEBIT = REKPERSEDIAAN
                            akunDebit = drdetail("brekpersediaan")

                        End If
                        'NOMINAL VALAS = (jml * harga) - jmldiskon
                        nominalvalas = (Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))

                        'HITUNG SELISIH SELISIH KURS
                        'SELISIH KURS = NOMINAL RI - (NOMINAL RI VALAS * (KURS PO ATAU KURS GRN))
                        'JIKA RI AMBIL DARI PO MAKA AMBIL KURS PO, JIKA RI AMBIL DARI GRN MAKA AMBIL KURS GRN
                        If Double.Parse(drdetail("idpodetail")) > 0 Then
                            selisihKurs = selisihKurs + ((nominalvalas * Double.Parse(drdetail("kurs"))) - (nominalvalas * Double.Parse(drdetail("pokurs"))))
                        ElseIf Double.Parse(drdetail("idgrndetail")) > 0 Then
                            selisihKurs = selisihKurs + ((nominalvalas * Double.Parse(drdetail("kurs"))) - (nominalvalas * Double.Parse(drdetail("grnkurs"))))
                        End If

                        'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                    Else
                        'NOMINAL = (jml * harga) - jmldiskon
                        nominal = (Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))
                        'NOMINAL VALAS = 0 
                        nominalvalas = 0

                        'SET AKUN DEBIT, JIKA RI AMBIL DARI GRN MAKA HUTANG SEMENTARA, SELAIN ITU PERSEDIAAN
                        If Double.Parse(drdetail("idpodetail")) > 0 Then
                            'AKUN DEBIT = REKPERSEDIAAN
                            akunDebit = drdetail("brekpersediaan")
                        ElseIf Double.Parse(drdetail("idgrndetail")) > 0 Then
                            'AKUN DEBIT = HUTANGSEMENTARA
                            akunDebit = rekHutangSementara
                        Else
                            'AKUN DEBIT = REKPERSEDIAAN
                            akunDebit = drdetail("brekpersediaan")
                        End If

                    End If

                    'GROUPING AKUN DEBIT (akunDebit)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & akunDebit & "'"
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                            rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", akunDebit, "HUTANG SEMENTARA/PERSEDIAAN", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If

                    'END OF AKUN HUTANG SEMENTARA ~~~~~~~~~~~~~~
                Next
            End If
            

            'PPN MASUKAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = ritotalpajak1detail * kurs
            nominal = Double.Parse(drutama("ritotalpajak1detail")) * Double.Parse(drutama("rikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("rimatauang").ToString <> matauang Then
                    'NOMINAL VALAS = ritotalpajak1detail
                    nominalvalas = Double.Parse(drutama("ritotalpajak1detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN MASUKAN1 (rirekpajak1)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("rirekpajak1").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("rirekpajak1").ToString, "PPN MASUKAN1", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN MASUKAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~

            'PPN MASUKAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = ritotalpajak2detail * kurs
            nominal = Double.Parse(drutama("ritotalpajak2detail")) * Double.Parse(drutama("rikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("rimatauang").ToString <> matauang Then
                    'NOMINAL VALAS = ritotalpajak2detail
                    nominalvalas = Double.Parse(drutama("ritotalpajak2detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN MASUKAN2 (rirekpajak2)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("rirekpajak2").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("rirekpajak2").ToString, "PPN MASUKAN2", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN MASUKAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~

            'BIAYA LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = ribiayalain * kurs
            nominal = Double.Parse(drutama("ribiayalain")) * Double.Parse(drutama("rikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("rimatauang").ToString <> matauang Then
                    'NOMINAL VALAS = ribiayalain
                    nominalvalas = Double.Parse(drutama("ribiayalain"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING BIAYA LAIN-LAIN (rirekbiayalain)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("rirekbiayalain").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("rirekbiayalain").ToString, "BIAYA LAIN-LAIN", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF BIAYA LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN DEBIT -----------------------------------

            'AKUN KREDIT -----------------------------------------
            'DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = rijmldiskon * kurs
            nominal = Double.Parse(drutama("rijmldiskon")) * Double.Parse(drutama("rikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("rimatauang").ToString <> matauang Then
                    'NOMINAL VALAS = rijmldiskon
                    nominalvalas = Double.Parse(drutama("rijmldiskon"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING DISKON (rirekdiskon)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("rirekdiskon").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("rirekdiskon").ToString, "DISKON", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

             'UM PEMBELIAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = rijmluangmuka * kurs
            nominal = Double.Parse(drutama("rijmluangmuka")) * Double.Parse(drutama("rikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("rimatauang").ToString <> matauang Then
                    'NOMINAL VALAS = rijmluangmuka
                    nominalvalas = Double.Parse(drutama("rijmluangmuka"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING uangmuka (rirekuangmuka)
                filter = "debitkredit = " & debitkredit & " AND norek = '" & drutama("rirekuangmuka").ToString & "' AND costcenter = '' AND divisi = '' AND subdivisi = '' AND proyek = ''"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan~matauang~kurs", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}~{11}~{12}", drutama("rirekuangmuka").ToString, "uangmuka", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, "", "", "", "", urutan, drutama("rimatauang").ToString, FixDouble(drutama("rikurs")))) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If

            End If
            'END OF UM PEMBELIAN ~~~~~~~~~~~~~~~~~~~~~~~~~~

            'HUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = ritotaltransaksi * kurs
            nominal = Double.Parse(drutama("ritotaltransaksi")) * Double.Parse(drutama("rikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("rimatauang").ToString <> matauang Then
                    'NOMINAL VALAS = ritotaltransaksi
                    nominalvalas = Double.Parse(drutama("ritotaltransaksi"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING HUTANG USAHA (rekHutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekHutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekHutangUsaha, "HUTANG USAHA", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF HUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------

            'SELISIH KURS ----------------------------------------
            'JIKA SELISIH KURS > 0 MAKA SEBELAH DEBIT, JIKA SELISIH KURS < 0 MAKA SEBELAH KREDIT
            If selisihKurs > 0 Then
                debitkredit = 0
                'NOMINAL = selisihKurs
                nominal = selisihKurs
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                'If drutama("rimatauang").ToString <> matauang Then
                ''NOMINAL VALAS = selisihKurs / kurs
                'nominalvalas = selisihKurs / Double.Parse(drutama("rikurs"))
                'Else
                nominalvalas = 0
                'End If

                'GROUPING SELISIH KURS (rekSelisihKurs)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekSelisihKurs & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekSelisihKurs, "SELISIH KURS", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If

            ElseIf selisihKurs < 0 Then
                debitkredit = 1
                'NOMINAL = selisihKurs
                nominal = Math.Abs(selisihKurs)
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                'If drutama("rimatauang").ToString <> matauang Then
                ''NOMINAL VALAS = selisihKurs / kurs
                'nominalvalas = Math.Abs(selisihKurs) / Double.Parse(drutama("rikurs"))
                'Else
                nominalvalas = 0
                'End If

                'GROUPING SELISIH KURS (rekSelisihKurs)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekSelisihKurs & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekSelisihKurs, "SELISIH KURS", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If

            End If
            'END OF SELISIH KURS ---------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================

        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                                                                                tmatauang,                                                                                            tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,           tsaldoawal, tadjustment,                         tcostcenter,           tdivisi,                                                        tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("ricabang")) & "', '" & FixQuotes(drutama("rilokasi")) & "', '" & FixQuotes(drutama("risumber")) & "', " & 0 & ", " & drutama("riid") & ", '" & FixQuotes(drutama("rinotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("ritgl"))) & "', " & drutama("rikodepa") & ", " & drutama("risupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("riuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & IIf(drjurnal("norek") = rekSelisihKurs, FixQuotes(matauang), FixQuotes(drutama("rimatauang"))) & "', '" & IIf(drjurnal("norek") = rekSelisihKurs, FixDouble(kurs), FixDouble(drutama("rikurs"))) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("ritgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("ritgllunas"))) & "', " & FixDouble(drutama("ristatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("risaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("ristatus") & ", 1, NOW(), " & drutama("rijmlrevisi") & ", " & drutama("ricetakanke") & ", " & drutama("riinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("riinputtgl"), formatTglWaktuDB)) & "', " & drutama("rimodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rimodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                                                                                tmatauang,                                                                                            tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,           tsaldoawal, tadjustment,                         tcostcenter,           tdivisi,                                                        tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("ricabang")) & "', '" & FixQuotes(drutama("rilokasi")) & "', '" & FixQuotes(drutama("risumber")) & "', " & 0 & ", " & drutama("riid") & ", '" & FixQuotes(drutama("rinotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("ritgl"))) & "', " & drutama("rikodepa") & ", " & drutama("risupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("riuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & IIf(drjurnal("norek") = rekSelisihKurs, FixQuotes(matauang), FixQuotes(drutama("rimatauang"))) & "', '" & IIf(drjurnal("norek") = rekSelisihKurs, FixDouble(kurs), FixDouble(drutama("rikurs"))) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("ritgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("ritgllunas"))) & "', " & FixDouble(drutama("ristatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("risaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("ristatus") & ", 1, NOW(), " & drutama("rijmlrevisi") & ", " & drutama("ricetakanke") & ", " & drutama("riinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("riinputtgl"), formatTglWaktuDB)) & "', " & drutama("rimodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rimodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'RI' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING RI
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m4_ri SET riposting = 1, ripostingtgl = NOW() WHERE riid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function

    Public Function M4_RiBalance(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'PPN MASUKAN1     (+D)
        'PPN MASUKAN2     (+D)
        'BIAYA LAIN       (+D)
        '           DISKON       (+K)
        '           HUTANG USAHA (+K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT ri.* FROM m4_ri ri WHERE (ri.ristatus = 2 OR ri.ristatus = 3 OR ri.ristatus = 4 OR ri.ristatus = 7) AND ri.riid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("risumber")
            noTransaksi = drutama("rinotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'HutangSementara') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'HutangUsaha') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'SelisihKurs')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN HUTANG USAHA
            Dim rekHutangUsaha As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'akun' AND skode = 'HutangUsaha'", "Not found")
            If rekHutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Payable CoA not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------


            'AKUN DEBIT ------------------------------------------
            'PPN MASUKAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = ritotalpajak1detail * kurs
            nominal = Double.Parse(drutama("ritotalpajak1detail")) * Double.Parse(drutama("rikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("rimatauang").ToString <> matauang Then
                    'NOMINAL VALAS = ritotalpajak1detail
                    nominalvalas = Double.Parse(drutama("ritotalpajak1detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN MASUKAN1 (rirekpajak1)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("rirekpajak1").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("rirekpajak1").ToString, "PPN MASUKAN1", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN MASUKAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~

            'PPN MASUKAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = ritotalpajak2detail * kurs
            nominal = Double.Parse(drutama("ritotalpajak2detail")) * Double.Parse(drutama("rikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("rimatauang").ToString <> matauang Then
                    'NOMINAL VALAS = ritotalpajak2detail
                    nominalvalas = Double.Parse(drutama("ritotalpajak2detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN MASUKAN2 (rirekpajak2)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("rirekpajak2").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("rirekpajak2").ToString, "PPN MASUKAN2", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN MASUKAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~

            'BIAYA LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = ribiayalain * kurs
            nominal = Double.Parse(drutama("ribiayalain")) * Double.Parse(drutama("rikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("rimatauang").ToString <> matauang Then
                    'NOMINAL VALAS = ribiayalain
                    nominalvalas = Double.Parse(drutama("ribiayalain"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING BIAYA LAIN-LAIN (rirekbiayalain)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("rirekbiayalain").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("rirekbiayalain").ToString, "BIAYA LAIN-LAIN", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF BIAYA LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN DEBIT -----------------------------------

            'AKUN KREDIT -----------------------------------------
            'DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = rijmldiskon * kurs
            nominal = Double.Parse(drutama("rijmldiskon")) * Double.Parse(drutama("rikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("rimatauang").ToString <> matauang Then
                    'NOMINAL VALAS = rijmldiskon
                    nominalvalas = Double.Parse(drutama("rijmldiskon"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING DISKON (rirekdiskon)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("rirekdiskon").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("rirekdiskon").ToString, "DISKON", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            'HUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = ritotaltransaksi * kurs
            nominal = Double.Parse(drutama("ritotaltransaksi")) * Double.Parse(drutama("rikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("rimatauang").ToString <> matauang Then
                    'NOMINAL VALAS = ritotaltransaksi
                    nominalvalas = Double.Parse(drutama("ritotaltransaksi"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING HUTANG USAHA (rekHutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekHutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekHutangUsaha, "HUTANG USAHA", nominal, nominalvalas, debitkredit, drutama("ricatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF HUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================

        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("ricabang")) & "', '" & FixQuotes(drutama("rilokasi")) & "', '" & FixQuotes(drutama("risumber")) & "', " & 0 & ", " & drutama("riid") & ", '" & FixQuotes(drutama("rinotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("ritgl"))) & "', " & drutama("rikodepa") & ", " & drutama("risupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("riuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("rimatauang")) & "', '" & FixDouble(drutama("rikurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("ritgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("ritgllunas"))) & "', " & FixDouble(drutama("ristatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("ristatus") & ", 1, NOW(), " & drutama("rijmlrevisi") & ", " & drutama("ricetakanke") & ", " & drutama("riinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("riinputtgl"), formatTglWaktuDB)) & "', " & drutama("rimodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rimodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("ricabang")) & "', '" & FixQuotes(drutama("rilokasi")) & "', '" & FixQuotes(drutama("risumber")) & "', " & 0 & ", " & drutama("riid") & ", '" & FixQuotes(drutama("rinotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("ritgl"))) & "', " & drutama("rikodepa") & ", " & drutama("risupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("riuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("rimatauang")) & "', '" & FixDouble(drutama("rikurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("ritgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("ritgllunas"))) & "', " & FixDouble(drutama("ristatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("ristatus") & ", 1, NOW(), " & drutama("rijmlrevisi") & ", " & drutama("ricetakanke") & ", " & drutama("riinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("riinputtgl"), formatTglWaktuDB)) & "', " & drutama("rimodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rimodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next

        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'RI' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING RI
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m4_ri SET riposting = 1, ripostingtgl = NOW() WHERE riid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M4_Prt"
    Public Function M4_Prt(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'HUTANG USAHA   (-D)
        'DISKON         (-D)
        '           PPN MASUKAN1    (-K)
        '           PPN MASUKAN2    (-K)
        '           BIAYA LAIN      (-K)
        '           RETUR PEMBELIAN (+K)

        'GROUP 2 : =====================
        'HPP            (+D)
        '           PERSEDIAAN      (-K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow, idutama As Double = 0
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0

        'BUAT DT JURNAL GROUP 1
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'BUAT DT JURNAL GROUP 2
        Dim dtjurnal2 As New DataTable
        AsDataTableTambahField(dtjurnal2, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal2, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal2, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal2, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "urutan", AsEnumTypeData.AsInt64)


        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT prt.* FROM m4_prt prt WHERE (prt.prtstatus = 2 OR prt.prtstatus = 3 OR prt.prtstatus = 4 OR prt.prtstatus = 7) AND prt.prtid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT prtd.*, i.bjenis FROM M4_prt_detail prtd JOIN M4_prt prt ON prtd.idprt = prt.prtid JOIN m1_item i ON prtd.idbarang = i.bid WHERE (prt.prtstatus = 2 OR prt.prtstatus = 3 OR prt.prtstatus = 4 OR prt.prtstatus = 7) AND prt.prtid = '" & idtransaksi & "'", strCon)


        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        'If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
        If dtutama.Rows.Count > 0 Then

            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            idutama = drutama("prtid")
            sumber = drutama("prtsumber")
            noTransaksi = drutama("prtnotransaksi")
            'END OF SET DATA UTAMA -------------------------------


            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'HutangUsaha')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN HUTANG USAHA
            Dim rekHutangUsaha As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'akun' AND skode = 'HutangUsaha'", "Not found")
            If rekHutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Payable CoA not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------


            Dim bjenis As String = ""

            'BUAT JURNAL YG BERASAL DARI DATA DETAIL -------------
            If dtdetail.Rows.Count > 0 Then
                For Each drdetail As DataRow In dtdetail.Rows

                    'GRUP 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    'AKUN RETUR PEMBELIAN ++++++++++++++
                    debitkredit = 1

                    'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                    nominal = ((Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))) * Double.Parse(drdetail("kurs"))
                    'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                    If drutama("prtmatauang").ToString <> matauang Then
                        'NOMINAL VALAS = (((jml * harga) - jmldiskon)
                        nominalvalas = ((Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon")))
                    Else
                        nominalvalas = 0
                    End If

                    'GROUPING AKUN KREDIT (rekreturpembelian)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekreturpembelian").ToString & "'"
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekreturpembelian").ToString, "RETUR PEMBELIAN", nominal, nominalvalas, debitkredit, drutama("prtcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If
                    'END OF AKUN RETUR PEMBELIAN +++++++
                    'END OF GRUP 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                    'GRUP 2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    'SET VARIABLE
                    bjenis = drdetail("bjenis")

                    'JIKA BUKAN BARANG JASA MAKA BUAT JURNAL
                    If bjenis <> "J" Then

                        'AKUN DEBIT --------------------
                        'AKUN HPP ++++++++++++++++++++++
                        debitkredit = 0
                        'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                        'NOMINAL = jmlbarang * hpp
                        nominal = Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))
                        If drutama("prtmatauang").ToString <> matauang Then
                            'NOMINAL VALAS = (jmlbarang * hpp) / kurs
                            nominalvalas = (Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))) / Double.Parse(drdetail("kurs"))

                            'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                        Else
                            'NOMINAL VALAS = 0 
                            nominalvalas = 0
                        End If

                        'GROUPING AKUN DEBIT (rekhargapokok)
                        filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekhargapokok").ToString & "'"
                        If AsDataTableDCount(dtjurnal2, filter) > 0 Then
                            nominal += Double.Parse(AsDataTableDLookup(dtjurnal2, "nominal", filter))
                            nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal2, "nominalvalas", filter))
                            If AsDataTableUpdateData(dtjurnal2, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                                rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        Else
                            If AsDataTableTambahData(dtjurnal2, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                     String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekhargapokok").ToString, "HPP", nominal, nominalvalas, debitkredit, drutama("prtcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                                rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        End If
                        'END OF AKUN HPP +++++++++++++++
                        'END OF AKUN DEBIT -------------


                        'AKUN KREDIT -------------------
                        'AKUN PERSEDIAAN +++++++++++++++
                        debitkredit = 1
                        'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                        'NOMINAL = jmlbarang * hpp
                        nominal = Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))
                        If drutama("prtmatauang").ToString <> matauang Then
                            'NOMINAL VALAS = (jmlbarang * hpp) / kurs
                            nominalvalas = (Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))) / Double.Parse(drdetail("kurs"))

                            'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                        Else
                            'NOMINAL VALAS = 0 
                            nominalvalas = 0
                        End If

                        'GROUPING AKUN DEBIT (rekpersediaan)
                        filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekpersediaan").ToString & "'"
                        If AsDataTableDCount(dtjurnal2, filter) > 0 Then
                            nominal += Double.Parse(AsDataTableDLookup(dtjurnal2, "nominal", filter))
                            nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal2, "nominalvalas", filter))
                            If AsDataTableUpdateData(dtjurnal2, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                                rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        Else
                            If AsDataTableTambahData(dtjurnal2, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                     String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekpersediaan").ToString, "PERSEDIAAN", nominal, nominalvalas, debitkredit, drutama("prtcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                                rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        End If
                        'END OF AKUN PERSEDIAAN ++++++++
                        'END OF AKUN KREDIT ------------

                    End If
                    'END OF GRUP 2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                Next
            End If
            'END OF BUAT JURNAL YG BERASAL DARI DATA DETAIL ------


            'BUAT JURNAL YG BERASAL DARI DATA UTAMA --------------
            'GRUP 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            'HUTANG USAHA ++++++++++++++++++++++++++
            debitkredit = 0
            'NOMINAL = prttotaltransaksi * kurs
            nominal = Double.Parse(drutama("prttotaltransaksi")) * Double.Parse(drutama("prtkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("prtmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = prttotaltransaksi
                    nominalvalas = Double.Parse(drutama("prttotaltransaksi"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING HUTANG USAHA (rekHutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekHutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekHutangUsaha, "HUTANG USAHA", nominal, nominalvalas, debitkredit, drutama("prtcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF HUTANG USAHA +++++++++++++++++++

            'DISKON ++++++++++++++++++++++++++++++++
            debitkredit = 0
            'NOMINAL = prtjmldiskon * kurs
            nominal = Double.Parse(drutama("prtjmldiskon")) * Double.Parse(drutama("prtkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("prtmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = prtjmldiskon
                    nominalvalas = Double.Parse(drutama("prtjmldiskon"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING DISKON (prtrekdiskon)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("prtrekdiskon").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("prtrekdiskon").ToString, "DISKON", nominal, nominalvalas, debitkredit, drutama("prtcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF DISKON +++++++++++++++++++++++++

            'PPN MASUKAN1 ++++++++++++++++++++++++++
            debitkredit = 1
            'NOMINAL = prttotalpajak1detail * kurs
            nominal = Double.Parse(drutama("prttotalpajak1detail")) * Double.Parse(drutama("prtkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("prtmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = prttotalpajak1detail
                    nominalvalas = Double.Parse(drutama("prttotalpajak1detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN MASUKAN1 (prtrekpajak1)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("prtrekpajak1").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("prtrekpajak1").ToString, "PPN MASUKAN1", nominal, nominalvalas, debitkredit, drutama("prtcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN MASUKAN1 +++++++++++++++++++

            'PPN MASUKAN2 ++++++++++++++++++++++++++
            debitkredit = 1
            'NOMINAL = prttotalpajak2detail * kurs
            nominal = Double.Parse(drutama("prttotalpajak2detail")) * Double.Parse(drutama("prtkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("prtmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = prttotalpajak2detail
                    nominalvalas = Double.Parse(drutama("prttotalpajak2detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN MASUKAN2 (prtrekpajak2)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("prtrekpajak2").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("prtrekpajak2").ToString, "PPN MASUKAN2", nominal, nominalvalas, debitkredit, drutama("prtcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN MASUKAN2 +++++++++++++++++++

            'BIAYA LAIN ++++++++++++++++++++++++++++
            debitkredit = 1
            'NOMINAL = prtbiayalain * kurs
            nominal = Double.Parse(drutama("prtbiayalain")) * Double.Parse(drutama("prtkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("prtmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = prtbiayalain
                    nominalvalas = Double.Parse(drutama("prtbiayalain"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING BIAYA LAIN-LAIN (prtrekbiayalain)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("prtrekbiayalain").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("prtrekbiayalain").ToString, "BIAYA LAIN-LAIN", nominal, nominalvalas, debitkredit, drutama("prtcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF BIAYA LAIN +++++++++++++++++++++
            'END OF GRUP 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            'END OF BUAT JURNAL YG BERASAL DARI DATA UTAMA -------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder
        Dim jGrup As Integer = 0

        'JURNAL GRUP 1 -------------------------------------------
        jGrup = 1

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                              tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,              tsaldoawal, tadjustment,                          tcostcenter,                                tdivisi,                                 tsubdivisi,                                tproyek,                                tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("prtcabang")) & "', '" & FixQuotes(drutama("prtlokasi")) & "', '" & FixQuotes(drutama("prtsumber")) & "', " & 0 & ", " & drutama("prtid") & ", '" & FixQuotes(drutama("prtnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("prttgl"))) & "', " & drutama("prtkodepa") & ", " & drutama("prtsupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("prturaian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("prtmatauang")) & "', '" & FixDouble(drutama("prtkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("prttgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("prttgllunas"))) & "', " & FixDouble(drutama("prtstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("prtsaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', " & FixDouble(jGrup) & ", 0, 'O', '0', 0, " & drutama("prtstatus") & ", 1, NOW(), " & drutama("prtjmlrevisi") & ", " & drutama("prtcetakanke") & ", " & drutama("prtinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("prtinputtgl"), formatTglWaktuDB)) & "', " & drutama("prtmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("prtmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                              tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,              tsaldoawal, tadjustment,                          tcostcenter,                                tdivisi,                                 tsubdivisi,                                tproyek,                                tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("prtcabang")) & "', '" & FixQuotes(drutama("prtlokasi")) & "', '" & FixQuotes(drutama("prtsumber")) & "', " & 0 & ", " & drutama("prtid") & ", '" & FixQuotes(drutama("prtnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("prttgl"))) & "', " & drutama("prtkodepa") & ", " & drutama("prtsupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("prturaian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("prtmatauang")) & "', '" & FixDouble(drutama("prtkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("prttgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("prttgllunas"))) & "', " & FixDouble(drutama("prtstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("prtsaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', " & FixDouble(jGrup) & ", 0, 'O', '0', 0, " & drutama("prtstatus") & ", 1, NOW(), " & drutama("prtjmlrevisi") & ", " & drutama("prtcetakanke") & ", " & drutama("prtinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("prtinputtgl"), formatTglWaktuDB)) & "', " & drutama("prtmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("prtmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next
        'END OF JURNAL GRUP 1 ------------------------------------


        'JURNAL GRUP 2 -------------------------------------------
        jGrup = 2

        'URUTKAN JURNAL
        dtjurnal2 = AsDataTableFilterSortDt(dtjurnal2, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal2, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal2.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                              tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,              tsaldoawal, tadjustment,                          tcostcenter,                                tdivisi,                                 tsubdivisi,                                tproyek,                                tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("prtcabang")) & "', '" & FixQuotes(drutama("prtlokasi")) & "', '" & FixQuotes(drutama("prtsumber")) & "', " & 0 & ", " & drutama("prtid") & ", '" & FixQuotes(drutama("prtnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("prttgl"))) & "', " & drutama("prtkodepa") & ", " & drutama("prtsupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("prturaian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("prtmatauang")) & "', '" & FixDouble(drutama("prtkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("prttgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("prttgllunas"))) & "', " & FixDouble(drutama("prtstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("prtsaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', " & FixDouble(jGrup) & ", 0, 'O', '0', 0, " & drutama("prtstatus") & ", 1, NOW(), " & drutama("prtjmlrevisi") & ", " & drutama("prtcetakanke") & ", " & drutama("prtinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("prtinputtgl"), formatTglWaktuDB)) & "', " & drutama("prtmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("prtmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                              tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,              tsaldoawal, tadjustment,                          tcostcenter,                                tdivisi,                                 tsubdivisi,                                tproyek,                                tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("prtcabang")) & "', '" & FixQuotes(drutama("prtlokasi")) & "', '" & FixQuotes(drutama("prtsumber")) & "', " & 0 & ", " & drutama("prtid") & ", '" & FixQuotes(drutama("prtnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("prttgl"))) & "', " & drutama("prtkodepa") & ", " & drutama("prtsupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("prturaian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("prtmatauang")) & "', '" & FixDouble(drutama("prtkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("prttgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("prttgllunas"))) & "', " & FixDouble(drutama("prtstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("prtsaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', " & FixDouble(jGrup) & ", 0, 'O', '0', 0, " & drutama("prtstatus") & ", 1, NOW(), " & drutama("prtjmlrevisi") & ", " & drutama("prtcetakanke") & ", " & drutama("prtinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("prtinputtgl"), formatTglWaktuDB)) & "', " & drutama("prtmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("prtmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next
        'END OF JURNAL GRUP 2 ------------------------------------


        'HAPUS JURNAL LAMA
        Dim sqlHapus As String = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'PRT' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'BUAT SQL JURNAL
        Dim sqlJurnal As String = ""
        If Len(strValue.ToString) > 0 Then
            sqlJurnal = "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & ""
        End If

        'UPDATE STATUS POSTING JURNAL TRANSAKSI BARANG
        Dim sqlPostingIT As String = "UPDATE M1_Item_Transaction SET postingjurnal = 1 WHERE sumber = '" & sumber & "' AND idutama = '" & idutama & "'"

        'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING
        Dim sqlPosting As String = "UPDATE m4_prt SET prtposting = 1, prtpostingtgl = NOW() WHERE prtid = '" & idtransaksi & "'"


        'GABUNGKAN VALUE SQL
        rsSql = String.Concat(sqlHapus, sptRow, sqlJurnal, sptRow, sqlPostingIT, sptRow, sqlPosting)
        'END OF BUAT SQL =====================================================


        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function

    Public Function M4_PrtBalance(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'HUTANG USAHA   (-D)
        'DISKON         (-D)
        '           PPN MASUKAN1    (-K)
        '           PPN MASUKAN2    (-K)
        '           BIAYA LAIN      (-K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0

        'BUAT DT JURNAL GROUP 1
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT prt.* FROM m4_prt prt WHERE (prt.prtstatus = 2 OR prt.prtstatus = 3 OR prt.prtstatus = 4 OR prt.prtstatus = 7) AND prt.prtid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)
            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("prtsumber")
            noTransaksi = drutama("prtnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'HutangUsaha')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN HUTANG USAHA
            Dim rekHutangUsaha As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'akun' AND skode = 'HutangUsaha'", "Not found")
            If rekHutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Payable CoA not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------


            'BUAT JURNAL YG BERASAL DARI DATA UTAMA --------------
            'GRUP 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            'HUTANG USAHA ++++++++++++++++++++++++++
            debitkredit = 0
            'NOMINAL = prttotaltransaksi * kurs
            nominal = Double.Parse(drutama("prttotaltransaksi")) * Double.Parse(drutama("prtkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("prtmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = prttotaltransaksi
                    nominalvalas = Double.Parse(drutama("prttotaltransaksi"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING HUTANG USAHA (rekHutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekHutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekHutangUsaha, "HUTANG USAHA", nominal, nominalvalas, debitkredit, drutama("prtcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF HUTANG USAHA +++++++++++++++++++

            'DISKON ++++++++++++++++++++++++++++++++
            debitkredit = 0
            'NOMINAL = prtjmldiskon * kurs
            nominal = Double.Parse(drutama("prtjmldiskon")) * Double.Parse(drutama("prtkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("prtmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = prtjmldiskon
                    nominalvalas = Double.Parse(drutama("prtjmldiskon"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING DISKON (prtrekdiskon)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("prtrekdiskon").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("prtrekdiskon").ToString, "DISKON", nominal, nominalvalas, debitkredit, drutama("prtcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF DISKON +++++++++++++++++++++++++

            'PPN MASUKAN1 ++++++++++++++++++++++++++
            debitkredit = 1
            'NOMINAL = prttotalpajak1detail * kurs
            nominal = Double.Parse(drutama("prttotalpajak1detail")) * Double.Parse(drutama("prtkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("prtmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = prttotalpajak1detail
                    nominalvalas = Double.Parse(drutama("prttotalpajak1detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN MASUKAN1 (prtrekpajak1)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("prtrekpajak1").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("prtrekpajak1").ToString, "PPN MASUKAN1", nominal, nominalvalas, debitkredit, drutama("prtcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN MASUKAN1 +++++++++++++++++++

            'PPN MASUKAN2 ++++++++++++++++++++++++++
            debitkredit = 1
            'NOMINAL = prttotalpajak2detail * kurs
            nominal = Double.Parse(drutama("prttotalpajak2detail")) * Double.Parse(drutama("prtkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("prtmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = prttotalpajak2detail
                    nominalvalas = Double.Parse(drutama("prttotalpajak2detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN MASUKAN2 (prtrekpajak2)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("prtrekpajak2").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("prtrekpajak2").ToString, "PPN MASUKAN2", nominal, nominalvalas, debitkredit, drutama("prtcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN MASUKAN2 +++++++++++++++++++

            'BIAYA LAIN ++++++++++++++++++++++++++++
            debitkredit = 1
            'NOMINAL = prtbiayalain * kurs
            nominal = Double.Parse(drutama("prtbiayalain")) * Double.Parse(drutama("prtkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("prtmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = prtbiayalain
                    nominalvalas = Double.Parse(drutama("prtbiayalain"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING BIAYA LAIN-LAIN (prtrekbiayalain)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("prtrekbiayalain").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("prtrekbiayalain").ToString, "BIAYA LAIN-LAIN", nominal, nominalvalas, debitkredit, drutama("prtcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF BIAYA LAIN +++++++++++++++++++++
            'END OF GRUP 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            'END OF BUAT JURNAL YG BERASAL DARI DATA UTAMA -------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder
        Dim jGrup As Integer = 0

        'JURNAL GRUP 1 -------------------------------------------
        jGrup = 1

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                              tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,                                tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("prtcabang")) & "', '" & FixQuotes(drutama("prtlokasi")) & "', '" & FixQuotes(drutama("prtsumber")) & "', " & 0 & ", " & drutama("prtid") & ", '" & FixQuotes(drutama("prtnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("prttgl"))) & "', " & drutama("prtkodepa") & ", " & drutama("prtsupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("prturaian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("prtmatauang")) & "', '" & FixDouble(drutama("prtkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("prttgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("prttgllunas"))) & "', " & FixDouble(drutama("prtstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', " & FixDouble(jGrup) & ", 0, 'O', '0', 0, " & drutama("prtstatus") & ", 1, NOW(), " & drutama("prtjmlrevisi") & ", " & drutama("prtcetakanke") & ", " & drutama("prtinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("prtinputtgl"), formatTglWaktuDB)) & "', " & drutama("prtmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("prtmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                              tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,                                tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("prtcabang")) & "', '" & FixQuotes(drutama("prtlokasi")) & "', '" & FixQuotes(drutama("prtsumber")) & "', " & 0 & ", " & drutama("prtid") & ", '" & FixQuotes(drutama("prtnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("prttgl"))) & "', " & drutama("prtkodepa") & ", " & drutama("prtsupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("prturaian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("prtmatauang")) & "', '" & FixDouble(drutama("prtkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("prttgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("prttgllunas"))) & "', " & FixDouble(drutama("prtstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', " & FixDouble(jGrup) & ", 0, 'O', '0', 0, " & drutama("prtstatus") & ", 1, NOW(), " & drutama("prtjmlrevisi") & ", " & drutama("prtcetakanke") & ", " & drutama("prtinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("prtinputtgl"), formatTglWaktuDB)) & "', " & drutama("prtmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("prtmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next
        'END OF JURNAL GRUP 1 ------------------------------------


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'PRT' AND tgrup = '" & FixDouble(jGrup) & "' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING PRT
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m4_prt SET prtposting = 1, prtpostingtgl = NOW() WHERE prtid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M4_Vp"
    Public Function M4_Vp(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'AKUN RI            (D) -------------------> INVOICE PEMBELIAN
        'COA > 0            (D) -------------------> COA
        'SELISIH KURS < 0   (D) -------------------> SELISIH KURS
        '               AKUN AP            (K) ----> UANG MUKA PEMBELIAN
        '               AKUN PRT           (K) ----> RETUR PEMBELIAN
        '               AKUN BAYAR         (K) ----> BAYAR
        '               COA < 0            (K) ----> COA
        '               SELISIH KURS > 0   (K) ----> SELISIH KURS

        'JIKA ADA SELISIH TOTAL AP DAN TOTAL AR MAKA MASUK KE AKUN SETTING SELISIH HUTANG PIUTANG

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable, dtpay As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, debitkreditgroup As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0, selisihKurs As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT vp.* FROM m4_vp vp WHERE (vp.vpstatus = 2 OR vp.vpstatus = 3 OR vp.vpstatus = 4 OR vp.vpstatus = 7) AND vp.vpid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT vpd.* FROM m4_vp_detail vpd JOIN m4_vp vp ON vpd.idvp = vp.vpid WHERE (vp.vpstatus = 2 OR vp.vpstatus = 3 OR vp.vpstatus = 4 OR vp.vpstatus = 7) AND vp.vpid = '" & idtransaksi & "'", strCon)
        'PAY
        dtpay = AsDataTableAmbilDariDB("SELECT vpp.* FROM m4_vp_pay vpp JOIN m4_vp vp ON vpp.idvp = vp.vpid WHERE (vp.vpstatus = 2 OR vp.vpstatus = 3 OR vp.vpstatus = 4 OR vp.vpstatus = 7) AND vp.vpid = '" & idtransaksi & "'", strCon)

        Dim rekSelisihKurs As String = "", rekSelisihHP As String = "", matauang As String = "", kurs As String = ""

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then

            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("vpsumber")
            noTransaksi = drutama("vpnotransaksi")
            rekSelisihKurs = drutama("vprekselisihkurs")
            'END OF SET DATA UTAMA -------------------------------


            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'SelisihHutangPiutang')", strCon)
            'MATAUANG
            matauang = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            kurs = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'REK SELISIH HUTANG PIUTANG
            rekSelisihHP = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'akun' AND skode = 'SelisihHutangPiutang'", "Not found")
            If rekSelisihHP = "Not found" Then
                rsErrMessage = "Setting Account of Difference AP/AR not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------


            'BUAT JURNAL TRANSAKSI -------------------------------
            'DATA DIAMBILKAN DARI DATA DETAIL
            For Each drdetail As DataRow In dtdetail.Rows
                'JIKA (SUMBER = RI) ATAU (SUMBER = CA DAN JMLBAYAR > 0) MAKA DEBIT, ELSE MAKA KREDIT
                If drdetail("sumber") = "RI" Or (drdetail("sumber") = "CA" And Double.Parse(drdetail("jmlbayar")) > 0) Then
                    debitkredit = 0
                Else
                    debitkredit = 1
                End If

                'NOMINAL = jmlbayar
                nominal = Math.Abs(Double.Parse(drdetail("jmlbayar")))
                'NOMINALVALAS = jmlbayarvalas
                nominalvalas = Math.Abs(Double.Parse(drdetail("jmlbayarvalas")))

                'GROUPING AKUN (rekhutangpiutang)
                filter = "norek='" & drdetail("rekhutangpiutang").ToString & "'"
                'CEK AKUN SUDAH ADA ATAU BELUM PADA DT JURNAL
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    'JIKA ADA, CEK AKUN TERSEBUT DEBIT / KREDIT
                    debitkreditgroup = Double.Parse(AsDataTableDLookup(dtjurnal, "debitkredit", filter))
                    If debitkreditgroup = debitkredit Then
                        'JIKA AKUN SAMA-SAMA DEBIT/SAMA-SAMA KREDIT MAKA TAMBAHKAN NOMINALNYA SAJA
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        'UPDATE NOMINAL AKUN PADA DT JURNAL
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                            rsErrMessage = "Failed update grouping datatable journal transaction #1 " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If

                    Else
                        'JIKA AKUN BERBEDA DEBIT KREDITNYA MAKA NOMINAL BARU = NOMINAL AKUN PADA DT JURNAL - NOMINAL AKUN
                        nominal = Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter)) - nominal
                        nominalvalas = Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter)) - nominalvalas
                        'CEK NOMINAL BARU, JIKA NOMINAL BARU < 1 MAKA PINDAH SISI DEBIT DAN KREDITNYA
                        If nominal < 0 Then
                            'ABSOLUTKAN NILAI NOMINAL
                            nominal = Math.Abs(nominal)
                            nominalvalas = Math.Abs(nominalvalas)
                            'UPDATE NOMINAL DAN DEBITKREDIT DT JURNAL
                            If debitkreditgroup = 0 Then
                                'JIKA AKUN PADA DT JURNAL DEBIT MAKA DIPINDAH KE KREDIT
                                If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas~debitkredit", nominal & "~" & nominalvalas & "~" & 1) = False Then
                                    rsErrMessage = "Failed update grouping datatable journal transaction #2 " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                                End If
                            Else
                                'JIKA AKUN PADA DT JURNAL KREDIT MAKA DIPINDAH KE DEBIT
                                If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas~debitkredit", nominal & "~" & nominalvalas & "~" & 0) = False Then
                                    rsErrMessage = "Failed update grouping datatable journal transaction #3 " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                                End If
                            End If

                            'JIKA NOMINAL BARU >= 0 MAKA UPDATE NOMINALNYA SAJA
                        Else
                            'UPDATE NOMINAL AKUN PADA DT JURNAL
                            If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                                rsErrMessage = "Failed update grouping datatable journal transaction #4 " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        End If
                    End If

                    'JIKA TIDAK ADA, TAMBAHKAN AKUN PADA DT JURNAL
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekhutangpiutang").ToString, drdetail("sumber").ToString, nominal, nominalvalas, debitkredit, drutama("vpcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal transaction " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If

            Next
            'END OF BUAT JURNAL TRANSAKSI ------------------------


            'BUAT JURNAL BAYAR -----------------------------------
            'DATA DIAMBILKAN DARI DATA PAY
            If dtpay.Rows.Count > 0 Then
                Dim rekBayar As String = ""
                debitkredit = 1
                For Each drpay As DataRow In dtpay.Rows
                    'JIKA CARABAYAR GIRO(2) MAKA AMBIL AKUN BAYAR AMBIL DARI rekgiro, ELSE AKUN BAYAR AMBIL DARI rekbank
                    If Double.Parse(drpay("carabayar")) = 2 Then rekBayar = drpay("rekgiro").ToString Else rekBayar = drpay("rekbank").ToString

                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                          String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekBayar, "AKUN BAYAR", Double.Parse(drpay("jumlah")), Double.Parse(drpay("jumlahvalas")), debitkredit, drutama("vpcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal payment " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Next
            End If
            'END OF BUAT JURNAL BAYAR ----------------------------


            'BUAT JURNAL SELISIH KURS ----------------------------
            If Double.Parse(drutama("vpselisihkurs")) < 0 Then
                'JIKA SELISIH KURS < 0 MAKA DEBIT
                debitkredit = 0
                nominal = Math.Abs(Double.Parse(drutama("vpselisihkurs")))
                nominalvalas = 0
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                          String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("vprekselisihkurs").ToString, "SELISIH KURS", nominal, nominalvalas, debitkredit, drutama("vpcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal difference rate " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If

            ElseIf Double.Parse(drutama("vpselisihkurs")) > 0 Then
                'JIKA SELISIH KURS > 0 MAKA KREDIT
                debitkredit = 1
                nominal = Math.Abs(Double.Parse(drutama("vpselisihkurs")))
                nominalvalas = 0
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                          String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("vprekselisihkurs").ToString, "SELISIH KURS", nominal, nominalvalas, debitkredit, drutama("vpcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal difference rate " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If

            End If
            'END OF BUAT JURNAL SELISIH KURS ---------------------


            'BUAT JURNAL DISKON TERMIN ---------------------------
            If Double.Parse(drutama("vpdiskontermin")) <> 0 Then
                'JIKA DISKON TERMIN > 0 MAKA KREDIT
                debitkredit = 1
                nominal = Double.Parse(drutama("vpdiskontermin"))
                nominalvalas = Double.Parse(drutama("vpdiskonterminvalas"))
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                          String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("vprekdiskontermin").ToString, "DISKON TERMIN", nominal, nominalvalas, debitkredit, drutama("vpcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal difference rate " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If

            End If
            'END OF BUAT JURNAL DISKON TERMIN --------------------


            'BUAT SELISIH HUTANG PIUTANG -------------------------
            Dim JmlRI As Double = 0, JmlCoa As Double = 0
            Dim JmlAP As Double = 0, JmlPRT As Double = 0
            Dim JmlTabBayar As Double = 0
            Dim TotalAP As Double = 0, TotalAR As Double = 0

            'TOTAL AP = RI + COA
            JmlRI = AsDataTableDSum(dtdetail, "jmlbayar", "sumber = 'RI'") - AsDataTableDSum(dtdetail, "jmldiskontermin", "sumber = 'RI'")
            JmlCoa = AsDataTableDSum(dtdetail, "jmlbayar", "sumber = 'CA'") - AsDataTableDSum(dtdetail, "jmldiskontermin", "sumber = 'CA'")
            TotalAP = JmlRI + JmlCoa

            'TOTAL AR = AP + PRT + BAYAR
            JmlAP = AsDataTableDSum(dtdetail, "jmlbayar", "sumber = 'AP'") - AsDataTableDSum(dtdetail, "jmldiskontermin", "sumber = 'AP'")
            JmlPRT = AsDataTableDSum(dtdetail, "jmlbayar", "sumber = 'PRT'") - AsDataTableDSum(dtdetail, "jmldiskontermin", "sumber = 'PR'")
            JmlTabBayar = AsDataTableDSum(dtpay, "jumlah")
            TotalAR = JmlAP + JmlPRT + JmlTabBayar


            If TotalAP - TotalAR > 0 Then
                'JIKA SELISIH AP - AR > 0 MAKA JURNAL PEMBULATAN DISISI KREDIT
                debitkredit = 1
                nominal = F_RoundDecimal(Math.Abs(TotalAP - TotalAR))
                nominalvalas = 0
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                          String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekSelisihHP, "SELISIH HUTANG PIUTANG", nominal, nominalvalas, debitkredit, drutama("vpcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal difference rate " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If

            ElseIf TotalAP - TotalAR < 0 Then
                'JIKA SELISIH AP - AR < 0 MAKA JURNAL PEMBULATAN DISISI DEBIT
                debitkredit = 0
                nominal = F_RoundDecimal(Math.Abs(TotalAP - TotalAR))
                nominalvalas = 0
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                          String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekSelisihHP, "SELISIH HUTANG PIUTANG", nominal, nominalvalas, debitkredit, drutama("vpcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal difference rate " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If

            End If
            'END OF BUAT SELISIH HUTANG PIUTANG ------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                                                                                tmatauang,                                                                                             tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                        ttgljatuhtempo,                                         ttgllunas,          tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("vpcabang")) & "', '" & FixQuotes(drutama("vplokasi")) & "', '" & FixQuotes(drutama("vpsumber")) & "', " & 0 & ", " & drutama("vpid") & ", '" & FixQuotes(drutama("vpnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("vptgl"))) & "', " & drutama("vpkodepa") & ", " & drutama("vpsupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("vpuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & IIf(drjurnal("norek") = rekSelisihKurs, FixQuotes(matauang), FixQuotes(drutama("vpmatauang"))) & "', '" & IIf(drjurnal("norek") = rekSelisihKurs, FixDouble(kurs), FixDouble(drutama("vpkurs"))) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', " & FixDouble(0) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("vpstatus") & ", 1, NOW(), " & drutama("vpjmlrevisi") & ", " & drutama("vpcetakanke") & ", " & drutama("vpinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("vpinputtgl"), formatTglWaktuDB)) & "', " & drutama("vpmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("vpmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                                                                                tmatauang,                                                                                             tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                        ttgljatuhtempo,                                         ttgllunas,          tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("vpcabang")) & "', '" & FixQuotes(drutama("vplokasi")) & "', '" & FixQuotes(drutama("vpsumber")) & "', " & 0 & ", " & drutama("vpid") & ", '" & FixQuotes(drutama("vpnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("vptgl"))) & "', " & drutama("vpkodepa") & ", " & drutama("vpsupplier") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("vpuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & IIf(drjurnal("norek") = rekSelisihKurs, FixQuotes(matauang), FixQuotes(drutama("vpmatauang"))) & "', '" & IIf(drjurnal("norek") = rekSelisihKurs, FixDouble(kurs), FixDouble(drutama("vpkurs"))) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', " & FixDouble(0) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("vpstatus") & ", 1, NOW(), " & drutama("vpjmlrevisi") & ", " & drutama("vpcetakanke") & ", " & drutama("vpinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("vpinputtgl"), formatTglWaktuDB)) & "', " & drutama("vpmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("vpmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'VP' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING VP
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m4_vp SET vpposting = 1, vppostingtgl = NOW() WHERE vpid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

    '********************************************** M5 **********************************************

#Region "M5_Ip"
    Public Function M5_Ip(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'AKUN TERIMA (D)
        '           AKUN TRANSIT TERIMA UANG (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT `ip`.* FROM m5_ip `ip` WHERE (`ip`.ipstatus = 2 OR `ip`.ipstatus = 3 OR `ip`.ipstatus = 4 OR `ip`.ipstatus = 7) AND `ip`.ipid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT ipd.* FROM m5_ip_pay ipd JOIN m5_ip `ip` ON ipd.idip = `ip`.ipid WHERE (`ip`.ipstatus = 2 OR `ip`.ipstatus = 3 OR `ip`.ipstatus = 4 OR `ip`.ipstatus = 7) AND `ip`.ipid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("ipsumber")
            noTransaksi = drutama("ipnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT ------------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            debitkredit = 0
            Dim rekBayar As String = ""
            For Each drdetail As DataRow In dtdetail.Rows
                urutan = Val(drdetail("urutan"))

                'JIKA CARABAYAR GIRO(2) MAKA AMBIL AKUN BAYAR AMBIL DARI rekgiro, ELSE AKUN BAYAR AMBIL DARI rekbank
                If Double.Parse(drdetail("carabayar")) = 2 Then rekBayar = drdetail("rekgiro").ToString Else rekBayar = drdetail("rekbank").ToString

                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekBayar, "AKUN TERIMA", Double.Parse(drdetail("jumlah")), Double.Parse(drdetail("jumlahvalas")), debitkredit, drutama("ipcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If
            Next
            'END OF AKUN DEBIT -----------------------------------

            'AKUN KREDIT -----------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI UTAMA
            debitkredit = 1
            urutan = urutan + 1
            If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                  String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("ipnorek").ToString, "AKUN TRANSIT TERIMA UANG", Double.Parse(drutama("ipjumlah")), Double.Parse(drutama("ipjumlahvalas")), debitkredit, drutama("ipcatatan").ToString, drutama("ipcostcenter").ToString, drutama("ipdivisi").ToString, drutama("ipsubdivisi").ToString, drutama("ipproyek").ToString, urutan)) = False Then
                rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            End If
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                   ttgljatuhtempo,                                                   ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("ipcabang")) & "', '" & FixQuotes(drutama("iplokasi")) & "', '" & FixQuotes(drutama("ipsumber")) & "', " & 0 & ", " & drutama("ipid") & ", '" & FixQuotes(drutama("ipnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("iptgl"))) & "', " & drutama("ipkodepa") & ", " & drutama("ipkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("ipuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("ipmatauang")) & "', '" & FixDouble(drutama("ipkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("iptgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("iptgllunas"))) & "', " & drutama("ipstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("ipjumlahbayar")) & "', " & drutama("ipstatusbayar") & ", " & drutama("ipstatus") & ", 1, NOW(), " & drutama("ipjmlrevisi") & ", " & drutama("ipcetakanke") & ", " & drutama("ipinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("ipinputtgl"), formatTglWaktuDB)) & "', " & drutama("ipmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("ipmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                   ttgljatuhtempo,                                                   ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("ipcabang")) & "', '" & FixQuotes(drutama("iplokasi")) & "', '" & FixQuotes(drutama("ipsumber")) & "', " & 0 & ", " & drutama("ipid") & ", '" & FixQuotes(drutama("ipnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("iptgl"))) & "', " & drutama("ipkodepa") & ", " & drutama("ipkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("ipuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("ipmatauang")) & "', '" & FixDouble(drutama("ipkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("iptgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("iptgllunas"))) & "', " & drutama("ipstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("ipjumlahbayar")) & "', " & drutama("ipstatusbayar") & ", " & drutama("ipstatus") & ", 1, NOW(), " & drutama("ipjmlrevisi") & ", " & drutama("ipcetakanke") & ", " & drutama("ipinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("ipinputtgl"), formatTglWaktuDB)) & "', " & drutama("ipmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("ipmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'IP' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING AS
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m5_ip SET ipposting = 1, ippostingtgl = NOW() WHERE ipid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M5_As"
    Public Function M5_As(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'AKUN TERIMA (D)
        '           AKUN UM PENJUALAN (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT `as`.* FROM m5_as `as` WHERE (`as`.asstatus = 2 OR `as`.asstatus = 3 OR `as`.asstatus = 4 OR `as`.asstatus = 7) AND `as`.asid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT asd.* FROM m5_as_pay asd JOIN m5_as `as` ON asd.idas = `as`.asid WHERE (`as`.asstatus = 2 OR `as`.asstatus = 3 OR `as`.asstatus = 4 OR `as`.asstatus = 7) AND `as`.asid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("assumber")
            noTransaksi = drutama("asnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT ------------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            debitkredit = 0
            Dim rekBayar As String = ""
            For Each drdetail As DataRow In dtdetail.Rows
                urutan = Val(drdetail("urutan"))

                'JIKA CARABAYAR GIRO(2) MAKA AMBIL AKUN BAYAR AMBIL DARI rekgiro, ELSE AKUN BAYAR AMBIL DARI rekbank
                If Double.Parse(drdetail("carabayar")) = 2 Then rekBayar = drdetail("rekgiro").ToString Else rekBayar = drdetail("rekbank").ToString

                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekBayar, "AKUN TERIMA", Double.Parse(drdetail("jumlah")), Double.Parse(drdetail("jumlahvalas")), debitkredit, drutama("ascatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If
            Next
            'END OF AKUN DEBIT -----------------------------------

            'AKUN KREDIT -----------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI UTAMA
            debitkredit = 1
            urutan = urutan + 1
            If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                  String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("asnorek").ToString, "AKUN UM PPENJUALAN", Double.Parse(drutama("asjumlah")), Double.Parse(drutama("asjumlahvalas")), debitkredit, drutama("ascatatan").ToString, drutama("ascostcenter").ToString, drutama("asdivisi").ToString, drutama("assubdivisi").ToString, drutama("asproyek").ToString, urutan)) = False Then
                rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            End If
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                   ttgljatuhtempo,                                                   ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("ascabang")) & "', '" & FixQuotes(drutama("aslokasi")) & "', '" & FixQuotes(drutama("assumber")) & "', " & 0 & ", " & drutama("asid") & ", '" & FixQuotes(drutama("asnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("astgl"))) & "', " & drutama("askodepa") & ", " & drutama("askontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("asuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("asmatauang")) & "', '" & FixDouble(drutama("askurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("astgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("astgllunas"))) & "', " & drutama("asstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("asjumlahbayar")) & "', " & drutama("asstatusbayar") & ", " & drutama("asstatus") & ", 1, NOW(), " & drutama("asjmlrevisi") & ", " & drutama("ascetakanke") & ", " & drutama("asinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("asinputtgl"), formatTglWaktuDB)) & "', " & drutama("asmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("asmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                   ttgljatuhtempo,                                                   ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("ascabang")) & "', '" & FixQuotes(drutama("aslokasi")) & "', '" & FixQuotes(drutama("assumber")) & "', " & 0 & ", " & drutama("asid") & ", '" & FixQuotes(drutama("asnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("astgl"))) & "', " & drutama("askodepa") & ", " & drutama("askontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("asuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("asmatauang")) & "', '" & FixDouble(drutama("askurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("astgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("astgllunas"))) & "', " & drutama("asstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("asjumlahbayar")) & "', " & drutama("asstatusbayar") & ", " & drutama("asstatus") & ", 1, NOW(), " & drutama("asjmlrevisi") & ", " & drutama("ascetakanke") & ", " & drutama("asinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("asinputtgl"), formatTglWaktuDB)) & "', " & drutama("asmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("asmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'AS' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING AS
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m5_as SET asposting = 1, aspostingtgl = NOW() WHERE asid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M5_Si"
    Public Function M5_Si(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'PIUTANG USAHA (D)
        'DISKON        (D)
        '           PPN KELUARAN1     (K)
        '           PPN KELUARAN2     (K)
        '           PEND. PENJUALAN   (K)
        '           PEND. LAIN        (K)

        'GROUP 2 : =====================
        'HPP           (D)
        '           PERSEDIAAN        (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow, idutama As Double = 0
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0, selisihKurs As Double = 0

        'BUAT DT JURNAL GRUP 1
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'BUAT DT JURNAL GRUP 2
        Dim dtjurnal2 As New DataTable
        AsDataTableTambahField(dtjurnal2, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal2, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal2, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal2, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT si.* FROM m5_si si WHERE (si.sistatus = 2 OR si.sistatus = 3 OR si.sistatus = 4 OR si.sistatus = 7) AND si.siid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT sid.*, i.bjenis FROM m5_si_detail sid JOIN m5_si si ON sid.idsi = si.siid JOIN m1_item i ON sid.idbarang = i.bid WHERE (si.sistatus = 2 OR si.sistatus = 3 OR si.sistatus = 4 OR si.sistatus = 7) AND si.siid = '" & idtransaksi & "'", strCon)


        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        'If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
        If dtutama.Rows.Count > 0 Then

            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            idutama = drutama("siid")
            sumber = drutama("sisumber")
            noTransaksi = drutama("sinotransaksi")
            'END OF SET DATA UTAMA -------------------------------


            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'PiutangUsaha')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN PIUTANG USAHA
            Dim rekPiutangUsaha As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'akun' AND skode = 'PiutangUsaha'", "Not found")
            If rekPiutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Receivable CoA not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------


            'AKUN DEBIT ------------------------------------------
            'PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sitotaltransaksi * kurs
            nominal = Double.Parse(drutama("sitotaltransaksi")) * Double.Parse(drutama("sikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("simatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sitotaltransaksi
                    nominalvalas = Double.Parse(drutama("sitotaltransaksi"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PIUTANG USAHA (rekPiutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekPiutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekPiutangUsaha, "PIUTANG USAHA", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~


            'DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sijmldiskon * kurs
            nominal = Double.Parse(drutama("sijmldiskon")) * Double.Parse(drutama("sikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("simatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sijmldiskon
                    nominalvalas = Double.Parse(drutama("sijmldiskon"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING DISKON (sirekdiskon)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("sirekdiskon").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("sirekdiskon").ToString, "DISKON", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            'UM PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sijmluangmuka * kurs
            nominal = Double.Parse(drutama("sijmluangmuka")) * Double.Parse(drutama("sikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("simatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sijmldiskon
                    nominalvalas = Double.Parse(drutama("sijmluangmuka"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING DISKON (sirekuangmuka)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("sirekuangmuka").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("sirekuangmuka").ToString, "UM PENJUALAN", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF UM PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN DEBIT -----------------------------------


            'AKUN KREDIT -----------------------------------------
            'PPN KELUARAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = sitotalpajak1detail * kurs
            nominal = Double.Parse(drutama("sitotalpajak1detail")) * Double.Parse(drutama("sikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("simatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sitotalpajak1detail
                    nominalvalas = Double.Parse(drutama("sitotalpajak1detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN KELUARAN1 (sirekpajak1)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("sirekpajak1").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("sirekpajak1").ToString, "PPN KELUARAN1", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN KELUARAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~


            'PPN KELUARAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = sitotalpajak2detail * kurs
            nominal = Double.Parse(drutama("sitotalpajak2detail")) * Double.Parse(drutama("sikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("simatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sitotalpajak2detail
                    nominalvalas = Double.Parse(drutama("sitotalpajak2detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN KELUARAN2 (sirekpajak2)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("sirekpajak2").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("sirekpajak2").ToString, "PPN KELUARAN2", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN KELUARAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~


            'PEND. LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = sibiayalain * kurs
            nominal = Double.Parse(drutama("sibiayalain")) * Double.Parse(drutama("sikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("simatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sibiayalain
                    nominalvalas = Double.Parse(drutama("sibiayalain"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PEND. LAIN-LAIN (sirekbiayalain)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("sirekbiayalain").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("sirekbiayalain").ToString, "PEND. LAIN-LAIN", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PEND. LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------


            Dim bjenis As String = ""

            'JURNAL DARI DATA TRANSAKSI DETAIL
            If dtdetail.Rows.Count > 0 Then
                For Each drdetail As DataRow In dtdetail.Rows

                    'GRUP 1 -----------------------------------
                    'AKUN KREDIT ++++++++++++++++++++++
                    'PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~
                    debitkredit = 1
                    'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                    If drutama("simatauang").ToString <> matauang Then
                        'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                        nominal = ((Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))) * Double.Parse(drdetail("kurs"))
                        'NOMINAL VALAS = (jml * harga) - jmldiskon
                        nominalvalas = (Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))

                        'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                    Else
                        'NOMINAL = (jml * harga) - jmldiskon
                        nominal = (Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))
                        'NOMINAL VALAS = 0 
                        nominalvalas = 0
                    End If

                    'GROUPING AKUN KREDIT (rekpenjualan)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekpenjualan").ToString & "'"
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekpenjualan").ToString, "PEND. PENJUALAN", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If
                    'END OF PEND. PENJUALAN ~~~~~~~~~~~
                    'END OF AKUN KREDIT +++++++++++++++
                    'END OF GRUP 1 ----------------------------


                    'GRUP 2 -----------------------------------
                    'SET VARIABLE
                    bjenis = drdetail("bjenis")

                    'JIKA BUKAN BARANG JASA MAKA BUAT JURNAL
                    If bjenis <> "J" Then

                        'AKUN DEBIT ------------------------------------------
                        'AKUN HPP ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                        debitkredit = 0
                        'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                        'NOMINAL = jmlbarang * hpp
                        nominal = Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))
                        If drutama("simatauang").ToString <> matauang Then
                            'NOMINAL VALAS = (jmlbarang * hpp) / kurs
                            nominalvalas = (Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))) / Double.Parse(drdetail("kurs"))

                            'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                        Else
                            'NOMINAL VALAS = 0 
                            nominalvalas = 0
                        End If

                        'GROUPING AKUN DEBIT (rekhargapokok)
                        filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekhargapokok").ToString & "'"
                        If AsDataTableDCount(dtjurnal2, filter) > 0 Then
                            nominal += Double.Parse(AsDataTableDLookup(dtjurnal2, "nominal", filter))
                            nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal2, "nominalvalas", filter))
                            If AsDataTableUpdateData(dtjurnal2, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                                rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        Else
                            If AsDataTableTambahData(dtjurnal2, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                     String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekhargapokok").ToString, "HPP", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                                rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        End If
                        'END OF AKUN HPP ~~~~~~~~~~~~~~~~~~~~~~~~~
                        'END OF AKUN DEBIT -----------------------------------


                        'AKUN KREDIT -----------------------------------------
                        'AKUN PERSEDIAAN ~~~~~~~~~~~~~~~~~~~~~~~~~
                        debitkredit = 1
                        'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                        'NOMINAL = jmlbarang * hpp
                        nominal = Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))
                        If drutama("simatauang").ToString <> matauang Then
                            'NOMINAL VALAS = (jmlbarang * hpp) / kurs
                            nominalvalas = (Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))) / Double.Parse(drdetail("kurs"))

                            'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                        Else
                            'NOMINAL VALAS = 0 
                            nominalvalas = 0
                        End If

                        'GROUPING AKUN DEBIT (rekpersediaan)
                        filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekpersediaan").ToString & "'"
                        If AsDataTableDCount(dtjurnal2, filter) > 0 Then
                            nominal += Double.Parse(AsDataTableDLookup(dtjurnal2, "nominal", filter))
                            nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal2, "nominalvalas", filter))
                            If AsDataTableUpdateData(dtjurnal2, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                                rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        Else
                            If AsDataTableTambahData(dtjurnal2, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                     String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekpersediaan").ToString, "PERSEDIAAN", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                                rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        End If
                        'END OF AKUN PERSEDIAAN ~~~~~~~~~~~~~~~~~~
                        'END OF AKUN KREDIT ----------------------------------

                    End If
                    'END OF GRUP 2 ----------------------------

                Next
            End If
            

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'JURNAL GRUP 1 ----------------------------------------
        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("sicabang")) & "', '" & FixQuotes(drutama("silokasi")) & "', '" & FixQuotes(drutama("sisumber")) & "', " & 0 & ", " & drutama("siid") & ", '" & FixQuotes(drutama("sinotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("sitgl"))) & "', " & drutama("sikodepa") & ", " & drutama("sicustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("siuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("simatauang")) & "', '" & FixDouble(drutama("sikurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("sitgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("sitgllunas"))) & "', " & FixDouble(drutama("sistatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("sisaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 2, 0, 'O', '0', 0, " & drutama("sistatus") & ", 1, NOW(), " & drutama("sijmlrevisi") & ", " & drutama("sicetakanke") & ", " & drutama("siinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("siinputtgl"), formatTglWaktuDB)) & "', " & drutama("simodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("simodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("sicabang")) & "', '" & FixQuotes(drutama("silokasi")) & "', '" & FixQuotes(drutama("sisumber")) & "', " & 0 & ", " & drutama("siid") & ", '" & FixQuotes(drutama("sinotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("sitgl"))) & "', " & drutama("sikodepa") & ", " & drutama("sicustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("siuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("simatauang")) & "', '" & FixDouble(drutama("sikurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("sitgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("sitgllunas"))) & "', " & FixDouble(drutama("sistatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("sisaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 2, 0, 'O', '0', 0, " & drutama("sistatus") & ", 1, NOW(), " & drutama("sijmlrevisi") & ", " & drutama("sicetakanke") & ", " & drutama("siinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("siinputtgl"), formatTglWaktuDB)) & "', " & drutama("simodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("simodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next
        'END OF JURNAL GRUP 1 ---------------------------------


        'JURNAL GRUP 2 ----------------------------------------
        'URUTKAN JURNAL
        dtjurnal2 = AsDataTableFilterSortDt(dtjurnal2, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal2, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal2.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("sicabang")) & "', '" & FixQuotes(drutama("silokasi")) & "', '" & FixQuotes(drutama("sisumber")) & "', " & 0 & ", " & drutama("siid") & ", '" & FixQuotes(drutama("sinotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("sitgl"))) & "', " & drutama("sikodepa") & ", " & drutama("sicustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("siuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("simatauang")) & "', '" & FixDouble(drutama("sikurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("sitgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("sitgllunas"))) & "', " & FixDouble(drutama("sistatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("sisaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 2, 0, 'O', '0', 0, " & drutama("sistatus") & ", 1, NOW(), " & drutama("sijmlrevisi") & ", " & drutama("sicetakanke") & ", " & drutama("siinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("siinputtgl"), formatTglWaktuDB)) & "', " & drutama("simodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("simodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("sicabang")) & "', '" & FixQuotes(drutama("silokasi")) & "', '" & FixQuotes(drutama("sisumber")) & "', " & 0 & ", " & drutama("siid") & ", '" & FixQuotes(drutama("sinotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("sitgl"))) & "', " & drutama("sikodepa") & ", " & drutama("sicustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("siuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("simatauang")) & "', '" & FixDouble(drutama("sikurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("sitgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("sitgllunas"))) & "', " & FixDouble(drutama("sistatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("sisaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 2, 0, 'O', '0', 0, " & drutama("sistatus") & ", 1, NOW(), " & drutama("sijmlrevisi") & ", " & drutama("sicetakanke") & ", " & drutama("siinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("siinputtgl"), formatTglWaktuDB)) & "', " & drutama("simodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("simodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next
        'END OF JURNAL GRUP 2 ---------------------------------


        'HAPUS JURNAL LAMA
        Dim sqlHapus As String = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'SI' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'BUAT SQL JURNAL
        Dim sqlJurnal As String = ""
        If Len(strValue.ToString) > 0 Then
            sqlJurnal = "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & ""
        End If

        'UPDATE STATUS POSTING JURNAL TRANSAKSI BARANG
        Dim sqlPostingIT As String = "UPDATE M1_Item_Transaction SET postingjurnal = 1 WHERE sumber = '" & sumber & "' AND idutama = '" & idutama & "'"

        'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING
        Dim sqlPosting As String = "UPDATE m5_si SET siposting = 1, sipostingtgl = NOW() WHERE siid = '" & idtransaksi & "'"


        'GABUNGKAN VALUE SQL
        rsSql = String.Concat(sqlHapus, sptRow, sqlJurnal, sptRow, sqlPostingIT, sptRow, sqlPosting)
        'END OF BUAT SQL =====================================================


        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function

    Public Function M5_SiBalance(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'PIUTANG USAHA (D)
        'DISKON        (D)
        '           PPN KELUARAN1     (K)
        '           PPN KELUARAN2     (K)
        '           PEND. LAIN        (K)


        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0, selisihKurs As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT si.* FROM m5_si si WHERE (si.sistatus = 2 OR si.sistatus = 3 OR si.sistatus = 4 OR si.sistatus = 7) AND si.siid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("sisumber")
            noTransaksi = drutama("sinotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'PiutangUsaha')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN PIUTANG USAHA
            Dim rekPiutangUsaha As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'akun' AND skode = 'PiutangUsaha'", "Not found")
            If rekPiutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Receivable CoA not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------

            'AKUN DEBIT ------------------------------------------
            'PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sitotaltransaksi * kurs
            nominal = Double.Parse(drutama("sitotaltransaksi")) * Double.Parse(drutama("sikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("simatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sitotaltransaksi
                    nominalvalas = Double.Parse(drutama("sitotaltransaksi"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PIUTANG USAHA (rekPiutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekPiutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekPiutangUsaha, "PIUTANG USAHA", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~


            'DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sijmldiskon * kurs
            nominal = Double.Parse(drutama("sijmldiskon")) * Double.Parse(drutama("sikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("simatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sijmldiskon
                    nominalvalas = Double.Parse(drutama("sijmldiskon"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING DISKON (sirekdiskon)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("sirekdiskon").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("sirekdiskon").ToString, "DISKON", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


            'UM PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sijmluangmuka * kurs
            nominal = Double.Parse(drutama("sijmluangmuka")) * Double.Parse(drutama("sikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("simatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sijmldiskon
                    nominalvalas = Double.Parse(drutama("sijmluangmuka"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING DISKON (sirekuangmuka)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("sirekuangmuka").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("sirekuangmuka").ToString, "UM PENJUALAN", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF UM PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN DEBIT -----------------------------------


            'AKUN KREDIT -----------------------------------------
            'PPN KELUARAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = sitotalpajak1detail * kurs
            nominal = Double.Parse(drutama("sitotalpajak1detail")) * Double.Parse(drutama("sikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("simatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sitotalpajak1detail
                    nominalvalas = Double.Parse(drutama("sitotalpajak1detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN KELUARAN1 (sirekpajak1)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("sirekpajak1").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("sirekpajak1").ToString, "PPN KELUARAN1", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN KELUARAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~

            'PPN KELUARAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = sitotalpajak2detail * kurs
            nominal = Double.Parse(drutama("sitotalpajak2detail")) * Double.Parse(drutama("sikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("simatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sitotalpajak2detail
                    nominalvalas = Double.Parse(drutama("sitotalpajak2detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN KELUARAN2 (sirekpajak2)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("sirekpajak2").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("sirekpajak2").ToString, "PPN KELUARAN2", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN KELUARAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~

            'PEND. LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = sibiayalain * kurs
            nominal = Double.Parse(drutama("sibiayalain")) * Double.Parse(drutama("sikurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("simatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sibiayalain
                    nominalvalas = Double.Parse(drutama("sibiayalain"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PEND. LAIN-LAIN (sirekbiayalain)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("sirekbiayalain").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("sirekbiayalain").ToString, "PEND. LAIN-LAIN", nominal, nominalvalas, debitkredit, drutama("sicatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PEND. LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("sicabang")) & "', '" & FixQuotes(drutama("silokasi")) & "', '" & FixQuotes(drutama("sisumber")) & "', " & 0 & ", " & drutama("siid") & ", '" & FixQuotes(drutama("sinotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("sitgl"))) & "', " & drutama("sikodepa") & ", " & drutama("sicustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("siuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("simatauang")) & "', '" & FixDouble(drutama("sikurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("sitgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("sitgllunas"))) & "', " & FixDouble(drutama("sistatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("sistatus") & ", 1, NOW(), " & drutama("sijmlrevisi") & ", " & drutama("sicetakanke") & ", " & drutama("siinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("siinputtgl"), formatTglWaktuDB)) & "', " & drutama("simodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("simodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("sicabang")) & "', '" & FixQuotes(drutama("silokasi")) & "', '" & FixQuotes(drutama("sisumber")) & "', " & 0 & ", " & drutama("siid") & ", '" & FixQuotes(drutama("sinotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("sitgl"))) & "', " & drutama("sikodepa") & ", " & drutama("sicustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("siuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("simatauang")) & "', '" & FixDouble(drutama("sikurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("sitgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("sitgllunas"))) & "', " & FixDouble(drutama("sistatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("sistatus") & ", 1, NOW(), " & drutama("sijmlrevisi") & ", " & drutama("sicetakanke") & ", " & drutama("siinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("siinputtgl"), formatTglWaktuDB)) & "', " & drutama("simodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("simodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'SI' AND tgrup = '1' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SI
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m5_si SET siposting = 1, sipostingtgl = NOW() WHERE siid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M5_Rp"
    Public Function M5_Rp(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'AKUN ONGKOS KIRIM (D)
        '           AKUN BAYAR (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT rp.* FROM m5_rp rp WHERE (rp.rpstatus = 2 OR rp.rpstatus = 3 OR rp.rpstatus = 4 OR rp.rpstatus = 7) AND rp.rpid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT rpd.* FROM m5_rp_pay rpd JOIN m5_rp rp ON rpd.idrp = rp.rpid WHERE (rp.rpstatus = 2 OR rp.rpstatus = 3 OR rp.rpstatus = 4 OR rp.rpstatus = 7) AND rp.rpid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("rpsumber")
            noTransaksi = drutama("rpnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AKUN DEBIT ------------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI UTAMA
            debitkredit = 0
            urutan = 1
            If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                  String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("rpnorek").ToString, "AKUN ONGKOS KIRIM", Double.Parse(drutama("rpjumlah")), Double.Parse(drutama("rpjumlahvalas")), debitkredit, drutama("rpcatatan").ToString, drutama("rpcostcenter").ToString, drutama("rpdivisi").ToString, drutama("rpsubdivisi").ToString, drutama("rpproyek").ToString, urutan)) = False Then
                rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            End If
            'END OF AKUN DEBIT -----------------------------------

            'AKUN KREDIT -----------------------------------------
            'DATA DIAMBILKAN DARI TRANSAKSI DETAIL
            debitkredit = 1
            Dim rekBayar As String = ""
            For Each drdetail As DataRow In dtdetail.Rows
                urutan = Val(drdetail("urutan")) + 1

                'JIKA CARABAYAR GIRO(2) MAKA AMBIL AKUN BAYAR AMBIL DARI rekgiro, ELSE AKUN BAYAR AMBIL DARI rekbank
                If Double.Parse(drdetail("carabayar")) = 2 Then rekBayar = drdetail("rekgiro").ToString Else rekBayar = drdetail("rekbank").ToString

                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekBayar, "AKUN BAYAR", Double.Parse(drdetail("jumlah")), Double.Parse(drdetail("jumlahvalas")), debitkredit, drutama("rpcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If
            Next
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                   ttgljatuhtempo,                                                   ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("rpcabang")) & "', '" & FixQuotes(drutama("rplokasi")) & "', '" & FixQuotes(drutama("rpsumber")) & "', " & 0 & ", " & drutama("rpid") & ", '" & FixQuotes(drutama("rpnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("rptgl"))) & "', " & drutama("rpkodepa") & ", " & drutama("rpkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("rpuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("rpmatauang")) & "', '" & FixDouble(drutama("rpkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("rptgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("rptgllunas"))) & "', " & drutama("rpstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("rpjumlahbayar")) & "', " & drutama("rpstatusbayar") & ", " & drutama("rpstatus") & ", 1, NOW(), " & drutama("rpjmlrevisi") & ", " & drutama("rpcetakanke") & ", " & drutama("rpinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rpinputtgl"), formatTglWaktuDB)) & "', " & drutama("rpmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rpmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                 tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                   ttgljatuhtempo,                                                   ttgllunas,                         tstatuslunas,    ttglrekonsiliasi, tsudahrekonsiliasi,          turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,                         tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas,       tjmlrealisasium,                    tstatusrealisasi,                   tstatus, tposting, tpostingtgl,        tjmlrevisi,                     tcetakanke,                     tinputuser,                                                tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("rpcabang")) & "', '" & FixQuotes(drutama("rplokasi")) & "', '" & FixQuotes(drutama("rpsumber")) & "', " & 0 & ", " & drutama("rpid") & ", '" & FixQuotes(drutama("rpnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("rptgl"))) & "', " & drutama("rpkodepa") & ", " & drutama("rpkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("rpuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("rpmatauang")) & "', '" & FixDouble(drutama("rpkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("rptgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("rptgllunas"))) & "', " & drutama("rpstatusbayar") & ", '1900-01-01', " & 0 & ", " & drjurnal("urutan") & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '" & FixDouble(drutama("rpjumlahbayar")) & "', " & drutama("rpstatusbayar") & ", " & drutama("rpstatus") & ", 1, NOW(), " & drutama("rpjmlrevisi") & ", " & drutama("rpcetakanke") & ", " & drutama("rpinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rpinputtgl"), formatTglWaktuDB)) & "', " & drutama("rpmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rpmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'RP' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING RP
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m5_rp SET rpposting = 1, rppostingtgl = NOW() WHERE rpid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M5_Sr"
    Public Function M5_Sr(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'RETUR PENJUALAN  (D)
        'PPN KELUARAN1    (D)
        'PPN KELUARAN2    (D)
        'PEND. LAIN       (D)
        '       DISKON         (K)
        '       PIUTANG USAHA  (K)

        'GROUP 2 : =====================
        'PERSEDIAAN       (D)
        '           HPP        (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow, idutama As Double = 0
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0

        'BUAT DT JURNAL GROUP 1
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'BUAT DT JURNAL GROUP 2
        Dim dtjurnal2 As New DataTable
        AsDataTableTambahField(dtjurnal2, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal2, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal2, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal2, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal2, "urutan", AsEnumTypeData.AsInt64)


        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT sr.* FROM m5_sr sr WHERE (sr.srstatus = 2 OR sr.srstatus = 3 OR sr.srstatus = 4 OR sr.srstatus = 7) AND sr.srid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT srd.*, i.bjenis FROM m5_sr_detail srd JOIN m5_sr sr ON srd.idsr = sr.srid JOIN m1_item i ON srd.idbarang = i.bid WHERE (sr.srstatus = 2 OR sr.srstatus = 3 OR sr.srstatus = 4 OR sr.srstatus = 7) AND sr.srid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        'If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("srsumber")
            idutama = drutama("srid")
            noTransaksi = drutama("srnotransaksi")
            'END OF SET DATA UTAMA -------------------------------


            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'PiutangUsaha')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN PIUTANG USAHA
            Dim rekPiutangUsaha As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'akun' AND skode = 'PiutangUsaha'", "Not found")
            If rekPiutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Receivable CoA not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------


            Dim bjenis As String = ""

            'JURNAL DARI DATA DETAIL
            If dtdetail.Rows.Count > 0 Then
                For Each drdetail As DataRow In dtdetail.Rows

                    'GRUP 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    'AKUN DEBIT -----------------------------
                    'RETUR PENJUALAN ++++++++++++++++++
                    debitkredit = 0

                    'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                    nominal = ((Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))) * Double.Parse(drdetail("kurs"))
                    'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                    If drutama("srmatauang").ToString <> matauang Then
                        'NOMINAL VALAS = (((jml * harga) - jmldiskon)
                        nominalvalas = ((Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon")))
                    Else
                        nominalvalas = 0
                    End If

                    'GROUPING AKUN KREDIT (rekreturpenjualan)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekreturpenjualan").ToString & "'"
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                            rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekreturpenjualan").ToString, "RETUR PENJUALAN", nominal, nominalvalas, debitkredit, drutama("srcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If
                    'END OF RETUR PENJUALAN +++++++++++
                    'END OF AKUN DEBIT ----------------------
                    'END OF GRUP 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~


                    'GRUP 2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    'SET VARIABLE
                    bjenis = drdetail("bjenis")

                    'JIKA BUKAN BARANG JASA MAKA BUAT JURNAL
                    If bjenis <> "J" Then

                        'AKUN DEBIT -------------------------
                        'AKUN HPP +++++++++++++++++++++
                        debitkredit = 1
                        'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                        'NOMINAL = jmlbarang * hpp
                        nominal = Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))
                        If drutama("srmatauang").ToString <> matauang Then
                            'NOMINAL VALAS = (jmlbarang * hpp) / kurs
                            nominalvalas = (Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))) / Double.Parse(drdetail("kurs"))

                            'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                        Else
                            'NOMINAL VALAS = 0 
                            nominalvalas = 0
                        End If

                        'GROUPING AKUN DEBIT (rekhargapokok)
                        filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekhargapokok").ToString & "'"
                        If AsDataTableDCount(dtjurnal2, filter) > 0 Then
                            nominal += Double.Parse(AsDataTableDLookup(dtjurnal2, "nominal", filter))
                            nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal2, "nominalvalas", filter))
                            If AsDataTableUpdateData(dtjurnal2, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                                rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        Else
                            If AsDataTableTambahData(dtjurnal2, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                     String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekhargapokok").ToString, "HPP", nominal, nominalvalas, debitkredit, drutama("srcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                                rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        End If
                        'END OF AKUN HPP ++++++++++++++
                        'END OF AKUN DEBIT ------------------


                        'AKUN KREDIT ------------------------
                        'AKUN PERSEDIAAN ++++++++++++++
                        debitkredit = 0
                        'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                        'NOMINAL = jmlbarang * hpp
                        nominal = Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))
                        If drutama("srmatauang").ToString <> matauang Then
                            'NOMINAL VALAS = (jmlbarang * hpp) / kurs
                            nominalvalas = (Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))) / Double.Parse(drdetail("kurs"))

                            'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                        Else
                            'NOMINAL VALAS = 0 
                            nominalvalas = 0
                        End If

                        'GROUPING AKUN DEBIT (rekpersediaan)
                        filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekpersediaan").ToString & "'"
                        If AsDataTableDCount(dtjurnal2, filter) > 0 Then
                            nominal += Double.Parse(AsDataTableDLookup(dtjurnal2, "nominal", filter))
                            nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal2, "nominalvalas", filter))
                            If AsDataTableUpdateData(dtjurnal2, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                                rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        Else
                            If AsDataTableTambahData(dtjurnal2, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                     String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekpersediaan").ToString, "PERSEDIAAN", nominal, nominalvalas, debitkredit, drutama("srcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                                rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        End If
                        'END OF AKUN PERSEDIAAN +++++++
                        'END OF AKUN KREDIT -----------------

                    End If
                    'END OF GRUP 2 ~~~~~~~~~~~~~~~~~~~~~~~~~~

                Next
            End If


            'JURNAL DARI DATA UTAMA
            'AKUN DEBIT ------------------------------------------
            'PPN KELUARAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = srtotalpajak1detail * kurs
            nominal = Double.Parse(drutama("srtotalpajak1detail")) * Double.Parse(drutama("srkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("srmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = srtotalpajak1detail
                    nominalvalas = Double.Parse(drutama("srtotalpajak1detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN KELUARAN1 (srrekpajak1)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("srrekpajak1").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("srrekpajak1").ToString, "PPN KELUARAN1", nominal, nominalvalas, debitkredit, drutama("srcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN KELUARAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~


            'PPN KELUARAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = srtotalpajak2detail * kurs
            nominal = Double.Parse(drutama("srtotalpajak2detail")) * Double.Parse(drutama("srkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("srmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = srtotalpajak2detail
                    nominalvalas = Double.Parse(drutama("srtotalpajak2detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN KELUARAN2 (srrekpajak2)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("srrekpajak2").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("srrekpajak2").ToString, "PPN KELUARAN2", nominal, nominalvalas, debitkredit, drutama("srcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN KELUARAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~


            'PEND. LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = srbiayalain * kurs
            nominal = Double.Parse(drutama("srbiayalain")) * Double.Parse(drutama("srkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("srmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = srbiayalain
                    nominalvalas = Double.Parse(drutama("srbiayalain"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PEND. LAIN-LAIN (srrekbiayalain)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("srrekbiayalain").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("srrekbiayalain").ToString, "PEND. LAIN-LAIN", nominal, nominalvalas, debitkredit, drutama("srcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PEND. LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN DEBIT -----------------------------------


            'AKUN KREDIT -----------------------------------------
            'PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = srtotaltransaksi * kurs
            nominal = Double.Parse(drutama("srtotaltransaksi")) * Double.Parse(drutama("srkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("srmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = srtotaltransaksi
                    nominalvalas = Double.Parse(drutama("srtotaltransaksi"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PIUTANG USAHA (rekPiutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekPiutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekPiutangUsaha, "PIUTANG USAHA", nominal, nominalvalas, debitkredit, drutama("srcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~


            'DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = srjmldiskon * kurs
            nominal = Double.Parse(drutama("srjmldiskon")) * Double.Parse(drutama("srkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("srmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = srjmldiskon
                    nominalvalas = Double.Parse(drutama("srjmldiskon"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING DISKON (srrekdiskon)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("srrekdiskon").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("srrekdiskon").ToString, "DISKON", nominal, nominalvalas, debitkredit, drutama("srcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder
        Dim jGrup As Integer = 0

        'JURNAL GRUP 1 -------------------------------------------
        jGrup = 1

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,             tsaldoawal, tadjustment,                       tcostcenter,                                tdivisi,                                 tsubdivisi,                                tproyek,                                tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("srcabang")) & "', '" & FixQuotes(drutama("srlokasi")) & "', '" & FixQuotes(drutama("srsumber")) & "', " & 0 & ", " & drutama("srid") & ", '" & FixQuotes(drutama("srnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("srtgl"))) & "', " & drutama("srkodepa") & ", " & drutama("srcustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("sruraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("srmatauang")) & "', '" & FixDouble(drutama("srkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("srtgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("srtgllunas"))) & "', " & FixDouble(drutama("srstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("srsaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', " & FixDouble(jGrup) & ", 0, 'O', '0', 0, " & drutama("srstatus") & ", 1, NOW(), " & drutama("srjmlrevisi") & ", " & drutama("srcetakanke") & ", " & drutama("srinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("srinputtgl"), formatTglWaktuDB)) & "', " & drutama("srmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("srmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,             tsaldoawal, tadjustment,                       tcostcenter,                                tdivisi,                                 tsubdivisi,                                tproyek,                                tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("srcabang")) & "', '" & FixQuotes(drutama("srlokasi")) & "', '" & FixQuotes(drutama("srsumber")) & "', " & 0 & ", " & drutama("srid") & ", '" & FixQuotes(drutama("srnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("srtgl"))) & "', " & drutama("srkodepa") & ", " & drutama("srcustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("sruraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("srmatauang")) & "', '" & FixDouble(drutama("srkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("srtgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("srtgllunas"))) & "', " & FixDouble(drutama("srstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("srsaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', " & FixDouble(jGrup) & ", 0, 'O', '0', 0, " & drutama("srstatus") & ", 1, NOW(), " & drutama("srjmlrevisi") & ", " & drutama("srcetakanke") & ", " & drutama("srinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("srinputtgl"), formatTglWaktuDB)) & "', " & drutama("srmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("srmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next
        'END OF JURNAL GRUP 1 ------------------------------------


        'JURNAL GRUP 2 -------------------------------------------
        jGrup = 2

        'URUTKAN JURNAL
        dtjurnal2 = AsDataTableFilterSortDt(dtjurnal2, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal2, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal2.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,             tsaldoawal, tadjustment,                       tcostcenter,                                tdivisi,                                 tsubdivisi,                                tproyek,                                tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("srcabang")) & "', '" & FixQuotes(drutama("srlokasi")) & "', '" & FixQuotes(drutama("srsumber")) & "', " & 0 & ", " & drutama("srid") & ", '" & FixQuotes(drutama("srnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("srtgl"))) & "', " & drutama("srkodepa") & ", " & drutama("srcustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("sruraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("srmatauang")) & "', '" & FixDouble(drutama("srkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("srtgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("srtgllunas"))) & "', " & FixDouble(drutama("srstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("srsaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', " & FixDouble(jGrup) & ", 0, 'O', '0', 0, " & drutama("srstatus") & ", 1, NOW(), " & drutama("srjmlrevisi") & ", " & drutama("srcetakanke") & ", " & drutama("srinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("srinputtgl"), formatTglWaktuDB)) & "', " & drutama("srmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("srmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,             tsaldoawal, tadjustment,                       tcostcenter,                                tdivisi,                                 tsubdivisi,                                tproyek,                                tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("srcabang")) & "', '" & FixQuotes(drutama("srlokasi")) & "', '" & FixQuotes(drutama("srsumber")) & "', " & 0 & ", " & drutama("srid") & ", '" & FixQuotes(drutama("srnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("srtgl"))) & "', " & drutama("srkodepa") & ", " & drutama("srcustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("sruraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("srmatauang")) & "', '" & FixDouble(drutama("srkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("srtgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("srtgllunas"))) & "', " & FixDouble(drutama("srstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("srsaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', " & FixDouble(jGrup) & ", 0, 'O', '0', 0, " & drutama("srstatus") & ", 1, NOW(), " & drutama("srjmlrevisi") & ", " & drutama("srcetakanke") & ", " & drutama("srinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("srinputtgl"), formatTglWaktuDB)) & "', " & drutama("srmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("srmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next
        'END OF JURNAL GRUP 2 ------------------------------------


        'HAPUS JURNAL LAMA
        Dim sqlHapus As String = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'SR' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'BUAT SQL JURNAL
        Dim sqlJurnal As String = ""
        If Len(strValue.ToString) > 0 Then
            sqlJurnal = "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & ""
        End If

        'UPDATE STATUS POSTING JURNAL TRANSAKSI BARANG
        Dim sqlPostingIT As String = "UPDATE M1_Item_Transaction SET postingjurnal = 1 WHERE sumber = '" & sumber & "' AND idutama = '" & idutama & "'"

        'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING
        Dim sqlPosting As String = "UPDATE m5_sr SET srposting = 1, srpostingtgl = NOW() WHERE srid = '" & idtransaksi & "'"


        'GABUNGKAN VALUE SQL
        rsSql = String.Concat(sqlHapus, sptRow, sqlJurnal, sptRow, sqlPostingIT, sptRow, sqlPosting)
        'END OF BUAT SQL =====================================================


        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function

    Public Function M5_SrBalance(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'PPN KELUARAN1    (D)
        'PPN KELUARAN2    (D)
        'PEND. LAIN       (D)
        '       DISKON         (K)
        '       PIUTANG USAHA  (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0

        'BUAT DT JURNAL GROUP 1
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT sr.* FROM m5_sr sr WHERE (sr.srstatus = 2 OR sr.srstatus = 3 OR sr.srstatus = 4 OR sr.srstatus = 7) AND sr.srid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)
            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("srsumber")
            noTransaksi = drutama("srnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'PiutangUsaha')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN PIUTANG USAHA
            Dim rekPiutangUsaha As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'akun' AND skode = 'PiutangUsaha'", "Not found")
            If rekPiutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Receivable CoA not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------

            'AKUN DEBIT ------------------------------------------
            'PPN KELUARAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = srtotalpajak1detail * kurs
            nominal = Double.Parse(drutama("srtotalpajak1detail")) * Double.Parse(drutama("srkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("srmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = srtotalpajak1detail
                    nominalvalas = Double.Parse(drutama("srtotalpajak1detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN KELUARAN1 (srrekpajak1)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("srrekpajak1").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("srrekpajak1").ToString, "PPN KELUARAN1", nominal, nominalvalas, debitkredit, drutama("srcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN KELUARAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~

            'PPN KELUARAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = srtotalpajak2detail * kurs
            nominal = Double.Parse(drutama("srtotalpajak2detail")) * Double.Parse(drutama("srkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("srmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = srtotalpajak2detail
                    nominalvalas = Double.Parse(drutama("srtotalpajak2detail"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PPN KELUARAN2 (srrekpajak2)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("srrekpajak2").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("srrekpajak2").ToString, "PPN KELUARAN2", nominal, nominalvalas, debitkredit, drutama("srcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PPN KELUARAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~

            'PEND. LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = srbiayalain * kurs
            nominal = Double.Parse(drutama("srbiayalain")) * Double.Parse(drutama("srkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("srmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = srbiayalain
                    nominalvalas = Double.Parse(drutama("srbiayalain"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PEND. LAIN-LAIN (srrekbiayalain)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("srrekbiayalain").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("srrekbiayalain").ToString, "PEND. LAIN-LAIN", nominal, nominalvalas, debitkredit, drutama("srcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PEND. LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN DEBIT -----------------------------------

            'AKUN KREDIT -----------------------------------------
            'PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = srtotaltransaksi * kurs
            nominal = Double.Parse(drutama("srtotaltransaksi")) * Double.Parse(drutama("srkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("srmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = srtotaltransaksi
                    nominalvalas = Double.Parse(drutama("srtotaltransaksi"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PIUTANG USAHA (rekPiutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekPiutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekPiutangUsaha, "PIUTANG USAHA", nominal, nominalvalas, debitkredit, drutama("srcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~

            'DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = srjmldiskon * kurs
            nominal = Double.Parse(drutama("srjmldiskon")) * Double.Parse(drutama("srkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("srmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = srjmldiskon
                    nominalvalas = Double.Parse(drutama("srjmldiskon"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING DISKON (srrekdiskon)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("srrekdiskon").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("srrekdiskon").ToString, "DISKON", nominal, nominalvalas, debitkredit, drutama("srcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================

        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder
        Dim jGrup As Integer = 0

        'JURNAL GRUP 1 -------------------------------------------
        jGrup = 1

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                              tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,                                tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("srcabang")) & "', '" & FixQuotes(drutama("srlokasi")) & "', '" & FixQuotes(drutama("srsumber")) & "', " & 0 & ", " & drutama("srid") & ", '" & FixQuotes(drutama("srnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("srtgl"))) & "', " & drutama("srkodepa") & ", " & drutama("srcustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("sruraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("srmatauang")) & "', '" & FixDouble(drutama("srkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("srtgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("srtgllunas"))) & "', " & FixDouble(drutama("srstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', " & FixDouble(jGrup) & ", 0, 'O', '0', 0, " & drutama("srstatus") & ", 1, NOW(), " & drutama("srjmlrevisi") & ", " & drutama("srcetakanke") & ", " & drutama("srinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("srinputtgl"), formatTglWaktuDB)) & "', " & drutama("srmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("srmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                              tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,                                tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("srcabang")) & "', '" & FixQuotes(drutama("srlokasi")) & "', '" & FixQuotes(drutama("srsumber")) & "', " & 0 & ", " & drutama("srid") & ", '" & FixQuotes(drutama("srnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("srtgl"))) & "', " & drutama("srkodepa") & ", " & drutama("srcustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("sruraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("srmatauang")) & "', '" & FixDouble(drutama("srkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("srtgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("srtgllunas"))) & "', " & FixDouble(drutama("srstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', " & FixDouble(jGrup) & ", 0, 'O', '0', 0, " & drutama("srstatus") & ", 1, NOW(), " & drutama("srjmlrevisi") & ", " & drutama("srcetakanke") & ", " & drutama("srinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("srinputtgl"), formatTglWaktuDB)) & "', " & drutama("srmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("srmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next
        'END OF JURNAL GRUP 1 ------------------------------------


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'SR' AND tgrup = '" & FixDouble(jGrup) & "' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SR
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m5_sr SET srposting = 1, srpostingtgl = NOW() WHERE srid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M5_Pv"
    Public Function M5_Pv(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'AKUN AS            (D) -------------------> UANG MUKA PENJUALAN
        'AKUN IP            (D) -------------------> TERIMA PEMBAYARAN
        'AKUN SR            (D) -------------------> RETUR PENJUALAN
        'COA < 0            (D) -------------------> COA
        'SELISIH KURS < 0   (D) -------------------> SELISIH KURS
        '               AKUN SI            (K) ----> INVOICE PENJUALAN
        '               AKUN RP            (K) ----> PIUTANG ONGKOS KIRIM
        '               COA > 0            (K) ----> COA
        '               SELISIH KURS > 0   (K) ----> SELISIH KURS

        'JIKA ADA SELISIH TOTAL AP DAN TOTAL AR MAKA MASUK KE AKUN SETTING SELISIH HUTANG PIUTANG

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, debitkreditgroup As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0, selisihKurs As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT pv.* FROM m5_pv pv WHERE (pv.pvstatus = 2 OR pv.pvstatus = 3 OR pv.pvstatus = 4 OR pv.pvstatus = 7) AND pv.pvid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT pvd.* FROM m5_pv_detail pvd JOIN m5_pv pv ON pvd.idpv = pv.pvid WHERE (pv.pvstatus = 2 OR pv.pvstatus = 3 OR pv.pvstatus = 4 OR pv.pvstatus = 7) AND pv.pvid = '" & idtransaksi & "'", strCon)

        Dim rekSelisihKurs As String = "", rekSelisihHP As String = "", matauang As String = "", kurs As String = ""

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then

            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("pvsumber")
            noTransaksi = drutama("pvnotransaksi")
            rekSelisihKurs = drutama("pvrekselisihkurs")
            'END OF SET DATA UTAMA -------------------------------


            'AMBIL DATA DARI SETTING -----------------------------
            dtMatauang = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 0 AND sgrup = 'akun' AND skode = 'SelisihHutangPiutang')", strCon)
            'MATAUANG
            matauang = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            kurs = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'REK SELISIH HUTANG PIUTANG
            rekSelisihHP = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'akun' AND skode = 'SelisihHutangPiutang'", "Not found")
            If rekSelisihHP = "Not found" Then
                rsErrMessage = "Setting Account of Difference AP/AR not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------


            'BUAT JURNAL TRANSAKSI -------------------------------
            'DATA DIAMBILKAN DARI DATA DETAIL
            For Each drdetail As DataRow In dtdetail.Rows
                'JIKA (SUMBER = SI) ATAU (SUMBER = RP) ATAU (SUMBER = CA DAN JMLBAYAR > 0) MAKA KREDIT, ELSE MAKA DEBIT
                If drdetail("sumber") = "SI" Or drdetail("sumber") = "RP" Or (drdetail("sumber") = "CA" And Double.Parse(drdetail("jmlbayar")) > 0) Then
                    debitkredit = 1
                Else
                    debitkredit = 0
                End If

                'NOMINAL = jmlbayar
                nominal = Math.Abs(Double.Parse(drdetail("jmlbayar")))
                'NOMINALVALAS = jmlbayarvalas
                nominalvalas = Math.Abs(Double.Parse(drdetail("jmlbayarvalas")))

                'GROUPING AKUN (rekhutangpiutang)
                filter = "norek='" & drdetail("rekhutangpiutang").ToString & "'"
                'CEK AKUN SUDAH ADA ATAU BELUM PADA DT JURNAL
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    'JIKA ADA, CEK AKUN TERSEBUT DEBIT / KREDIT
                    debitkreditgroup = Double.Parse(AsDataTableDLookup(dtjurnal, "debitkredit", filter))
                    If debitkreditgroup = debitkredit Then
                        'JIKA AKUN SAMA-SAMA DEBIT/SAMA-SAMA KREDIT MAKA TAMBAHKAN NOMINALNYA SAJA
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        'UPDATE NOMINAL AKUN PADA DT JURNAL
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                            rsErrMessage = "Failed update grouping datatable journal transaction #1 " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If

                    Else
                        'JIKA AKUN BERBEDA DEBIT KREDITNYA MAKA NOMINAL BARU = NOMINAL AKUN PADA DT JURNAL - NOMINAL AKUN
                        nominal = Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter)) - nominal
                        nominalvalas = Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter)) - nominalvalas
                        'CEK NOMINAL BARU, JIKA NOMINAL BARU < 1 MAKA PINDAH SISI DEBIT DAN KREDITNYA
                        If nominal < 0 Then
                            'ABSOLUTKAN NILAI NOMINAL
                            nominal = Math.Abs(nominal)
                            nominalvalas = Math.Abs(nominalvalas)
                            'UPDATE NOMINAL DAN DEBITKREDIT DT JURNAL
                            If debitkreditgroup = 0 Then
                                'JIKA AKUN PADA DT JURNAL DEBIT MAKA DIPINDAH KE KREDIT
                                If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas~debitkredit", nominal & "~" & nominalvalas & "~" & 1) = False Then
                                    rsErrMessage = "Failed update grouping datatable journal transaction #2 " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                                End If
                            Else
                                'JIKA AKUN PADA DT JURNAL KREDIT MAKA DIPINDAH KE DEBIT
                                If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas~debitkredit", nominal & "~" & nominalvalas & "~" & 0) = False Then
                                    rsErrMessage = "Failed update grouping datatable journal transaction #3 " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                                End If
                            End If

                            'JIKA NOMINAL BARU >= 0 MAKA UPDATE NOMINALNYA SAJA
                        Else
                            'UPDATE NOMINAL AKUN PADA DT JURNAL
                            If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                                rsErrMessage = "Failed update grouping datatable journal transaction #4 " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        End If
                    End If

                    'JIKA TIDAK ADA, TAMBAHKAN AKUN PADA DT JURNAL
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekhutangpiutang").ToString, drdetail("sumber").ToString, nominal, nominalvalas, debitkredit, drutama("pvcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal transaction " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If

            Next
            'END OF BUAT JURNAL TRANSAKSI ------------------------


            'BUAT JURNAL SELISIH KURS ----------------------------
            If Double.Parse(drutama("pvselisihkurs")) > 0 Then
                'JIKA SELISIH KURS > 0 MAKA KREDIT
                debitkredit = 1
                nominal = Math.Abs(Double.Parse(drutama("pvselisihkurs")))
                nominalvalas = 0
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                          String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("pvrekselisihkurs").ToString, "SELISIH KURS", nominal, nominalvalas, debitkredit, drutama("pvcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal difference rate " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If

            ElseIf Double.Parse(drutama("pvselisihkurs")) < 0 Then
                'JIKA SELISIH KURS < 0 MAKA DEBIT
                debitkredit = 0
                nominal = Math.Abs(Double.Parse(drutama("pvselisihkurs")))
                nominalvalas = 0
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                          String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("pvrekselisihkurs").ToString, "SELISIH KURS", nominal, nominalvalas, debitkredit, drutama("pvcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal difference rate " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If

            End If
            'END OF BUAT JURNAL SELISIH KURS ---------------------


            'BUAT JURNAL DISKON TERMIN ---------------------------
            If Double.Parse(drutama("pvdiskontermin")) <> 0 Then
                'JIKA DISKON TERMIN <> 0 MAKA KREDIT
                debitkredit = 0
                nominal = Double.Parse(drutama("pvdiskontermin"))
                nominalvalas = Double.Parse(drutama("pvdiskonterminvalas"))
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                          String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("pvrekdiskontermin").ToString, "DISKON TERMIN", nominal, nominalvalas, debitkredit, drutama("pvcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal difference rate " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If
            End If
            'END OF BUAT JURNAL DISKON TERMIN --------------------


            'BUAT SELISIH HUTANG PIUTANG -------------------------
            Dim JmlSI As Double = 0, JmlRP As Double = 0, JmlCoa As Double = 0
            Dim JmlIP As Double = 0, JmlAS As Double = 0, JmlSR As Double = 0
            Dim TotalAP As Double = 0, TotalAR As Double = 0

            'TOTAL AR = RI + RP + COA
            JmlSI = AsDataTableDSum(dtdetail, "jmlbayar", "sumber = 'SI'") - AsDataTableDSum(dtdetail, "jmldiskontermin", "sumber = 'SI'")
            JmlRP = AsDataTableDSum(dtdetail, "jmlbayar", "sumber = 'RP'") - AsDataTableDSum(dtdetail, "jmldiskontermin", "sumber = 'RP'")
            JmlCoa = AsDataTableDSum(dtdetail, "jmlbayar", "sumber = 'CA'") - AsDataTableDSum(dtdetail, "jmldiskontermin", "sumber = 'CA'")
            TotalAR = JmlSI + JmlRP + JmlCoa

            'TOTAL AP = IP + AS + SR
            JmlIP = AsDataTableDSum(dtdetail, "jmlbayar", "sumber = 'IP'") - AsDataTableDSum(dtdetail, "jmldiskontermin", "sumber = 'IP'")
            JmlAS = AsDataTableDSum(dtdetail, "jmlbayar", "sumber = 'AS'") - AsDataTableDSum(dtdetail, "jmldiskontermin", "sumber = 'AS'")
            JmlSR = AsDataTableDSum(dtdetail, "jmlbayar", "sumber = 'SR'") - AsDataTableDSum(dtdetail, "jmldiskontermin", "sumber = 'SR'")
            TotalAP = JmlIP + JmlAS + JmlSR


            If TotalAR - TotalAP > 0 Then
                'JIKA SELISIH AR - AP > 0 MAKA JURNAL PEMBULATAN DISISI DEBIT
                debitkredit = 0
                nominal = F_RoundDecimal(Math.Abs(TotalAR - TotalAP))
                nominalvalas = 0
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                           String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekSelisihHP, "SELISIH HUTANG PIUTANG", nominal, nominalvalas, debitkredit, drutama("pvcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal difference rate " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If

            ElseIf TotalAR - TotalAP < 0 Then
                'JIKA SELISIH AR - AP < 0 MAKA JURNAL PEMBULATAN DISISI KREDIT
                debitkredit = 1
                nominal = F_RoundDecimal(Math.Abs(TotalAR - TotalAP))
                nominalvalas = 0
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                           String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekSelisihHP, "SELISIH HUTANG PIUTANG", nominal, nominalvalas, debitkredit, drutama("pvcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal difference rate " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If

            End If
            'END OF BUAT SELISIH HUTANG PIUTANG ------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                                                                                tmatauang,                                                                                            tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                        ttgljatuhtempo,                                         ttgllunas,          tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("pvcabang")) & "', '" & FixQuotes(drutama("pvlokasi")) & "', '" & FixQuotes(drutama("pvsumber")) & "', " & 0 & ", " & drutama("pvid") & ", '" & FixQuotes(drutama("pvnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("pvtgl"))) & "', " & drutama("pvkodepa") & ", " & drutama("pvcustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("pvuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & IIf(drjurnal("norek") = rekSelisihKurs, FixQuotes(matauang), FixQuotes(drutama("pvmatauang"))) & "', '" & IIf(drjurnal("norek") = rekSelisihKurs, FixDouble(kurs), FixDouble(drutama("pvkurs"))) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', " & FixDouble(0) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("pvstatus") & ", 1, NOW(), " & drutama("pvjmlrevisi") & ", " & drutama("pvcetakanke") & ", " & drutama("pvinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("pvinputtgl"), formatTglWaktuDB)) & "', " & drutama("pvmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("pvmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                                                                                tmatauang,                                                                                            tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                        ttgljatuhtempo,                                         ttgllunas,          tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("pvcabang")) & "', '" & FixQuotes(drutama("pvlokasi")) & "', '" & FixQuotes(drutama("pvsumber")) & "', " & 0 & ", " & drutama("pvid") & ", '" & FixQuotes(drutama("pvnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("pvtgl"))) & "', " & drutama("pvkodepa") & ", " & drutama("pvcustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("pvuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & IIf(drjurnal("norek") = rekSelisihKurs, FixQuotes(matauang), FixQuotes(drutama("pvmatauang"))) & "', '" & IIf(drjurnal("norek") = rekSelisihKurs, FixDouble(kurs), FixDouble(drutama("pvkurs"))) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', '" & FixQuotes(AsFormatTanggal("1900-01-01")) & "', " & FixDouble(0) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("pvstatus") & ", 1, NOW(), " & drutama("pvjmlrevisi") & ", " & drutama("pvcetakanke") & ", " & drutama("pvinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("pvinputtgl"), formatTglWaktuDB)) & "', " & drutama("pvmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("pvmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'PV' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING PV
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m5_pv SET pvposting = 1, pvpostingtgl = NOW() WHERE pvid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

    '********************************************** M6 **********************************************

#Region "M6_Pd"
    Public Function M6_Pd(ByVal idtransaksi As Integer) As String 'progress?errMessage?sqljurnal?sqlupdateposting
        'PERSEDIAAN BARANG HASIL (D)
        '           PERSEDIAAN BARANG BAHAN     (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = ""
        Dim sumber As String = "", noTransaksi As String = "", filter As String = ""
        Dim sql As String = "", idutama As Double = 0, iddetail As Double = 0

        Dim dtutama As New DataTable, dtDetailIn As New DataTable, dtDetailOut As New DataTable
        Dim drutama As DataRow, dtSaldo As New DataTable, dt As New DataTable
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0
        Dim sqlPosting As String = "", sqlJurnal As String = ""

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)


        'AMBIL DATA DARI SETTING ---------------------------------
        Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs')", strCon)
        'MATAUANG
        Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
        If matauang = "Not found" Then
            rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
        End If
        'KURS
        Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
        If kurs = "Not found" Then
            rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
        End If
        'END OF AMBIL DATA DARI SETTING --------------------------


        'AMBIL DATA ----------------------------------------------
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT pd.* FROM M6_pd pd WHERE (pd.pdstatus = 2 OR pd.pdstatus = 3 OR pd.pdstatus = 4 OR pd.pdstatus = 7) AND pd.pdid = '" & idtransaksi & "'", strCon)


        'SET DATA UTAMA ====================================================
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            idutama = drutama("pdid")
            sumber = drutama("pdsumber")
            noTransaksi = drutama("pdnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF SET DATA UTAMA =============================================


        'BUAT JURNAL HPP PERSEDIAAN ========================================
        'DETAIL IN
        dtDetailIn = AsDataTableAmbilDariDB("SELECT pdi.* FROM M6_pd_in pdi JOIN M6_pd pd ON pdi.idpd = pd.pdid JOIN m1_item i ON pdi.idbarang = i.bid  WHERE (pd.pdstatus = 2 OR pd.pdstatus = 3 OR pd.pdstatus = 4 OR pd.pdstatus = 7) AND pd.pdid = '" & idtransaksi & "'", strCon)
        'DETAIL OUT
        dtDetailOut = AsDataTableAmbilDariDB("SELECT pdo.* FROM M6_pd_out pdo JOIN M6_pd pd ON pdo.idpd = pd.pdid JOIN m1_item i ON pdo.idbarang = i.bid  WHERE (pd.pdstatus = 2 OR pd.pdstatus = 3 OR pd.pdstatus = 4 OR pd.pdstatus = 7) AND pd.pdid = '" & idtransaksi & "'", strCon)

        If dtutama.Rows.Count > 0 And dtDetailIn.Rows.Count > 0 And dtDetailOut.Rows.Count > 0 Then

            'AKUN DEBIT ------------------------------------------
            'BARANG HASIL
            For Each drdetail As DataRow In dtDetailIn.Rows

                debitkredit = 0
                'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                'NOMINAL = jmlbarang * hpp
                nominal = Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))
                If drutama("pdmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = (jmlbarang * hpp) / kurs
                    nominalvalas = (Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))) / Double.Parse(drdetail("kurs"))

                    'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                Else
                    'NOMINAL VALAS = 0 
                    nominalvalas = 0
                End If

                'GROUPING AKUN DEBIT (rekpersediaan)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekpersediaan").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekpersediaan").ToString, "PERSEDIAAN MASUK", nominal, nominalvalas, debitkredit, drutama("pdcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            Next
            'END OF AKUN DEBIT -----------------------------------


            'AKUN KREDIT -----------------------------------------
            'BARANG BAHAN
            For Each drdetail As DataRow In dtDetailOut.Rows

                debitkredit = 1
                'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                'NOMINAL = jmlbarang * hpp
                nominal = Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))
                If drutama("pdmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = (jmlbarang * hpp) / kurs
                    nominalvalas = (Double.Parse(drdetail("jmlbarang")) * Double.Parse(drdetail("hpp"))) / Double.Parse(drdetail("kurs"))

                    'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                Else
                    'NOMINAL VALAS = 0 
                    nominalvalas = 0
                End If

                'GROUPING AKUN DEBIT (rekpersediaan)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekpersediaan").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekpersediaan").ToString, "PERSEDIAAN KELUAR", nominal, nominalvalas, debitkredit, drutama("pdcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            Next
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF BUAT JURNAL HPP PERSEDIAAN ===================================


        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,ttgljatuhtempo,ttgllunas,tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("pdcabang")) & "', '" & FixQuotes(drutama("pdlokasi")) & "', '" & FixQuotes(drutama("pdsumber")) & "', " & 0 & ", " & drutama("pdid") & ", '" & FixQuotes(drutama("pdnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("pdtgl"))) & "', " & drutama("pdkodepa") & ", " & drutama("pdbagianpd") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("pduraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("pdmatauang")) & "', '" & FixDouble(drutama("pdkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("pdstatus") & ", 1, NOW(), " & drutama("pdjmlrevisi") & ", " & drutama("pdcetakanke") & ", " & drutama("pdinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("pdinputtgl"), formatTglWaktuDB)) & "', " & drutama("pdmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("pdmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,ttgljatuhtempo,ttgllunas,tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("pdcabang")) & "', '" & FixQuotes(drutama("pdlokasi")) & "', '" & FixQuotes(drutama("pdsumber")) & "', " & 0 & ", " & drutama("pdid") & ", '" & FixQuotes(drutama("pdnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("pdtgl"))) & "', " & drutama("pdkodepa") & ", " & drutama("pdbagianpd") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("pduraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("pdmatauang")) & "', '" & FixDouble(drutama("pdkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("pdstatus") & ", 1, NOW(), " & drutama("pdjmlrevisi") & ", " & drutama("pdcetakanke") & ", " & drutama("pdinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("pdinputtgl"), formatTglWaktuDB)) & "', " & drutama("pdmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("pdmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'HAPUS JURNAL LAMA
        Dim sqlHapus As String = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'PD' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'BUAT SQL JURNAL
        If Len(strValue.ToString) > 0 Then
            sqlJurnal = "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & ""
        End If

        'UPDATE STATUS POSTING JURNAL TRANSAKSI BARANG
        Dim sqlPostingIT As String = "UPDATE M1_Item_Transaction SET postingjurnal = 1 WHERE sumber = '" & sumber & "' AND idutama = '" & idutama & "'"

        'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING PD
        sqlPosting = "UPDATE M6_pd SET pdposting = 1, pdpostingtgl = NOW() WHERE pdid = '" & idtransaksi & "'"

        'GABUNGKAN VALUE SQL
        rsSql = String.Concat(sqlHapus, sptRow, sqlJurnal, sptRow, sqlPostingIT, sptRow, sqlPosting)
        'END OF BUAT SQL ================================================


        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

    '********************************************** M7 **********************************************

#Region "M7_Da"
    Public Function M7_Da(ByVal idtransaksi As Integer) As String 'progress?errMessage?sqljurnal?sqlupdateposting
        'BIAYA PENYUSUTAN (D)
        '         AKUM. BIAYA PENYUSUTAN (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = ""
        Dim sumber As String = "", noTransaksi As String = "", filter As String = ""
        Dim sql As String = "", idutama As Double = 0, iddetail As Double = 0

        Dim dtutama As New DataTable, dtDetail As New DataTable
        Dim drutama As DataRow, dtSaldo As New DataTable, dt As New DataTable
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0

        Dim sqlJurnal As String = "", sqlPosting As String = ""

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt16) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)


        '//TRANSAKSI KE DATABASE ****************************************************************
        Dim objCmd As MySql.Data.MySqlClient.MySqlCommand
        Dim Trans As MySql.Data.MySqlClient.MySqlTransaction


        Con1 = New MySql.Data.MySqlClient.MySqlConnection(strCon)
        Con1.Open()

        '******* Start Transaction ******'
        Trans = Con1.BeginTransaction(IsolationLevel.ReadCommitted)

        Try

            'AMBIL DATA DARI SETTING ---------------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : Trans.Rollback() : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : Trans.Rollback() : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING --------------------------


            'AMBIL DATA ----------------------------------------------
            'UTAMA
            dtutama = AsDataTableAmbilDariDB("SELECT Da.* FROM M7_Da Da WHERE (Da.Dastatus = 2 OR Da.Dastatus = 3 OR Da.Dastatus = 4 OR Da.Dastatus = 7) AND Da.Daid = '" & idtransaksi & "'", strCon)
            'DETAIL
            dtDetail = AsDataTableAmbilDariDB("SELECT Dad.*, a.abebanperbln, a.arekakumdepresiasi, a.arekdepresiasi FROM M7_Da_detail Dad JOIN M7_Da Da ON Dad.idDa = Da.Daid JOIN m7_asset a ON Dad.idaset = a.aid WHERE (Da.Dastatus = 2 OR Da.Dastatus = 3 OR Da.Dastatus = 4 OR Da.Dastatus = 7) AND Da.Daid = '" & idtransaksi & "'", strCon)


            'SET DATA UTAMA ====================================================
            If dtutama.Rows.Count > 0 Then
                'SET DATA UTAMA --------------------------------------
                drutama = dtutama.Rows(0)

                'SET SUMBER DAN NOTRANSAKSI
                idutama = drutama("Daid")
                sumber = drutama("Dasumber")
                noTransaksi = drutama("Danotransaksi")
                'END OF SET DATA UTAMA -------------------------------

            Else
                'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
                rsProgress = 4 : GoTo selesai
            End If
            'END OF SET DATA UTAMA =============================================


            'PROSES JURNAL =====================================================
            'JIKA TERDAPAT DATA TRANSAKSI MAKA BUAT JURNAL
            If dtDetail.Rows.Count > 0 Then

                For Each dr1 As DataRow In dtDetail.Rows
                    'SET VARIABEL
                    iddetail = Double.Parse(dr1("iddadetail"))

                    ''PROSES UPDATE ASSET DAN TRANSAKSI
                    'sql = "UPDATE m7_asset a JOIN m7_da_detail dad ON a.aid = dad.idaset SET a.apenyusutanke = a.apenyusutanke + 1, a.aakumulasibeban = a.aakumulasibeban + (dad.nilaipenyusutan * dad.kurs), a.anilaibuku = a.anilaibuku - (dad.nilaipenyusutan * dad.kurs), dad.penyusutanke = a.apenyusutanke WHERE dad.iddadetail = '" & FixDouble(iddetail) & "'"
                    'objCmd = New MySql.Data.MySqlClient.MySqlCommand()
                    'With objCmd
                    '    .Connection = Con1
                    '    .Transaction = Trans
                    '    .CommandType = CommandType.Text
                    '    .CommandText = sql
                    'End With
                    'objCmd.ExecuteNonQuery()

                    'PROSES JURNAL ---------------------------------------
                    'AKUN DEBIT ~~~~~~~~~~~~~~~~~~~~~~~~~
                    debitkredit = 0

                    'NOMINAL = nilaipenyusutan * kurs
                    nominal = Double.Parse(FixDouble(dr1("nilaipenyusutan"))) * Double.Parse(FixDouble(dr1("kurs")))

                    'GROUPING AKUN DEBIT (arekdepresiasi)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & dr1("arekdepresiasi").ToString & "'"
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                            rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : Trans.Rollback() : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", dr1("arekdepresiasi").ToString, "BIAYA PENYUSUTAN", nominal, nominalvalas, debitkredit, drutama("Dacatatan").ToString, dr1("costcenter").ToString, dr1("divisi").ToString, dr1("subdivisi").ToString, dr1("proyek").ToString, urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : Trans.Rollback() : GoTo selesai
                        End If
                    End If
                    'END OF AKUN DEBIT ~~~~~~~~~~~~~~~~~~

                    'AKUN KREDIT ~~~~~~~~~~~~~~~~~~~~~~~~
                    debitkredit = 1

                    'NOMINAL = nilaipenyusutan * kurs
                    nominal = Double.Parse(FixDouble(dr1("nilaipenyusutan"))) * Double.Parse(FixDouble(dr1("kurs")))

                    'GROUPING AKUN KREDIT (arekakumdepresiasi)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & dr1("arekakumdepresiasi").ToString & "'"
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : Trans.Rollback() : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", dr1("arekakumdepresiasi").ToString, "AKUM. PENYUSUTAN", nominal, nominalvalas, debitkredit, drutama("Dacatatan").ToString, dr1("costcenter").ToString, dr1("divisi").ToString, dr1("subdivisi").ToString, dr1("proyek").ToString, urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : Trans.Rollback() : GoTo selesai
                        End If
                    End If
                    'END OF AKUN KREDIT ~~~~~~~~~~~~~~~~~
                    'END OF PROSES JURNAL --------------------------------

                Next

            Else
                'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
                rsProgress = 4 : GoTo selesai
            End If
            'END OF PROSES JURNAL ==============================================


            'BUAT SQL ============================================================
            Dim strValue As New StringBuilder

            'URUTKAN JURNAL
            dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

            'DELETE JURNAL JIKA NOMIAL = 0
            AsDataTableDeleteData(dtjurnal, "nominal = 0")

            For Each drjurnal As DataRow In dtjurnal.Rows
                urutan = urutan + 1
                'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
                strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
                'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
                If drjurnal("debitkredit") = 0 Then
                    'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,ttgljatuhtempo,ttgllunas,tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                    strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("Dacabang")) & "', '" & FixQuotes(drutama("Dalokasi")) & "', '" & FixQuotes(drutama("Dasumber")) & "', " & 0 & ", " & drutama("Daid") & ", '" & FixQuotes(drutama("Danotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("Datgl"))) & "', " & drutama("Dakodepa") & ", " & drutama("dabagianda") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("Dauraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("Damatauang")) & "', '" & FixDouble(drutama("Dakurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("Dastatus") & ", 1, NOW(), " & drutama("Dajmlrevisi") & ", " & drutama("Dacetakanke") & ", " & drutama("Dainputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("Dainputtgl"), formatTglWaktuDB)) & "', " & drutama("Damodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("Damodifikasitgl"), formatTglWaktuDB)) & "')")
                Else
                    'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,ttgljatuhtempo,ttgllunas,tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter,           tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                    strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("Dacabang")) & "', '" & FixQuotes(drutama("Dalokasi")) & "', '" & FixQuotes(drutama("Dasumber")) & "', " & 0 & ", " & drutama("Daid") & ", '" & FixQuotes(drutama("Danotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("Datgl"))) & "', " & drutama("Dakodepa") & ", " & drutama("dabagianda") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("Dauraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("Damatauang")) & "', '" & FixDouble(drutama("Dakurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', 0, 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("Dastatus") & ", 1, NOW(), " & drutama("Dajmlrevisi") & ", " & drutama("Dacetakanke") & ", " & drutama("Dainputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("Dainputtgl"), formatTglWaktuDB)) & "', " & drutama("Damodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("Damodifikasitgl"), formatTglWaktuDB)) & "')")
                End If
            Next


            'BUAT SQL HAPUS JURNAL LAMA
            Dim sqlHapus As String = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'DA' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"
            objCmd = New MySql.Data.MySqlClient.MySqlCommand()
            With objCmd
                .Connection = Con1
                .Transaction = Trans
                .CommandType = CommandType.Text
                .CommandText = sqlHapus
            End With
            objCmd.ExecuteNonQuery()


            'BUAT SQL JURNAL
            If Len(strValue.ToString) > 0 Then
                sqlJurnal = "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & ""
                objCmd = New MySql.Data.MySqlClient.MySqlCommand()
                With objCmd
                    .Connection = Con1
                    .Transaction = Trans
                    .CommandType = CommandType.Text
                    .CommandText = sqlJurnal
                End With
                objCmd.ExecuteNonQuery()
            End If


            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING
            sqlPosting = "UPDATE M7_Da SET Daposting = 1, Dapostingtgl = NOW() WHERE Daid = '" & idtransaksi & "'"
            objCmd = New MySql.Data.MySqlClient.MySqlCommand()
            With objCmd
                .Connection = Con1
                .Transaction = Trans
                .CommandType = CommandType.Text
                .CommandText = sqlPosting
            End With
            objCmd.ExecuteNonQuery()


            'GABUNGKAN VALUE SQL JURNAL HPP , SQL POSTING 
            rsSql = ""
            'END OF BUAT SQL ================================================


            Trans.Commit()  '*** Commit Transaction ***'

        Catch ex As Exception

            Trans.Rollback() '*** RollBack Transaction ***'  
            rsProgress = 0
            rsErrMessage = "Transaction Rollback : " & ex.Message
            GoTo selesai

        End Try

        objCmd = Nothing
        'Con1.Close()
        '//END OF TRANSAKSI KE DATABASE *********************************************************

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

    '********************************************** M11 **********************************************
#Region "M11_Lu"
    Public Function M11_Lu(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'PIUTANG SEMENTARA (D)
        '           PEND. PENJUALAN   (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""
        Dim rekPiutangUsaha As String
        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0, selisihKurs As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt64) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT lu.*, (CASE lucustomer WHEN 2 THEN k.knama ELSE p.pnama END) AS lupasiennama, c.kid as idkontak FROM m_11_lu lu LEFT JOIN m1_patient p ON (lu.lucustomer = p.pid) LEFT JOIN m1_contact c ON (CASE lucustomer WHEN 2 THEN lu.lucustomer = c.kid ELSE p.pkode = c.kkode AND c.kkategori = 'P' END) LEFT JOIN m1_contact k ON (p.pid = k.kid) WHERE (lu.lustatus = 2 OR lu.lustatus = 3 OR lu.lustatus = 4 OR lu.lustatus = 7) AND lu.luid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT lud.* FROM m_11_lu_detail lud JOIN m_11_lu lu ON lud.idlu = lu.luid WHERE (lu.lustatus = 2 OR lu.lustatus = 3 OR lu.lustatus = 4 OR lu.lustatus = 7) AND lu.luid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        ' If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("lusumber")
            noTransaksi = drutama("lunotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangBilling') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangApotek') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangLaboratorium')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN PIUTANG USAHA
            'If drutama("lujenisbilling") = 1 Then
            rekPiutangUsaha = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara'", "Not found")
            'Else
            'rekPiutangUsaha = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangBilling'", "Not found")
            ' End If

            If rekPiutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Receivable Coa not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------

            'AKUN DEBIT ------------------------------------------
            'PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sitotaltransaksi * kurs
            nominal = Double.Parse(drutama("lutotaltransaksi")) * Double.Parse(drutama("lukurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("lumatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sitotaltransaksi
                    nominalvalas = Double.Parse(drutama("lutotaltransaksi"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PIUTANG USAHA (rekPiutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekPiutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekPiutangUsaha, "PIUTANG USAHA", nominal, nominalvalas, debitkredit, drutama("lucatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~

            'PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            'PEND. PENJUALAN DIAMBILKAN DARI DATA TRANSAKSI DETAIL
            If dtdetail.Rows.Count > 0 Then
                For Each drdetail As DataRow In dtdetail.Rows
                    debitkredit = 1
                    'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                    If drutama("lumatauang").ToString <> matauang Then
                        'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                        nominal = ((Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))) * Double.Parse(drdetail("kurs"))
                        'NOMINAL VALAS = (jml * harga) - jmldiskon
                        nominalvalas = (Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))

                        'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                    Else
                        'NOMINAL = (jml * harga) - jmldiskon
                        nominal = (Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))
                        'NOMINAL VALAS = 0 
                        nominalvalas = 0
                    End If

                    'GROUPING AKUN KREDIT (rekpenjualan)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekpenjualan").ToString & "'"
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekpenjualan").ToString, "PEND. PENJUALAN", nominal, nominalvalas, debitkredit, drutama("lucatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If

                Next
            End If
            'END OF PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================

        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("luuraian")) & "', ' ', '" & FixQuotes(drutama("lupasiennama")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("luuraian")) & "', ' ', '" & FixQuotes(drutama("lupasiennama")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'LU' AND tgrup = '1' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SI
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m_11_lu SET luposting = 1, lupostingtgl = NOW() WHERE luid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M11_Km"
    Public Function M11_Km(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'PIUTANG SEMENTARA (D)
        '           PEND. PENJUALAN   (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable ', dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0, selisihKurs As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt64) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT km.*, (CASE kmcustomer WHEN 2 THEN k.knama ELSE p.pnama END) AS kmpasiennama FROM m_11_km km LEFT JOIN m1_patient p ON (km.kmcustomer = p.pid) LEFT JOIN m1_contact k ON (km.kmcustomer = k.kid) WHERE (km.kmstatus = 2 OR km.kmstatus = 3 OR km.kmstatus = 4 OR km.kmstatus = 7) AND km.kmid = '" & idtransaksi & "'", strCon)
        'DETAIL
        'dtdetail = AsDataTableAmbilDariDB("SELECT kmd.* FROM m_11_km_detail kmd JOIN m_11_km km ON kmd.idkm = km.kmid WHERE (km.kmstatus = 2 OR km.kmstatus = 3 OR km.kmstatus = 4 OR km.kmstatus = 7) AND km.kmid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        ' If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("kmsumber")
            noTransaksi = drutama("kmnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN PIUTANG USAHA
            Dim rekPiutangUsaha As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara'", "Not found")
            If rekPiutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Receivable Coa not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------

            'AKUN DEBIT ------------------------------------------
            'PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sitotaltransaksi * kurs
            nominal = Double.Parse(drutama("kmtotaltransaksi")) * Double.Parse(drutama("kmkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("kmmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sitotaltransaksi
                    nominalvalas = Double.Parse(drutama("kmtotaltransaksi"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PIUTANG USAHA (rekPiutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekPiutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekPiutangUsaha, "PIUTANG USAHA", nominal, nominalvalas, debitkredit, drutama("kmcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~

            'PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            'PEND. PENJUALAN DIAMBILKAN DARI DATA TRANSAKSI DETAIL
            If dtutama.Rows.Count > 0 Then
                For Each drdetail As DataRow In dtutama.Rows
                    debitkredit = 1
                    'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                    If drutama("kmmatauang").ToString <> matauang Then
                        'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                        nominal = ((Double.Parse(drdetail("kmjmlhari")) * Double.Parse(drdetail("kmharga"))) - 0) * Double.Parse(drdetail("kmkurs"))
                        'NOMINAL VALAS = (jml * harga) - jmldiskon
                        nominalvalas = (Double.Parse(drdetail("kmjmlhari")) * Double.Parse(drdetail("kmharga"))) - 0

                        'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                    Else
                        'NOMINAL = (jml * harga) - jmldiskon
                        nominal = (Double.Parse(drdetail("kmjmlhari")) * Double.Parse(drdetail("kmharga"))) - 0
                        'NOMINAL VALAS = 0 
                        nominalvalas = 0
                    End If

                    'GROUPING AKUN KREDIT (rekpenjualan)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("kmrekpenjualan").ToString & "'"
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("kmrekpenjualan").ToString, "PEND. PENJUALAN", nominal, nominalvalas, debitkredit, drutama("kmcatatan").ToString, "", "", "", "", urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If

                Next
            End If
            'END OF PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================

        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("kmcabang")) & "', '" & FixQuotes(drutama("kmlokasi")) & "', '" & FixQuotes(drutama("kmsumber")) & "', " & 0 & ", " & drutama("kmid") & ", '" & FixQuotes(drutama("kmnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("kmtgl"))) & "', " & drutama("kmkodepa") & ", " & drutama("kmcustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("kmuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("kmmatauang")) & "', '" & FixDouble(drutama("kmkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("kmtgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("kmtgllunas"))) & "', " & FixDouble(drutama("kmstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("kmsaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("kmstatus") & ", 1, NOW(), " & drutama("kmjmlrevisi") & ", " & drutama("kmcetakanke") & ", " & drutama("kminputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("kminputtgl"), formatTglWaktuDB)) & "', " & drutama("kmmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("kmmodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("kmcabang")) & "', '" & FixQuotes(drutama("kmlokasi")) & "', '" & FixQuotes(drutama("kmsumber")) & "', " & 0 & ", " & drutama("kmid") & ", '" & FixQuotes(drutama("kmnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("kmtgl"))) & "', " & drutama("kmkodepa") & ", " & drutama("kmcustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("kmuraian")) & "', ' ', '" & FixQuotes(drutama("kmpasiennama")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("kmmatauang")) & "', '" & FixDouble(drutama("kmkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("kmstatus") & ", 1, NOW(), " & drutama("kmjmlrevisi") & ", " & drutama("kmcetakanke") & ", " & drutama("kminputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("kminputtgl"), formatTglWaktuDB)) & "', " & drutama("kmmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("kmmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("kmcabang")) & "', '" & FixQuotes(drutama("kmlokasi")) & "', '" & FixQuotes(drutama("kmsumber")) & "', " & 0 & ", " & drutama("kmid") & ", '" & FixQuotes(drutama("kmnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("kmtgl"))) & "', " & drutama("kmkodepa") & ", " & drutama("kmcustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("kmuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("kmmatauang")) & "', '" & FixDouble(drutama("kmkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("kmtgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("kmtgllunas"))) & "', " & FixDouble(drutama("kmstatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("kmsaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("kmstatus") & ", 1, NOW(), " & drutama("kmjmlrevisi") & ", " & drutama("kmcetakanke") & ", " & drutama("kminputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("kminputtgl"), formatTglWaktuDB)) & "', " & drutama("kmmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("kmmodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("kmcabang")) & "', '" & FixQuotes(drutama("kmlokasi")) & "', '" & FixQuotes(drutama("kmsumber")) & "', " & 0 & ", " & drutama("kmid") & ", '" & FixQuotes(drutama("kmnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("kmtgl"))) & "', " & drutama("kmkodepa") & ", " & drutama("kmcustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("kmuraian")) & "', ' ', '" & FixQuotes(drutama("kmpasiennama")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("kmmatauang")) & "', '" & FixDouble(drutama("kmkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("kmstatus") & ", 1, NOW(), " & drutama("kmjmlrevisi") & ", " & drutama("kmcetakanke") & ", " & drutama("kminputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("kminputtgl"), formatTglWaktuDB)) & "', " & drutama("kmmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("kmmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'KM' AND tgrup = '1' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SI
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m_11_km SET kmposting = 1, kmpostingtgl = NOW() WHERE kmid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M11_Lb"
    Public Function M11_Lb(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'PIUTANG SEMENTARA (D)
        '           PEND. LAB   (K)

        'DISINI HANYA MEMBUAT GROUP 1, GROUP 2 DIPROSES PADA TOOLS HPP
        'GROUP 2 : =====================
        'HPP           (D)
        '           PERSEDIAAN        (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim rekPiutangUsaha As String
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0, selisihKurs As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt64) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT lb.*, (CASE lbcustomer WHEN 2 THEN k.knama ELSE p.pnama END) AS lbpasiennama, c.kid as idkontak FROM m_11_lb lb LEFT JOIN m1_patient p ON (lb.lbcustomer = p.pid) LEFT JOIN m1_contact c ON (CASE lbcustomer WHEN 2 THEN lb.lbcustomer = c.kid ELSE p.pkode = c.kkode AND c.kkategori = 'P' END) LEFT JOIN m1_contact k ON (p.pid = k.kid) WHERE (lb.lbstatus = 2 OR lb.lbstatus = 3 OR lb.lbstatus = 4 OR lb.lbstatus = 7) AND lb.lbid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT lbd.* FROM m_11_lb_detail lbd JOIN m_11_lb lb ON lbd.idlb = lb.lbid WHERE (lb.lbstatus = 2 OR lb.lbstatus = 3 OR lb.lbstatus = 4 OR lb.lbstatus = 7) AND lb.lbid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        ' If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("lbsumber")
            noTransaksi = drutama("lbnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangLaboratorium')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN PIUTANG USAHA
            ' If drutama("lbpenjualanlangsung") = 0 Then
            rekPiutangUsaha = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara'", "Not found")
            'Else
            '  rekPiutangUsaha = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangLaboratorium'", "Not found")
            'End If

            If rekPiutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Receivable Coa not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------

            'AKUN DEBIT ------------------------------------------
            'PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sitotaltransaksi * kurs
            nominal = Double.Parse(drutama("lbtotaltransaksi")) * Double.Parse(drutama("lbkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("lbmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sitotaltransaksi
                    nominalvalas = Double.Parse(drutama("lbtotaltransaksi"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PIUTANG USAHA (rekPiutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekPiutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekPiutangUsaha, "PIUTANG SEMENTARA", nominal, nominalvalas, debitkredit, drutama("lbcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~


            'DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sijmldiskon * kurs
            'nominal = Double.Parse(drutama("lujmldiskon")) * Double.Parse(drutama("lukurs"))
            'If nominal <> 0 Then
            '    'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
            '    If drutama("lumatauang").ToString <> matauang Then
            '        'NOMINAL VALAS = sijmldiskon
            '        nominalvalas = Double.Parse(drutama("lujmldiskon"))
            '    Else
            '        nominalvalas = 0
            '    End If

            '    'GROUPING DISKON (sirekdiskon)
            '    filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("lurekdiskon").ToString & "'"
            '    If AsDataTableDCount(dtjurnal, filter) > 0 Then
            '        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
            '        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
            '        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
            '            rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    Else
            '        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
            '                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("lurekdiskon").ToString, "DISKON", nominal, nominalvalas, debitkredit, drutama("lucatatan").ToString, "", "", "", "", urutan)) = False Then
            '            rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    End If
            'End If
            'END OF DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


            'UM PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sijmluangmuka * kurs
            'nominal = Double.Parse(drutama("lujmluangmuka")) * Double.Parse(drutama("lukurs"))
            'If nominal <> 0 Then
            '    'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
            '    If drutama("lumatauang").ToString <> matauang Then
            '        'NOMINAL VALAS = sijmldiskon
            '        nominalvalas = Double.Parse(drutama("lujmluangmuka"))
            '    Else
            '        nominalvalas = 0
            '    End If

            '    'GROUPING DISKON (sirekuangmuka)
            '    filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("lurekuangmuka").ToString & "'"
            '    If AsDataTableDCount(dtjurnal, filter) > 0 Then
            '        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
            '        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
            '        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
            '            rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    Else
            '        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
            '                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("lurekuangmuka").ToString, "UM PENJUALAN", nominal, nominalvalas, debitkredit, drutama("lucatatan").ToString, "", "", "", "", urutan)) = False Then
            '            rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    End If
            'End If
            'END OF UM PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN DEBIT -----------------------------------


            'AKUN KREDIT -----------------------------------------
            'PPN KELUARAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = sitotalpajak1detail * kurs
            'nominal = Double.Parse(drutama("lutotalpajak1detail")) * Double.Parse(drutama("lukurs"))
            'If nominal <> 0 Then
            '    'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
            '    If drutama("lumatauang").ToString <> matauang Then
            '        'NOMINAL VALAS = sitotalpajak1detail
            '        nominalvalas = Double.Parse(drutama("lutotalpajak1detail"))
            '    Else
            '        nominalvalas = 0
            '    End If

            '    'GROUPING PPN KELUARAN1 (sirekpajak1)
            '    filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("lurekpajak1").ToString & "'"
            '    If AsDataTableDCount(dtjurnal, filter) > 0 Then
            '        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
            '        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
            '        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
            '            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    Else
            '        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
            '                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("lurekpajak1").ToString, "PPN KELUARAN1", nominal, nominalvalas, debitkredit, drutama("lucatatan").ToString, "", "", "", "", urutan)) = False Then
            '            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    End If
            'End If
            'END OF PPN KELUARAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~

            'PPN KELUARAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = sitotalpajak2detail * kurs
            'nominal = Double.Parse(drutama("lutotalpajak2detail")) * Double.Parse(drutama("lukurs"))
            'If nominal <> 0 Then
            '    'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
            '    If drutama("lumatauang").ToString <> matauang Then
            '        'NOMINAL VALAS = sitotalpajak2detail
            '        nominalvalas = Double.Parse(drutama("lutotalpajak2detail"))
            '    Else
            '        nominalvalas = 0
            '    End If

            '    'GROUPING PPN KELUARAN2 (sirekpajak2)
            '    filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("lurekpajak2").ToString & "'"
            '    If AsDataTableDCount(dtjurnal, filter) > 0 Then
            '        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
            '        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
            '        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
            '            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    Else
            '        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
            '                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("lurekpajak2").ToString, "PPN KELUARAN2", nominal, nominalvalas, debitkredit, drutama("lucatatan").ToString, "", "", "", "", urutan)) = False Then
            '            rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    End If
            'End If
            'END OF PPN KELUARAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~

            'PEND. LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = sibiayalain * kurs
            'nominal = Double.Parse(drutama("lubiayalain")) * Double.Parse(drutama("lukurs"))
            'If nominal <> 0 Then
            '    'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
            '    If drutama("lumatauang").ToString <> matauang Then
            '        'NOMINAL VALAS = sibiayalain
            '        nominalvalas = Double.Parse(drutama("lubiayalain"))
            '    Else
            '        nominalvalas = 0
            '    End If

            '    'GROUPING PEND. LAIN-LAIN (sirekbiayalain)
            '    filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("sirekbiayalain").ToString & "'"
            '    If AsDataTableDCount(dtjurnal, filter) > 0 Then
            '        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
            '        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
            '        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
            '            rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    Else
            '        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
            '                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("lurekbiayalain").ToString, "PEND. LAIN-LAIN", nominal, nominalvalas, debitkredit, drutama("lucatatan").ToString, "", "", "", "", urutan)) = False Then
            '            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    End If
            'End If
            'END OF PEND. LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~

            'PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            'PEND. PENJUALAN DIAMBILKAN DARI DATA TRANSAKSI DETAIL
            If dtdetail.Rows.Count > 0 Then
                For Each drdetail As DataRow In dtdetail.Rows
                    debitkredit = 1
                    'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                    If drutama("lbmatauang").ToString <> matauang Then
                        'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                        nominal = ((Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))) * Double.Parse(drdetail("kurs"))
                        'NOMINAL VALAS = (jml * harga) - jmldiskon
                        nominalvalas = (Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))

                        'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                    Else
                        'NOMINAL = (jml * harga) - jmldiskon
                        nominal = (Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))
                        'NOMINAL VALAS = 0 
                        nominalvalas = 0
                    End If

                    'GROUPING AKUN KREDIT (rekpenjualan)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekpenjualan").ToString & "'"
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekpenjualan").ToString, "PEND. LABORATORIUM", nominal, nominalvalas, debitkredit, drutama("lbcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If

                Next
            End If
            'END OF PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================

        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lbcabang")) & "', '" & FixQuotes(drutama("lblokasi")) & "', '" & FixQuotes(drutama("lbsumber")) & "', " & 0 & ", " & drutama("lbid") & ", '" & FixQuotes(drutama("lbnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lbtgl"))) & "', " & drutama("lbkodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("lburaian")) & "', ' ', '" & FixQuotes(drutama("lbpasiennama")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lbmatauang")) & "', '" & FixDouble(drutama("lbkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lbstatus") & ", 1, NOW(), " & drutama("lbjmlrevisi") & ", " & drutama("lbcetakanke") & ", " & drutama("lbinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lbinputtgl"), formatTglWaktuDB)) & "', " & drutama("lbmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lbmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lbcabang")) & "', '" & FixQuotes(drutama("lblokasi")) & "', '" & FixQuotes(drutama("lbsumber")) & "', " & 0 & ", " & drutama("lbid") & ", '" & FixQuotes(drutama("lbnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lbtgl"))) & "', " & drutama("lbkodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("lburaian")) & "', ' ', '" & FixQuotes(drutama("lbpasiennama")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lbmatauang")) & "', '" & FixDouble(drutama("lbkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lbstatus") & ", 1, NOW(), " & drutama("lbjmlrevisi") & ", " & drutama("lbcetakanke") & ", " & drutama("lbinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lbinputtgl"), formatTglWaktuDB)) & "', " & drutama("lbmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lbmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'LB' AND tgrup = '1' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SI
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m_11_lb SET lbposting = 1, lbtglposting = NOW() WHERE lbid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M11_AK"
    Public Function M11_Ak(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'PIUTANG SEMENTARA (D)
        '           PEND. APOTEK   (K)

        'DISINI HANYA MEMBUAT GROUP 1, GROUP 2 DIPROSES PADA TOOLS HPP
        'GROUP 2 : =====================
        'HPP           (D)
        '           PERSEDIAAN        (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim rekPiutangUsaha As String
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0, selisihKurs As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt64) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT ak.*, (CASE akcustomer WHEN 2 THEN k.knama ELSE p.pnama END) AS akpasiennama, c.kid as idkontak FROM m_11_ak ak LEFT JOIN m1_patient p ON (ak.akcustomer = p.pid) LEFT JOIN m1_contact c ON (CASE akcustomer WHEN 2 THEN ak.akcustomer = c.kid ELSE p.pkode = c.kkode AND c.kkategori = 'P' END) LEFT JOIN m1_contact k ON (p.pid = k.kid) WHERE (ak.akstatus = 2 OR ak.akstatus = 3 OR ak.akstatus = 4 OR ak.akstatus = 7) AND ak.akid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT akd.* FROM m_11_ak_detail akd JOIN m_11_ak ak ON akd.idak = ak.akid WHERE (ak.akstatus = 2 OR ak.akstatus = 3 OR ak.akstatus = 4 OR ak.akstatus = 7) AND ak.akid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        ' If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("aksumber")
            noTransaksi = drutama("aknotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangApotek')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN PIUTANG USAHA
            ' If drutama("akpenjualanlangsung") = 0 Then
            rekPiutangUsaha = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara'", "Not found")
            'Else
            ' rekPiutangUsaha = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangApotek'", "Not found")
            'End If

            If rekPiutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Receivable Coa not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------

            'AKUN DEBIT ------------------------------------------
            'PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sitotaltransaksi * kurs
            nominal = Double.Parse(drutama("aktotaltransaksi")) * Double.Parse(drutama("akkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("akmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sitotaltransaksi
                    nominalvalas = Double.Parse(drutama("aktotaltransaksi"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PIUTANG USAHA (rekPiutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekPiutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekPiutangUsaha, "PIUTANG SEMENTARA", nominal, nominalvalas, debitkredit, drutama("akcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~

            'PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            'PEND. PENJUALAN DIAMBILKAN DARI DATA TRANSAKSI DETAIL
            If dtdetail.Rows.Count > 0 Then
                For Each drdetail As DataRow In dtdetail.Rows
                    debitkredit = 1
                    'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                    If drutama("akmatauang").ToString <> matauang Then
                        'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                        nominal = ((Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))) * Double.Parse(drdetail("kurs"))
                        'NOMINAL VALAS = (jml * harga) - jmldiskon
                        nominalvalas = (Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))
                        nominalvalas = nominalvalas + Double.Parse(drutama("akresep")) + Double.Parse(drutama("akracik")) + Double.Parse(drutama("akembalase"))
                        'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                    Else
                        'NOMINAL = (jml * harga) - jmldiskon
                        nominal = (Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))
                        'NOMINAL VALAS = 0 
                        nominalvalas = 0
                    End If

                    'GROUPING AKUN KREDIT (rekpenjualan)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekpenjualan").ToString & "'"
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekpenjualan").ToString, "PEND. APOTEK", nominal + Double.Parse(drutama("akresep")) + Double.Parse(drutama("akracik")) + Double.Parse(drutama("akembalase")), nominalvalas, debitkredit, drutama("akcatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If

                Next
            End If
            'END OF PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================

        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,akpasiennama                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("akcabang")) & "', '" & FixQuotes(drutama("aklokasi")) & "', '" & FixQuotes(drutama("aksumber")) & "', " & 0 & ", " & drutama("akid") & ", '" & FixQuotes(drutama("aknotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("aktgl"))) & "', " & drutama("akkodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("akuraian")) & "', ' ', '" & FixQuotes(drutama("aknoref")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("akmatauang")) & "', '" & FixDouble(drutama("akkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("akstatus") & ", 1, NOW(), " & drutama("akjmlrevisi") & ", " & drutama("akcetakanke") & ", " & drutama("akinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("akinputtgl"), formatTglWaktuDB)) & "', " & drutama("akmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("akmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("akcabang")) & "', '" & FixQuotes(drutama("aklokasi")) & "', '" & FixQuotes(drutama("aksumber")) & "', " & 0 & ", " & drutama("akid") & ", '" & FixQuotes(drutama("aknotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("aktgl"))) & "', " & drutama("akkodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("akuraian")) & "', ' ', '" & FixQuotes(drutama("aknoref")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("akmatauang")) & "', '" & FixDouble(drutama("akkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("akstatus") & ", 1, NOW(), " & drutama("akjmlrevisi") & ", " & drutama("akcetakanke") & ", " & drutama("akinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("akinputtgl"), formatTglWaktuDB)) & "', " & drutama("akmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("akmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'AK' AND tgrup = '1' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SI
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m_11_ak SET akposting = 1, aktglposting = NOW() WHERE akid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M11_Rk"
    Public Function M11_Rk(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'PIUTANG SEMENTARA (D)
        '           HUTANG REKANAN   (K)

        'DISINI HANYA MEMBUAT GROUP 1, GROUP 2 DIPROSES PADA TOOLS HPP
        'GROUP 2 : =====================
        'HPP           (D)
        '           PERSEDIAAN        (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0, selisihKurs As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt64) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT rk.*, c.kid as idkontak FROM m_11_rk rk LEFT JOIN m1_patient p ON (rk.rkkontak = p.pid) LEFT JOIN m1_contact c ON (CASE rkkontak WHEN 2 THEN rk.rkkontak = c.kid ELSE p.pkode = c.kkode AND c.kkategori = 'P' END) LEFT JOIN m1_contact k ON (p.pid = k.kid) WHERE (rk.rkstatus = 2 OR rk.rkstatus = 3 OR rk.rkstatus = 4 OR rk.rkstatus = 7) AND rk.rkid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT rkd.* FROM m_11_rk_pay rkd JOIN m_11_rk rk ON rkd.idrk = rk.rkid WHERE (rk.rkstatus = 2 OR rk.rkstatus = 3 OR rk.rkstatus = 4 OR rk.rkstatus = 7) AND rk.rkid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        ' If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("rksumber")
            noTransaksi = drutama("rkjumlah")
            'END OF SET DATA UTAMA -------------------------------

            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN PIUTANG USAHA
            Dim rekPiutangUsaha As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara'", "Not found")
            If rekPiutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Receivable Coa not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------

            'AKUN DEBIT ------------------------------------------
            'PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sitotaltransaksi * kurs
            nominal = Double.Parse(drutama("rkjumlah")) * Double.Parse(drutama("rkkurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("rkmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sitotaltransaksi
                    nominalvalas = Double.Parse(drutama("rkjumlah"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PIUTANG USAHA (rekPiutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekPiutangUsaha & "'"
                'If AsDataTableDCount(dtjurnal, filter) > 0 Then
                '    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                '    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                '    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                '        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                '    End If
                'Else
                If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                         String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("rknorek").ToString, "PIUTANG SEMENTARA", nominal, nominalvalas, debitkredit, drutama("rkcatatan").ToString, "", "", "", "", urutan)) = False Then
                    'String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekPiutangUsaha, "PIUTANG SEMENTARA", nominal, nominalvalas, debitkredit, drutama("rkcatatan").ToString, "", "", "", "", urutan)) = False Then
                    rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                End If
                'End If
            End If
            'END OF PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~


            'DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sijmldiskon * kurs
            'nominal = Double.Parse(drutama("lujmldiskon")) * Double.Parse(drutama("lukurs"))
            'If nominal <> 0 Then
            '    'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
            '    If drutama("lumatauang").ToString <> matauang Then
            '        'NOMINAL VALAS = sijmldiskon
            '        nominalvalas = Double.Parse(drutama("lujmldiskon"))
            '    Else
            '        nominalvalas = 0
            '    End If

            '    'GROUPING DISKON (sirekdiskon)
            '    filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("lurekdiskon").ToString & "'"
            '    If AsDataTableDCount(dtjurnal, filter) > 0 Then
            '        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
            '        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
            '        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
            '            rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    Else
            '        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
            '                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("lurekdiskon").ToString, "DISKON", nominal, nominalvalas, debitkredit, drutama("lucatatan").ToString, "", "", "", "", urutan)) = False Then
            '            rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    End If
            'End If
            'END OF DISKON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


            'UM PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            'NOMINAL = sijmluangmuka * kurs
            'nominal = Double.Parse(drutama("lujmluangmuka")) * Double.Parse(drutama("lukurs"))
            'If nominal <> 0 Then
            '    'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
            '    If drutama("lumatauang").ToString <> matauang Then
            '        'NOMINAL VALAS = sijmldiskon
            '        nominalvalas = Double.Parse(drutama("lujmluangmuka"))
            '    Else
            '        nominalvalas = 0
            '    End If

            '    'GROUPING DISKON (sirekuangmuka)
            '    filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("lurekuangmuka").ToString & "'"
            '    If AsDataTableDCount(dtjurnal, filter) > 0 Then
            '        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
            '        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
            '        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
            '            rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    Else
            '        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
            '                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("lurekuangmuka").ToString, "UM PENJUALAN", nominal, nominalvalas, debitkredit, drutama("lucatatan").ToString, "", "", "", "", urutan)) = False Then
            '            rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    End If
            'End If
            'END OF UM PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN DEBIT -----------------------------------


            'AKUN KREDIT -----------------------------------------
            'PPN KELUARAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = sitotalpajak1detail * kurs
            'nominal = Double.Parse(drutama("lutotalpajak1detail")) * Double.Parse(drutama("lukurs"))
            'If nominal <> 0 Then
            '    'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
            '    If drutama("lumatauang").ToString <> matauang Then
            '        'NOMINAL VALAS = sitotalpajak1detail
            '        nominalvalas = Double.Parse(drutama("lutotalpajak1detail"))
            '    Else
            '        nominalvalas = 0
            '    End If

            '    'GROUPING PPN KELUARAN1 (sirekpajak1)
            '    filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("lurekpajak1").ToString & "'"
            '    If AsDataTableDCount(dtjurnal, filter) > 0 Then
            '        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
            '        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
            '        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
            '            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    Else
            '        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
            '                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("lurekpajak1").ToString, "PPN KELUARAN1", nominal, nominalvalas, debitkredit, drutama("lucatatan").ToString, "", "", "", "", urutan)) = False Then
            '            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    End If
            'End If
            'END OF PPN KELUARAN1 ~~~~~~~~~~~~~~~~~~~~~~~~~

            'PPN KELUARAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = sitotalpajak2detail * kurs
            'nominal = Double.Parse(drutama("lutotalpajak2detail")) * Double.Parse(drutama("lukurs"))
            'If nominal <> 0 Then
            '    'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
            '    If drutama("lumatauang").ToString <> matauang Then
            '        'NOMINAL VALAS = sitotalpajak2detail
            '        nominalvalas = Double.Parse(drutama("lutotalpajak2detail"))
            '    Else
            '        nominalvalas = 0
            '    End If

            '    'GROUPING PPN KELUARAN2 (sirekpajak2)
            '    filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("lurekpajak2").ToString & "'"
            '    If AsDataTableDCount(dtjurnal, filter) > 0 Then
            '        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
            '        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
            '        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
            '            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    Else
            '        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
            '                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("lurekpajak2").ToString, "PPN KELUARAN2", nominal, nominalvalas, debitkredit, drutama("lucatatan").ToString, "", "", "", "", urutan)) = False Then
            '            rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    End If
            'End If
            'END OF PPN KELUARAN2 ~~~~~~~~~~~~~~~~~~~~~~~~~

            'PEND. LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = sibiayalain * kurs
            'nominal = Double.Parse(drutama("lubiayalain")) * Double.Parse(drutama("lukurs"))
            'If nominal <> 0 Then
            '    'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
            '    If drutama("lumatauang").ToString <> matauang Then
            '        'NOMINAL VALAS = sibiayalain
            '        nominalvalas = Double.Parse(drutama("lubiayalain"))
            '    Else
            '        nominalvalas = 0
            '    End If

            '    'GROUPING PEND. LAIN-LAIN (sirekbiayalain)
            '    filter = "debitkredit=" & debitkredit & " AND norek='" & drutama("sirekbiayalain").ToString & "'"
            '    If AsDataTableDCount(dtjurnal, filter) > 0 Then
            '        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
            '        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
            '        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
            '            rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    Else
            '        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
            '                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drutama("lurekbiayalain").ToString, "PEND. LAIN-LAIN", nominal, nominalvalas, debitkredit, drutama("lucatatan").ToString, "", "", "", "", urutan)) = False Then
            '            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
            '        End If
            '    End If
            'End If
            'END OF PEND. LAIN-LAIN ~~~~~~~~~~~~~~~~~~~~~~~

            'PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            'PEND. PENJUALAN DIAMBILKAN DARI DATA TRANSAKSI DETAIL
            Dim dtUntukKredit As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'HutangRekanan')", strCon)

            Dim rekHutangRekanan As String = AsDataTableDLookup(dtUntukKredit, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'HutangRekanan'", "Not found")
            If rekHutangRekanan = "Not found" Then
                rsErrMessage = "Setting Account Receivable Coa not found." : GoTo selesai
            End If

            If dtdetail.Rows.Count > 0 Then
                For Each drdetail As DataRow In dtdetail.Rows
                    debitkredit = 1
                    urutan = Val(drdetail("urutan")) + 1
                    'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                    If drutama("rkmatauang").ToString <> matauang Then
                        'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                        nominal = (Double.Parse(drdetail("jumlah")) * Double.Parse(drdetail("kurs")))
                        'NOMINAL VALAS = (jml * harga) - jmldiskon
                        nominalvalas = (Double.Parse(drdetail("jumlah")))

                        'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                    Else
                        'NOMINAL = (jml * harga) - jmldiskon
                        nominal = (Double.Parse(drdetail("jumlah")))
                        'NOMINAL VALAS = 0 
                        nominalvalas = 0
                    End If

                    'GROUPING AKUN KREDIT (rekpenjualan)
                    'filter = "debitkredit=" & debitkredit & " AND norek='" & rekHutangRekanan & "'"
                    'If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    '    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    '    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    '    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                    '        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    '    End If
                    'Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekbank").ToString, "AKUN LAWAN", Double.Parse(drdetail("jumlah")), Double.Parse(drdetail("jumlahvalas")), debitkredit, drutama("rkcatatan").ToString, "", "", "", "", urutan)) = False Then
                        'String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekHutangRekanan, "HUTANG REKANAN", nominal, nominalvalas, debitkredit, drutama("rkcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                    'End If

                Next
            End If
            'END OF PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================

        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            'urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("rkcabang")) & "', '" & FixQuotes(drutama("rklokasi")) & "', '" & FixQuotes(drutama("rksumber")) & "', " & 0 & ", " & drutama("rkid") & ", '" & FixQuotes(drutama("rknotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("rktgl"))) & "', " & drutama("rkkodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("rkuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("rkmatauang")) & "', '" & FixDouble(drutama("rkkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("rkstatus") & ", 1, NOW(), " & drutama("rkjmlrevisi") & ", " & drutama("rkcetakanke") & ", " & drutama("rkinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rkinputtgl"), formatTglWaktuDB)) & "', " & drutama("rkmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rkmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("rkcabang")) & "', '" & FixQuotes(drutama("rklokasi")) & "', '" & FixQuotes(drutama("rksumber")) & "', " & 0 & ", " & drutama("rkid") & ", '" & FixQuotes(drutama("rknotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("rktgl"))) & "', " & drutama("rkkodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("rkuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("rkmatauang")) & "', '" & FixDouble(drutama("rkkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("rkstatus") & ", 1, NOW(), " & drutama("rkjmlrevisi") & ", " & drutama("rkcetakanke") & ", " & drutama("rkinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rkinputtgl"), formatTglWaktuDB)) & "', " & drutama("rkmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("rkmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'RK' AND tgrup = '1' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SI
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m_11_rk SET rkposting = 1, rkpostingtgl = NOW() WHERE rkid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M11_Pb"
    Public Function M11_Pb(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'PIUTANG SEMENTARA (D)
        '           HUTANG REKANAN   (K)

        'DISINI HANYA MEMBUAT GROUP 1, GROUP 2 DIPROSES PADA TOOLS HPP
        'GROUP 2 : =====================
        'HPP           (D)
        '           PERSEDIAAN        (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0, selisihKurs As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt64) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT pb.*, (CASE pvcustomer WHEN 2 THEN k.knama ELSE p.pnama END) AS pvpasiennama, c.kid as idkontak FROM m_11_pb pb LEFT JOIN m1_patient p ON (pb.pvcustomer = p.pid) LEFT JOIN m1_contact c ON (CASE pvcustomer WHEN 2 THEN pb.pvcustomer = c.kid ELSE p.pkode = c.kkode AND c.kkategori = 'P' END) LEFT JOIN m1_contact k ON (p.pid = k.kid) WHERE (pb.pvstatus = 2 OR pb.pvstatus = 3 OR pb.pvstatus = 4 OR pb.pvstatus = 7) AND pb.pvid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT pvd.* FROM m_11_pb_detail pvd JOIN m_11_pb pv ON pvd.idpv = pv.pvid WHERE (pv.pvstatus = 2 OR pv.pvstatus = 3 OR pv.pvstatus = 4 OR pv.pvstatus = 7) AND pv.pvid = '" & idtransaksi & "'", strCon)
        If dtutama.Rows.Count > 0 Then
            drutama = dtutama.Rows(0)
            sumber = drutama("pvsumber")
            noTransaksi = drutama("pvnotransaksi")
            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangPasien')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN PIUTANG USAHA
            Dim rekPiutangUsaha As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangPasien'", "Not found")
            If rekPiutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Receivable Coa not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------

            Dim dtUntukKredit As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara')", strCon)

            Dim rekHutangRekanan As String = ""
            If dtdetail.Rows.Count > 0 Then
                For Each drdetail As DataRow In dtdetail.Rows
                    debitkredit = 0
                    If drdetail("sumber") = "CA" Then
                        rekHutangRekanan = FixQuotes(drdetail("rekhutangpiutang"))
                        nominal = Double.Parse(drdetail("jmlbayar"))
                        nominalvalas = 0

                        'GROUPING AKUN KREDIT (rekpenjualan)
                        filter = "debitkredit=" & debitkredit & " AND norek='" & rekHutangRekanan & "'"
                        If AsDataTableDCount(dtjurnal, filter) > 0 Then
                            nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                            nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                            If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                                rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        Else
                            If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                     String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekHutangRekanan, "PIUTANG SEMENTARA", nominal, nominalvalas, debitkredit, drutama("pvcatatan").ToString, "", "", "", "", urutan)) = False Then
                                rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If
                        End If
                    End If
                Next
            End If

            debitkredit = 1
            'NOMINAL = sitotaltransaksi * kurs
            nominal = Double.Parse(drutama("pvtotalap"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS

                nominalvalas = 0
                ' End If

                'GROUPING PIUTANG USAHA (rekPiutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekPiutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekPiutangUsaha, "PIUTANG", nominal, nominalvalas, debitkredit, drutama("pvcatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If
            'END OF PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================

        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("pvcabang")) & "', '" & FixQuotes(drutama("pvlokasi")) & "', '" & FixQuotes(drutama("pvsumber")) & "', " & 0 & ", " & drutama("pvid") & ", '" & FixQuotes(drutama("pvnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("pvtgl"))) & "', " & drutama("pvkodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("pvuraian")) & "', ' ', '" & FixQuotes(drutama("pvpasiennama")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("pvmatauang")) & "', '" & FixDouble(drutama("pvkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("pvstatus") & ", 1, NOW(), " & drutama("pvjmlrevisi") & ", " & drutama("pvcetakanke") & ", " & drutama("pvinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("pvinputtgl"), formatTglWaktuDB)) & "', " & drutama("pvmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("pvmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("pvcabang")) & "', '" & FixQuotes(drutama("pvlokasi")) & "', '" & FixQuotes(drutama("pvsumber")) & "', " & 0 & ", " & drutama("pvid") & ", '" & FixQuotes(drutama("pvnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("pvtgl"))) & "', " & drutama("pvkodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("pvuraian")) & "', ' ', '" & FixQuotes(drutama("pvpasiennama")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("pvmatauang")) & "', '" & FixDouble(drutama("pvkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("pvstatus") & ", 1, NOW(), " & drutama("pvjmlrevisi") & ", " & drutama("pvcetakanke") & ", " & drutama("pvinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("pvinputtgl"), formatTglWaktuDB)) & "', " & drutama("pvmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("pvmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'pb' AND tgrup = '1' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SI
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m_11_pb SET pvposting = 1, pvpostingtgl = NOW() WHERE pvid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M11_RO"
    Public Function M11_Ro(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'RETUR PENJUALAN (D)
        '           PIUTANG SEMENTARA   (K)

        'DISINI HANYA MEMBUAT GROUP 1, GROUP 2 DIPROSES PADA TOOLS HPP
        'GROUP 2 : =====================
        'PERSEDIAAN           (D)
        '           HPP        (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0, selisihKurs As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt64) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT ro.*, (CASE rocustomer WHEN 2 THEN k.knama ELSE p.pnama END) AS ropasiennama, c.kid as idkontak FROM m_11_ro ro LEFT JOIN m1_patient p ON (ro.rocustomer = p.pid) LEFT JOIN m1_contact c ON (CASE rocustomer WHEN 2 THEN ro.rocustomer = c.kid ELSE p.pkode = c.kkode AND c.kkategori = 'P' END) LEFT JOIN m1_contact k ON (p.pid = k.kid) WHERE (ro.rostatus = 2 OR ro.rostatus = 3 OR ro.rostatus = 4 OR ro.rostatus = 7) AND ro.roid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT rod.* FROM m_11_ro_detail rod JOIN m_11_ro ro ON rod.idro = ro.roid WHERE (ro.rostatus = 2 OR ro.rostatus = 3 OR ro.rostatus = 4 OR ro.rostatus = 7) AND ro.roid = '" & idtransaksi & "'", strCon)
        drutama = dtutama.Rows(0)
        Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara')", strCon)
        Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        ' If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
        If dtdetail.Rows.Count > 0 Then
            For Each drdetail As DataRow In dtdetail.Rows
                debitkredit = 0
                'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                If drutama("romatauang").ToString <> matauang Then
                    'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                    nominal = ((Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))) * Double.Parse(drdetail("kurs"))
                    'NOMINAL VALAS = (jml * harga) - jmldiskon
                    nominalvalas = (Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))

                    'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                Else
                    'NOMINAL = (jml * harga) - jmldiskon
                    nominal = (Double.Parse(drdetail("jml")) * Double.Parse(drdetail("harga"))) - Double.Parse(drdetail("jmldiskon"))
                    'NOMINAL VALAS = 0 
                    nominalvalas = 0
                End If

                'GROUPING AKUN KREDIT (rekpenjualan)
                filter = "debitkredit=" & debitkredit & " AND norek='" & drdetail("rekpenjualan").ToString & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", drdetail("rekpenjualan").ToString, "PEND. APOTEK", nominal, nominalvalas, debitkredit, drutama("rocatatan").ToString, drdetail("costcenter").ToString, drdetail("divisi").ToString, drdetail("subdivisi").ToString, drdetail("proyek").ToString, urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If

            Next
        End If


        'END OF PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~
        'END OF AKUN DEBIT -----------------------------------

        'AKUN KREDIT -----------------------------------------
        'PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        'PEND. PENJUALAN DIAMBILKAN DARI DATA TRANSAKSI DETAIL
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("rosumber")
            noTransaksi = drutama("ronotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AMBIL DATA DARI SETTING -----------------------------

            'MATAUANG
            'Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN PIUTANG USAHA
            Dim rekPiutangUsaha As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara'", "Not found")
            If rekPiutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Receivable Coa not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------

            'AKUN DEBIT ------------------------------------------
            'PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 1
            'NOMINAL = sitotaltransaksi * kurs
            nominal = Double.Parse(drutama("rototaltransaksi")) * Double.Parse(drutama("rokurs"))
            If nominal <> 0 Then
                'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                If drutama("romatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sitotaltransaksi
                    nominalvalas = Double.Parse(drutama("rototaltransaksi"))
                Else
                    nominalvalas = 0
                End If

                'GROUPING PIUTANG USAHA (rekPiutangUsaha)
                filter = "debitkredit=" & debitkredit & " AND norek='" & rekPiutangUsaha & "'"
                If AsDataTableDCount(dtjurnal, filter) > 0 Then
                    nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                    nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                        rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                Else
                    If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                             String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekPiutangUsaha, "PIUTANG SEMENTARA", nominal, nominalvalas, debitkredit, drutama("rocatatan").ToString, "", "", "", "", urutan)) = False Then
                        rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                    End If
                End If
            End If

            'END OF PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================

        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("rocabang")) & "', '" & FixQuotes(drutama("rolokasi")) & "', '" & FixQuotes(drutama("rosumber")) & "', " & 0 & ", " & drutama("roid") & ", '" & FixQuotes(drutama("ronotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("rotgl"))) & "', " & drutama("rokodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("rouraian")) & "', ' ', '" & FixQuotes(drutama("ropasiennama")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("romatauang")) & "', '" & FixDouble(drutama("rokurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("rostatus") & ", 1, NOW(), " & drutama("rojmlrevisi") & ", " & drutama("rocetakanke") & ", " & drutama("roinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("roinputtgl"), formatTglWaktuDB)) & "', " & drutama("romodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("romodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("rocabang")) & "', '" & FixQuotes(drutama("rolokasi")) & "', '" & FixQuotes(drutama("rosumber")) & "', " & 0 & ", " & drutama("roid") & ", '" & FixQuotes(drutama("ronotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("rotgl"))) & "', " & drutama("rokodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("rouraian")) & "', ' ', '" & FixQuotes(drutama("ropasiennama")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("romatauang")) & "', '" & FixDouble(drutama("rokurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("rostatus") & ", 1, NOW(), " & drutama("rojmlrevisi") & ", " & drutama("rocetakanke") & ", " & drutama("roinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("roinputtgl"), formatTglWaktuDB)) & "', " & drutama("romodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("romodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'RO' AND tgrup = '1' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SI
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m_11_ro SET roposting = 1, rotglposting = NOW() WHERE roid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

#Region "M11_Kw"
    Public Function M11_Kw(ByVal idtransaksi As Integer) As String 'progress△errMessage△sqljurnal▲sqlupdateposting
        'GROUP 1 : =====================
        'PIUTANG PASIEN (D)
        '           PIUTANG SEMENTARA (K)

        Dim wsResult As String = ""
        Dim rsProgress As Integer = 0, rsErrMessage As String = "", rsSql As String = "", sql As String = "", sumber As String = "", noTransaksi As String = "", filter As String = ""

        Dim dtutama As DataTable, dtdetail As DataTable, dtpay As DataTable
        Dim drutama As DataRow
        Dim debitkredit As Integer = 0, urutan As Integer = 0, nominal As Double = 0, nominalvalas As Double = 0, selisihKurs As Double = 0

        'BUAT DT JURNAL
        Dim dtjurnal As New DataTable
        AsDataTableTambahField(dtjurnal, "norek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "namaakun", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "nominal", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "nominalvalas", AsEnumTypeData.AsDouble)
        AsDataTableTambahField(dtjurnal, "debitkredit", AsEnumTypeData.AsInt64) '0=debit,1=kredit
        AsDataTableTambahField(dtjurnal, "catatan", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "costcenter", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "divisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "subdivisi", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "proyek", AsEnumTypeData.AsString)
        AsDataTableTambahField(dtjurnal, "urutan", AsEnumTypeData.AsInt64)

        'AMBIL DATA ==========================================================
        'UTAMA
        dtutama = AsDataTableAmbilDariDB("SELECT kw.*, (CASE kwcustomer WHEN 2 THEN k.knama ELSE p.pnama END) AS kwpasiennama, c.kid as idkontak FROM m_11_kw kw LEFT JOIN m1_patient p ON (kw.kwcustomer = p.pid) LEFT JOIN m1_contact c ON (CASE kwcustomer WHEN 2 THEN kw.kwcustomer = c.kid ELSE p.pkode = c.kkode AND c.kkategori = 'P' END) LEFT JOIN m1_contact k ON (p.pid = k.kid) WHERE (kw.kwstatus = 2 OR kw.kwstatus = 3 OR kw.kwstatus = 4 OR kw.kwstatus = 7) AND kw.kwid = '" & idtransaksi & "'", strCon)
        'DETAIL
        dtdetail = AsDataTableAmbilDariDB("SELECT kwd.* FROM m_11_kw_detail kwd JOIN m_11_kw kw ON kwd.idkw = kw.kwid WHERE (kw.kwstatus = 2 OR kw.kwstatus = 3 OR kw.kwstatus = 4 OR kw.kwstatus = 7) AND kw.kwid = '" & idtransaksi & "'", strCon)
        'PAY
        dtpay = AsDataTableAmbilDariDB("SELECT sip.* FROM m_11_kw_pay sip JOIN m_11_kw si ON sip.idkw = si.kwid WHERE (si.kwstatus = 2 OR si.kwstatus = 3 OR si.kwstatus = 4 OR si.kwstatus = 7) AND si.kwid = '" & idtransaksi & "'", strCon)

        'JIKA TERDAPAT DATA MAKA BUAT JURNAL
        ' If dtutama.Rows.Count > 0 And dtdetail.Rows.Count > 0 Then
        If dtutama.Rows.Count > 0 Then
            'SET DATA UTAMA --------------------------------------
            'SET DATA ROW
            drutama = dtutama.Rows(0)

            'SET SUMBER DAN NOTRANSAKSI
            sumber = drutama("kwsumber")
            noTransaksi = drutama("kwnotransaksi")
            'END OF SET DATA UTAMA -------------------------------

            'AMBIL DATA DARI SETTING -----------------------------
            Dim dtMatauang As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangPasien')", strCon)
            'MATAUANG
            Dim matauang As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional'", "Not found")
            If matauang = "Not found" Then
                rsErrMessage = "Setting Functional Currency not found." : GoTo selesai
            End If
            'KURS
            Dim kurs As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs'", "Not found")
            If kurs = "Not found" Then
                rsErrMessage = "Setting Exchange Rate Functional Currency not found." : GoTo selesai
            End If
            'AKUN PIUTANG USAHA
            Dim rekPiutangUsaha As String = AsDataTableDLookup(dtMatauang, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangPasien'", "Not found")
            If rekPiutangUsaha = "Not found" Then
                rsErrMessage = "Setting Account Receivable Coa not found." : GoTo selesai
            End If
            'END OF AMBIL DATA DARI SETTING ----------------------

            'AKUN DEBIT ------------------------------------------
            'PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            debitkredit = 0
            If dtpay.Rows.Count > 0 Then
                For Each drpay As DataRow In dtpay.Rows
                    'JIKA CARABAYAR GIRO(2) MAKA AMBIL AKUN BAYAR AMBIL DARI rekgiro, ELSE AKUN BAYAR AMBIL DARI rekbank
                    If Double.Parse(drpay("carabayar")) = 2 Then rekBayar = drpay("rekgiro").ToString Else rekBayar = drpay("rekbank").ToString

                    'If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                    '                      String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekBayar, "AKUN BAYAR", Double.Parse(drpay("jumlah")), Double.Parse(drpay("jumlahvalas")), debitkredit, drutama("sicatatan").ToString, "", "", "", "", urutan)) = False Then
                    '    rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & ". (Payment)" : GoTo selesai
                    'End If

                    'NOMINAL = jmlbayar
                    nominal = Math.Abs(Double.Parse(drpay("jumlah")))
                    'NOMINALVALAS = jmlbayarvalas
                    nominalvalas = Math.Abs(Double.Parse(drpay("jumlahvalas")))

                    'GROUPING AKUN BAYAR
                    'filter = "norek = '" & rekBayar & "'"
                    filter = "norek = '" & rekBayar & "' AND costcenter = '' AND divisi = '' AND subdivisi = '' AND proyek = ''"
                    'CEK AKUN SUDAH ADA ATAU BELUM PADA DT JURNAL
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        'JIKA ADA, CEK AKUN TERSEBUT DEBIT / KREDIT
                        debitkreditgroup = Double.Parse(AsDataTableDLookup(dtjurnal, "debitkredit", filter))
                        If debitkreditgroup = debitkredit Then
                            'JIKA AKUN SAMA-SAMA DEBIT/SAMA-SAMA KREDIT MAKA TAMBAHKAN NOMINALNYA SAJA
                            nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                            nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                            'UPDATE NOMINAL AKUN PADA DT JURNAL
                            If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                                rsErrMessage = "Failed update grouping datatable journal transaction #1 " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                            End If

                        Else
                            'JIKA AKUN BERBEDA DEBIT KREDITNYA MAKA NOMINAL BARU = NOMINAL AKUN PADA DT JURNAL - NOMINAL AKUN
                            nominal = Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter)) - nominal
                            nominalvalas = Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter)) - nominalvalas
                            'CEK NOMINAL BARU, JIKA NOMINAL BARU < 1 MAKA PINDAH SISI DEBIT DAN KREDITNYA
                            If nominal < 0 Then
                                'ABSOLUTKAN NILAI NOMINAL
                                nominal = Math.Abs(nominal)
                                nominalvalas = Math.Abs(nominalvalas)
                                'UPDATE NOMINAL DAN DEBITKREDIT DT JURNAL
                                If debitkreditgroup = 0 Then
                                    'JIKA AKUN PADA DT JURNAL DEBIT MAKA DIPINDAH KE KREDIT
                                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas~debitkredit", nominal & "~" & nominalvalas & "~" & 1) = False Then
                                        rsErrMessage = "Failed update grouping datatable journal transaction #2 " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                                    End If
                                Else
                                    'JIKA AKUN PADA DT JURNAL KREDIT MAKA DIPINDAH KE DEBIT
                                    If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas~debitkredit", nominal & "~" & nominalvalas & "~" & 0) = False Then
                                        rsErrMessage = "Failed update grouping datatable journal transaction #3 " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                                    End If
                                End If

                                'JIKA NOMINAL BARU >= 0 MAKA UPDATE NOMINALNYA SAJA
                            Else
                                'UPDATE NOMINAL AKUN PADA DT JURNAL
                                If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                                    rsErrMessage = "Failed update grouping datatable journal transaction #4 " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                                End If
                            End If
                        End If

                        'JIKA TIDAK ADA, TAMBAHKAN AKUN PADA DT JURNAL
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekBayar, "AKUN BAYAR", nominal, nominalvalas, debitkredit, drutama("kwcatatan").ToString, "", "", "", "", urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal transaction " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If

                Next
            Else
                'NOMINAL = sitotaltransaksi * kurs
                nominal = Double.Parse(drutama("kwtotalar"))
                If nominal <> 0 Then
                    'NOMINAL VALAS JIKA MENGGUNAKAN MATAUANG VALAS
                    'If drutama("pbmatauang").ToString <> matauang Then
                    'NOMINAL VALAS = sitotaltransaksi
                    'nominalvalas = Double.Parse(drutama("pbjumlah"))
                    'Else
                    ' nominalvalas = 0
                    ' End If

                    'GROUPING PIUTANG USAHA (rekPiutangUsaha)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & rekPiutangUsaha & "'"
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & 0) = False Then
                            rsErrMessage = "Failed update grouping datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekPiutangUsaha, "PIUTANG", nominal, 0, debitkredit, drutama("kwcatatan").ToString, "", "", "", "", urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal debit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If
                End If
            End If

            'END OF PIUTANG USAHA ~~~~~~~~~~~~~~~~~~~~~~~~~

            debitkredit = 1
            Dim dtUntukKredit As DataTable = AsDataTableAmbilDariDB("SELECT smodule, sgrup, skode, snilai FROM m0_setting WHERE (smodule = 0 AND sgrup = 'accounting' AND skode = 'MataUangFungsional') OR (smodule = 0 AND sgrup = 'accounting' AND skode = 'Kurs') OR (smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara')", strCon)

            Dim rekHutangRekanan As String '= AsDataTableDLookup(dtUntukKredit, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara'", "Not found")
            'If rekHutangRekanan = "Not found" Then
            '    rsErrMessage = "Setting Account Receivable Coa not found." : GoTo selesai
            'End If

            If dtdetail.Rows.Count > 0 Then
                For Each drdetail As DataRow In dtdetail.Rows
                    debitkredit = 1
                    If drdetail("sumber") = "CA" Then
                        rekHutangRekanan = FixQuotes(drdetail("rekhutangpiutang"))
                        nominal = Double.Parse(drdetail("jmlbayar"))
                        nominalvalas = 0
                    Else
                        rekHutangRekanan = AsDataTableDLookup(dtUntukKredit, "snilai", "smodule = 11 AND sgrup = 'akun' AND skode = 'PiutangSementara'", "Not found")
                        nominal = Double.Parse(drdetail("totaltransaksi"))
                        nominalvalas = 0
                    End If
                    'JIKA MENGGUNAKAN MATAUANG VALAS MAKA PERHITUNGAN VALAS, ELSE MAKA PERHITUNGAN BIASA
                    'If drutama("pbmatauang").ToString <> matauang Then
                    'NOMINAL = (((jml * harga) - jmldiskon) * kurs
                    'nominal = Double.Parse(drdetail("totaltransaksi"))
                    'NOMINAL VALAS = (jml * harga) - jmldiskon
                    'nominalvalas = (Double.Parse(drdetail("jumlah")))

                    'JIKA MENGGUNAKAN MATAUANG FUNGSIONAL MAKA PERHITUNGAN BIASA
                    ' Else
                    'NOMINAL = (jml * harga) - jmldiskon
                    ' nominal = (Double.Parse(drdetail("jumlah")))
                    'NOMINAL VALAS = 0 
                    'nominalvalas = 0
                    ' End If

                    'GROUPING AKUN KREDIT (rekpenjualan)
                    filter = "debitkredit=" & debitkredit & " AND norek='" & rekHutangRekanan & "'"
                    If AsDataTableDCount(dtjurnal, filter) > 0 Then
                        nominal += Double.Parse(AsDataTableDLookup(dtjurnal, "nominal", filter))
                        nominalvalas += Double.Parse(AsDataTableDLookup(dtjurnal, "nominalvalas", filter))
                        If AsDataTableUpdateData(dtjurnal, filter, "nominal~nominalvalas", nominal & "~" & nominalvalas) = False Then
                            rsErrMessage = "Failed update grouping datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    Else
                        If AsDataTableTambahData(dtjurnal, "norek~namaakun~nominal~nominalvalas~debitkredit~catatan~costcenter~divisi~subdivisi~proyek~urutan", _
                                                 String.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}~{8}~{9}~{10}", rekHutangRekanan, "PIUTANG SEMENTARA", nominal, nominalvalas, debitkredit, drutama("kwcatatan").ToString, "", "", "", "", urutan)) = False Then
                            rsErrMessage = "Failed insert datatable journal kredit " & sumber & " (" & noTransaksi & ") : " & urutan & "." : GoTo selesai
                        End If
                    End If

                Next
            End If
            'END OF PEND. PENJUALAN ~~~~~~~~~~~~~~~~~~~~~~~
            'END OF AKUN KREDIT ----------------------------------

        Else
            'JIKA TIDAK ADA DATA MAKA UPDATE STATUS MSMQ MENJADI 4(TRANSAKSI TDK APPROVED)
            rsProgress = 4 : GoTo selesai
        End If
        'END OF AMBIL DATA ===================================================

        'BUAT SQL ============================================================
        Dim strValue As New StringBuilder

        'URUTKAN JURNAL
        dtjurnal = AsDataTableFilterSortDt(dtjurnal, "", "debitkredit ASC, norek ASC")

        'DELETE JURNAL JIKA NOMIAL = 0
        AsDataTableDeleteData(dtjurnal, "nominal = 0")

        For Each drjurnal As DataRow In dtjurnal.Rows
            urutan = urutan + 1
            'BUAT VALUE SQL INSERT KE M2_TRANSACTION_JOURNAL
            strValue.Append(IIf(Len(strValue.ToString) = 0, "", ", "))
            'JIKA debitkredit = 0 maka DEBIT, ELSE KREDIT
            If drjurnal("debitkredit") = 0 Then
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,                          tdebit,              tkredit,                          tdebitvalas,         tkreditvalas, tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("kwcabang")) & "', '" & FixQuotes(drutama("kwlokasi")) & "', '" & FixQuotes(drutama("kwsumber")) & "', " & 0 & ", " & drutama("kwid") & ", '" & FixQuotes(drutama("kwnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("kwtgl"))) & "', " & drutama("kwkodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("kwuraian")) & "', ' ', '" & FixQuotes(drutama("kwpasiennama")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("kwmatauang")) & "', '" & FixDouble(drutama("kwkurs")) & "', '', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', '" & 0 & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("kwstatus") & ", 1, NOW(), " & drutama("kwjmlrevisi") & ", " & drutama("kwcetakanke") & ", " & drutama("kwinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("kwinputtgl"), formatTglWaktuDB)) & "', " & drutama("kwmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("kwmodifikasitgl"), formatTglWaktuDB)) & "')")
            Else
                'mapping            tid,                             tcabang,                                  tlokasi,                                  tsumber,    tkodetabelangka,       tidtransaksi,                              tnotransaksi,                                                  ttgl,                        tkodepa,                     tkontak,                                tnorek,                                 turaian,                                  tcatatan,                                  tmatauang,                                   tkurs,      tnobon,   tdebit,                             tkredit,         tdebitvalas,                          tkreditvalas,         tcarabayar, thutangpiutang,                                    ttgljatuhtempo,                                                  ttgllunas,                                  tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang,          tsaldoawal, tadjustment,                         tcostcenter,                                 tdivisi,                                 tsubdivisi,                                tproyek,     tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke,                     tinputuser,                                           tinputtgl,                                              tmodifikasiuser,                                                tmodifikasitgl
                'strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("lucabang")) & "', '" & FixQuotes(drutama("lulokasi")) & "', '" & FixQuotes(drutama("lusumber")) & "', " & 0 & ", " & drutama("luid") & ", '" & FixQuotes(drutama("lunotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgl"))) & "', " & drutama("lukodepa") & ", " & drutama("lucustomer") & ", '" & FixQuotes(drjurnal("norek")) & "', '" & FixQuotes(drutama("luuraian")) & "', '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("lumatauang")) & "', '" & FixDouble(drutama("lukurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '" & FixQuotes(AsFormatTanggal(drutama("lutgljatuhtempo"))) & "', '" & FixQuotes(AsFormatTanggal(drutama("lutgllunas"))) & "', " & FixDouble(drutama("lustatuslunas")) & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & FixDouble(drutama("lusaldoawal")) & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("lustatus") & ", 1, NOW(), " & drutama("lujmlrevisi") & ", " & drutama("lucetakanke") & ", " & drutama("luinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("luinputtgl"), formatTglWaktuDB)) & "', " & drutama("lumodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("lumodifikasitgl"), formatTglWaktuDB)) & "')")
                strValue.Append("(" & 0 & ", '" & FixQuotes(drutama("kwcabang")) & "', '" & FixQuotes(drutama("kwlokasi")) & "', '" & FixQuotes(drutama("kwsumber")) & "', " & 0 & ", " & drutama("kwid") & ", '" & FixQuotes(drutama("kwnotransaksi")) & "', '" & FixQuotes(AsFormatTanggal(drutama("kwtgl"))) & "', " & drutama("kwkodepa") & ", " & drutama("idkontak") & ", '" & FixQuotes(drjurnal("norek")) & "', CONCAT('" & FixQuotes(drutama("kwuraian")) & "', ' ', '" & FixQuotes(drutama("kwpasiennama")) & "'), '" & FixQuotes(drjurnal("catatan")) & "', '" & FixQuotes(drutama("kwmatauang")) & "', '" & FixDouble(drutama("kwkurs")) & "', '', '" & 0 & "', '" & FixDouble(drjurnal("nominal")) & "', '" & 0 & "', '" & FixDouble(drjurnal("nominalvalas")) & "', " & 0 & ", " & 0 & ", '1900-01-01', '1900-01-01', " & 0 & ", '1900-01-01', " & 0 & ", " & urutan & ", '', " & 0 & ", 0, '" & FixQuotes(drjurnal("costcenter")) & "', '" & FixQuotes(drjurnal("divisi")) & "', '" & FixQuotes(drjurnal("subdivisi")) & "', '" & FixQuotes(drjurnal("proyek")) & "', 1, 0, 'O', '0', 0, " & drutama("kwstatus") & ", 1, NOW(), " & drutama("kwjmlrevisi") & ", " & drutama("kwcetakanke") & ", " & drutama("kwinputuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("kwinputtgl"), formatTglWaktuDB)) & "', " & drutama("kwmodifikasiuser") & ", '" & FixQuotes(AsFormatTanggal(drutama("kwmodifikasitgl"), formatTglWaktuDB)) & "')")
            End If
        Next


        'TAMBAHKAN SQL HAPUS JURNAL LAMA
        rsSql = "DELETE FROM M2_Transaction_Journal WHERE tsumber = 'kw' AND tgrup = '1' AND tidtransaksi = '" & FixDouble(idtransaksi) & "'"

        'GABUNGKAN VALUE SQL
        If Len(strValue.ToString) > 0 Then
            'QUERY INSERT JURNAL BARU
            rsSql = String.Concat(rsSql, sptRow, "Insert into M2_Transaction_Journal(tid, tcabang, tlokasi, tsumber, tkodetabelangka, tidtransaksi, tnotransaksi, ttgl, tkodepa, tkontak, tnorek, turaian, tcatatan, tmatauang, tkurs, tnobon, tdebit, tkredit, tdebitvalas, tkreditvalas, tcarabayar, thutangpiutang, ttgljatuhtempo, ttgllunas, tstatuslunas, ttglrekonsiliasi, tsudahrekonsiliasi, turutan, tnohutangpiutang, tsaldoawal, tadjustment, tcostcenter, tdivisi, tsubdivisi, tproyek, tgrup, tretail, tjenisaruskas, tjmlrealisasium, tstatusrealisasi, tstatus, tposting, tpostingtgl, tjmlrevisi, tcetakanke, tinputuser, tinputtgl, tmodifikasiuser, tmodifikasitgl) values" & strValue.ToString & "")

            'TAMBAHKAN SQL UNTUK UPDATE TGLPOSTING SI
            rsSql = String.Concat(rsSql, sptRow, "UPDATE m_11_kw SET kwposting = 1, kwpostingtgl = NOW() WHERE kwid = '" & idtransaksi & "'")
        End If
        'END OF BUAT SQL =====================================================

        rsProgress = 1

selesai:
        wsResult = String.Concat(rsProgress, sptSubParam, rsErrMessage, sptSubParam, rsSql)
        Return wsResult
    End Function
#End Region

End Class
