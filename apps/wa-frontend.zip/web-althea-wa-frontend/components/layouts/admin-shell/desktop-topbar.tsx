'use client';

import { Bell } from 'lucide-react';
import type { Role } from '@/shared/auth/constants';
import { WaStatusIndicator } from '@/features/wa-connection-health/ui/wa-status-indicator';
import type { WaBannerRole } from '@/features/wa-connection-health/model/types';
import { RoleSwitcher } from './role-switcher';

/**
 * Top header desktop — breadcrumb + page title + bell + avatar mini.
 */
export function DesktopTopbar({
  meta,
  initial,
  userName,
  avatarUrl,
  avatarColor,
  availableRoles,
  activeRole,
  role,
}: {
  meta: { category: string; label: string; title: string } | null;
  initial: string;
  userName: string;
  avatarUrl?: string | null;
  avatarColor?: string | null;
  availableRoles?: Role[];
  activeRole?: Role | null;
  role: WaBannerRole;
}) {
  return (
    <header
      className="hidden lg:flex sticky top-0 z-20 items-center justify-between border-b border-border bg-card"
      style={{ height: 64, padding: '0 28px' }}
    >
      <div className="flex flex-col leading-tight">
        {meta ? (
          <span className="caption" style={{ fontSize: 12 }}>
            {meta.category} · {meta.label}
          </span>
        ) : null}
        <h1
          style={{
            margin: 0,
            fontFamily: 'var(--font-serif)',
            fontSize: 22,
            fontWeight: 500,
            color: 'var(--teal-800)',
            letterSpacing: '-0.01em',
          }}
        >
          {meta?.title ?? 'Althea Psychology'}
        </h1>
      </div>
      <div className="flex items-center gap-3">
        <WaStatusIndicator role={role} />
        {availableRoles && activeRole && availableRoles.length > 1 ? (
          <RoleSwitcher
            availableRoles={availableRoles}
            activeRole={activeRole}
            variant="desktop"
          />
        ) : null}
        <button
          type="button"
          className="btn btn-icon btn-ghost btn-sm"
          aria-label="Notifikasi"
          title="Notifikasi"
        >
          <Bell size={17} />
        </button>
        <div
          style={{
            width: 36,
            height: 36,
            borderRadius: 999,
            background: avatarUrl ? 'transparent' : (avatarColor ?? 'var(--cream-300)'),
            color: avatarColor ? '#fff' : 'var(--teal-800)',
            display: 'grid',
            placeItems: 'center',
            fontWeight: 700,
            fontSize: 14,
            flexShrink: 0,
            overflow: 'hidden',
          }}
          title={userName}
          aria-label={`Akun: ${userName}`}
        >
          {avatarUrl ? (
            <img
              src={avatarUrl}
              alt={userName}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
          ) : (
            initial
          )}
        </div>
      </div>
    </header>
  );
}
