'use client';

import { Bell } from 'lucide-react';
import type { Role } from '@/shared/auth/constants';
import { WaStatusIndicator } from '@/features/wa-connection-health/ui/wa-status-indicator';
import type { WaBannerRole } from '@/features/wa-connection-health/model/types';
import { RoleSwitcher } from './role-switcher';

/**
 * Top bar mobile — mirror prototype "Mobile · Admin Klinik":
 * avatar + nama/role di kiri, judul halaman, bell di kanan.
 * Avatar di-tap untuk membuka menu (sidebar drawer).
 *
 * Untuk user multi-role: RoleSwitcher pill muncul di tempat bell (bell
 * di-hide saat switcher tampil — slot mobile sempit, switcher prioritas).
 */
export function MobileTopbar({
  roleShort,
  userName,
  initial,
  pageTitle,
  onOpenMenu,
  availableRoles,
  activeRole,
  role,
}: {
  roleShort: string;
  userName: string;
  initial: string;
  pageTitle: string;
  onOpenMenu: () => void;
  availableRoles?: Role[];
  activeRole?: Role | null;
  role: WaBannerRole;
}) {
  const showSwitcher = !!(availableRoles && activeRole && availableRoles.length > 1);
  return (
    <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-border bg-card px-4 lg:hidden">
      <button
        type="button"
        onClick={onOpenMenu}
        className="flex items-center gap-2.5 text-left"
        aria-label="Buka menu"
      >
        <span
          className="flex h-9 w-9 items-center justify-center rounded-full text-sm font-semibold"
          style={{ background: 'var(--sage-100, #dde9d8)', color: 'var(--sage-700, #3a5b3f)' }}
        >
          {initial}
        </span>
        <span className="flex flex-col leading-tight">
          <span className="text-sm font-semibold text-teal-800">{userName}</span>
          <span className="caption text-[11px]">{roleShort}</span>
        </span>
      </button>

      {pageTitle && !showSwitcher && (
        <span className="brand-mark mx-auto text-base text-teal-800">
          {pageTitle}
        </span>
      )}

      <div className="ml-auto flex items-center gap-2">
        <WaStatusIndicator role={role} compact />
        {showSwitcher && availableRoles && activeRole ? (
          <RoleSwitcher
            availableRoles={availableRoles}
            activeRole={activeRole}
            variant="mobile"
          />
        ) : (
          <button
            type="button"
            className="btn btn-ghost btn-icon btn-sm"
            aria-label="Notifikasi"
          >
            <Bell className="h-5 w-5" />
          </button>
        )}
      </div>
    </header>
  );
}
