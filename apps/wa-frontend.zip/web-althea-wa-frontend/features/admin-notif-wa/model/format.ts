/**
 * Format helpers untuk halaman Notifikasi WA.
 */
import { RECIPIENT_STYLE, STATUS_STYLE } from './constants';
import type { WaLog } from './types';

/**
 * Label sumber pesan untuk satu baris log.
 * - Pesan dari template DB → nama template.
 * - Pesan tanpa template (mis. kirim Invoice/Bukti Pembayaran Add-on 2 yang
 *   caption + link-nya dibangun di kode, jadi `templateId` memang null) →
 *   diturunkan dari metadata, BUKAN "(template dihapus)" yang menyesatkan.
 */
export function templateLabel(log: WaLog): string {
  if (log.template?.name) return log.template.name;
  const meta = log.metadata;
  if (meta?.docType === 'receipt') {
    return meta.invoiceNumber ? `Bukti Pembayaran · ${meta.invoiceNumber}` : 'Bukti Pembayaran';
  }
  if (meta?.docType === 'invoice') {
    return meta.invoiceNumber ? `Invoice · ${meta.invoiceNumber}` : 'Invoice';
  }
  if (meta?.test) return 'Tes pengiriman';
  return 'Pesan langsung';
}

export function formatTime(iso: string | null): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatDate(iso: string | null): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('id-ID', {
    day: '2-digit',
    month: 'short',
  });
}

export function getRecipStyle(r: string) {
  return (
    RECIPIENT_STYLE[r] || {
      bg: 'var(--cream-100)',
      fg: 'var(--fg-muted)',
      label: r,
    }
  );
}

export function getStatusStyle(s: string) {
  return STATUS_STYLE[s] || { bg: 'var(--cream-100)', fg: 'var(--fg-muted)' };
}

export function isToday(iso: string | null): boolean {
  if (!iso) return false;
  const created = new Date(iso);
  const today = new Date();
  return (
    created.getFullYear() === today.getFullYear() &&
    created.getMonth() === today.getMonth() &&
    created.getDate() === today.getDate()
  );
}
