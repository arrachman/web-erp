/**
 * Konstanta UI untuk halaman Notifikasi WA.
 */
import type { CreateTemplateInput, WaCategory } from './types';

export const CATEGORY_HINT: Record<WaCategory, string> = {
  pengingat: 'Cron-scheduled berdasarkan booking',
  jadwal: 'Dipicu oleh aksi admin',
  onboarding: 'Pendaftaran klien & staff',
  bayar: 'Bukti bayar',
};

export const RECIPIENT_STYLE: Record<string, { bg: string; fg: string; label: string }> = {
  klien: { bg: 'var(--sage-100)', fg: 'var(--sage-800)', label: 'klien' },
  psikolog: { bg: '#dde8f1', fg: '#3b5b75', label: 'psikolog' },
  staff: { bg: 'var(--cream-200)', fg: '#6b5320', label: 'staff' },
  user: { bg: 'var(--info-soft)', fg: 'var(--info)', label: 'user' },
};

export const STATUS_STYLE: Record<string, { bg: string; fg: string }> = {
  dibaca: { bg: 'var(--success-soft)', fg: 'var(--success)' },
  sampai: { bg: 'var(--info-soft)', fg: 'var(--info)' },
  terkirim: { bg: 'var(--info-soft)', fg: 'var(--info)' },
  gagal: { bg: 'var(--danger-soft)', fg: 'var(--danger)' },
  queued: { bg: 'var(--warning-soft)', fg: '#8a4a00' },
};

export const COMMON_VARIABLES = [
  '{{nama_klien}}',
  '{{nama_psikolog}}',
  '{{layanan}}',
  '{{tanggal}}',
  '{{waktu}}',
  '{{ruang}}',
];

export const TRIGGER_VARIABLES: Record<string, string[]> = {
  reminder_h1: [
    '{{nama_klien}}',
    '{{nama_psikolog}}',
    '{{layanan}}',
    '{{tanggal}}',
    '{{waktu}}',
    '{{ruang}}',
  ],
  reminder_30m: [
    '{{nama_klien}}',
    '{{nama_psikolog}}',
    '{{layanan}}',
    '{{tanggal}}',
    '{{waktu}}',
    '{{ruang}}',
  ],
  follow_up: ['{{nama_klien}}', '{{nama_psikolog}}', '{{sesi_berikut_tanggal}}'],
  feedback_request: ['{{nama_klien}}', '{{nama_psikolog}}'],
  confirmation: [
    '{{nama_klien}}',
    '{{nama_psikolog}}',
    '{{layanan}}',
    '{{jadwal_lengkap}}',
    '{{total_baris}}',
  ],
  'confirmation-psychology': ['{{nama_psikolog}}', '{{nama_klien}}', '{{jadwal_lengkap}}'],
  reschedule: [
    '{{nama_klien}}',
    '{{nama_psikolog}}',
    '{{layanan}}',
    '{{ruang}}',
    '{{tanggal_lama}}',
    '{{waktu_lama}}',
    '{{tanggal_baru}}',
    '{{waktu_baru}}',
    '{{alasan}}',
  ],
  cancel: [
    '{{nama_klien}}',
    '{{nama_psikolog}}',
    '{{layanan}}',
    '{{tanggal}}',
    '{{waktu}}',
    '{{ruang}}',
    '{{alasan}}',
  ],
  walk_in_confirmation: ['{{nama_klien}}', '{{nama_psikolog}}', '{{ruang}}'],
  slot_moved: ['{{nama_klien}}', '{{tanggal_baru}}', '{{waktu_baru}}', '{{ruang_baru}}'],
  welcome: ['{{nama_klien}}'],
  clinic_info: ['{{alamat}}', '{{telepon}}', '{{jam}}', '{{maps_link}}'],
  psikolog_info: [
    '{{nama_psikolog}}',
    '{{title}}',
    '{{spesialisasi}}',
    '{{pendidikan}}',
    '{{lisensi}}',
  ],
  psikolog_welcome: ['{{nama_psikolog}}', '{{login_url}}', '{{username}}'],
  invoice: [
    '{{nama_klien}}',
    '{{layanan}}',
    '{{nomor}}',
    '{{total}}',
    '{{terbayar}}',
    '{{belum_terbayar}}',
    '{{link_invoice}}',
  ],
  receipt: ['{{nama_klien}}', '{{layanan}}', '{{total}}', '{{metode}}', '{{link_receipt}}'],
};

export type TriggerMeta = {
  status: 'auto' | 'cron' | 'manual' | 'paket-full' | 'belum-aktif';
  /** Narasi singkat: apa yang terjadi dan kenapa WA ini ada. */
  cerita: string;
  /** Kondisi yang harus terpenuhi supaya notif benar-benar terkirim. */
  syarat: string[];
  /** Tips atau peringatan yang perlu diperhatikan admin. */
  tips?: string;
};

export const TRIGGER_META: Record<string, TriggerMeta> = {
  reminder_h1: {
    status: 'cron',
    cerita:
      'Notifikasi ini dikirim otomatis oleh sistem sehari sebelum jadwal sesi. ' +
      'Tujuannya simpel: supaya klien tidak lupa dan bisa mempersiapkan diri. ' +
      'Sistem memeriksa jadwal secara rutin dan langsung mengirim begitu masuk window H-1.',
    syarat: [
      'Booking masih aktif — belum dibatalkan atau selesai',
      'Nomor WhatsApp klien sudah diisi di data klien',
      'Reminder H-1 belum pernah dikirim untuk booking ini (tidak akan kirim dua kali)',
    ],
    tips: 'Kalau klien tidak terima WA, cek apakah nomor HP-nya sudah benar dan diisi format internasional (628xxx).',
  },
  reminder_30m: {
    status: 'cron',
    cerita:
      'Pengingat terakhir yang dikirim 30 menit sebelum sesi dimulai. ' +
      'Cocok untuk klien yang sering lupa atau perjalanannya perlu perhitungan waktu. ' +
      'Sistem cek lebih sering (tiap menit) supaya timing-nya tepat.',
    syarat: [
      'Booking masih aktif',
      'Nomor WhatsApp klien sudah diisi',
      'Reminder 30 menit belum pernah dikirim untuk booking ini',
    ],
    tips: 'Pastikan isi pesan singkat dan to-the-point — klien biasanya sudah dalam perjalanan.',
  },
  follow_up: {
    status: 'auto',
    cerita:
      'Dikirim otomatis sesaat setelah admin atau psikolog menandai sesi sebagai selesai. ' +
      'Fungsinya untuk menjaga hubungan baik dengan klien pasca-sesi — bisa berisi ucapan terima kasih, ' +
      'info sesi berikutnya, atau dorongan untuk lanjut terapi.',
    syarat: [
      'Admin atau psikolog sudah klik "Selesai" di detail booking',
      'Nomor WhatsApp klien sudah diisi',
    ],
    tips: 'Kalau template memakai variabel {{sesi_berikut_tanggal}}, sistem auto-lookup booking lanjutan klien terdekat (status scheduled/confirmed/checked_in, scheduledStart > now). Kalau belum ada booking lanjutan, variabel diisi "(belum dijadwalkan)" — jadi input booking lanjutan dulu sebelum tandai "Selesai" supaya isinya akurat.',
  },
  feedback_request: {
    status: 'cron',
    cerita:
      'Dikirim otomatis H+1 setelah sesi selesai — sistem cek tiap hari jam 08:00 WIB ' +
      'dan mengirim ke semua klien yang sesinya ditandai "Selesai" pada hari sebelumnya. ' +
      'Klien diminta membalas pesan WhatsApp ini langsung dengan masukannya (tanpa link/formulir); ' +
      'balasan dibaca tim lewat WhatsApp.',
    syarat: [
      'Sesi sudah ditandai "Selesai" (status completed) pada hari sebelumnya',
      'Nomor WhatsApp klien sudah diisi & klien tidak opt-out',
      'Feedback belum pernah dikirim untuk booking ini (tidak akan kirim dua kali)',
    ],
    tips: 'Jaga template tetap meminta klien membalas pesan ini — jangan masukkan link form. Balasan klien masuk ke WhatsApp klinik, bukan ke aplikasi.',
  },
  confirmation: {
    status: 'auto',
    cerita:
      'Otomatis terkirim ke KLIEN begitu booking dibuat di sistem. ' +
      'Sejak template ini dikhususkan untuk klien, notifikasi ke psikolog dipisah ' +
      'ke template "Konfirmasi Booking - Psikolog" tersendiri.',
    syarat: ['Booking sudah ada di sistem', 'Nomor WhatsApp klien sudah diisi'],
    tips: 'Boleh diisi sapaan personal ke klien (mis. "Halo {{nama_klien}}") — template ini tidak lagi dikirim ke psikolog.',
  },
  'confirmation-psychology': {
    status: 'auto',
    cerita:
      'Otomatis terkirim ke PSIKOLOG begitu admin menambahkan sesi baru ke jadwalnya — ' +
      'baik booking single-session, sesi baru dalam paket, maupun paket baru. ' +
      'Terpisah dari "Konfirmasi Booking" (klien) supaya isi pesan bisa disapa personal ke psikolog.',
    syarat: [
      'Booking sudah ada di sistem (bukan sesi lampau/backdate)',
      'Nomor psikolog (User.phone) sudah diisi',
    ],
    tips: 'Body boleh menyapa langsung psikolog (mis. "Halo {{nama_psikolog}}") — template ini hanya dikirim ke psikolog, tidak ke klien.',
  },
  reschedule: {
    status: 'auto',
    cerita:
      'Otomatis dikirim setiap kali jadwal booking digeser — baik tanggalnya, jam-nya, psikolognya, maupun ruangannya. ' +
      'Klien langsung dapat info jadwal baru tanpa perlu dihubungi manual. ' +
      'Kalau ada alasan reschedule, akan ikut terkirim di pesan.',
    syarat: [
      'Reschedule dilakukan lewat fitur Reschedule di sistem (bukan edit manual di database)',
      'Nomor WhatsApp klien sudah diisi',
    ],
    tips: 'Gunakan variabel {{alasan_reschedule}} di template supaya klien tahu kenapa jadwalnya diubah.',
  },
  cancel: {
    status: 'auto',
    cerita:
      'Langsung terkirim begitu admin membatalkan booking. ' +
      'Penting supaya klien tidak datang sia-sia ke klinik dan bisa reschedule lebih awal.',
    syarat: [
      'Pembatalan dilakukan lewat fitur Cancel di sistem',
      'Nomor WhatsApp klien sudah diisi',
    ],
    tips: 'Selalu isi alasan pembatalan di form cancel — akan masuk ke variabel {{alasan}} sehingga klien mendapat penjelasan, bukan hanya "dibatalkan".',
  },
  walk_in_confirmation: {
    status: 'auto',
    cerita:
      'Terkirim otomatis menggantikan "Konfirmasi Booking" ketika admin/resepsionis membuat ' +
      'booking single-session dan mematikan checkbox "Kirim Konfirmasi Booking" di wizard. ' +
      'Checkbox tersebut default aktif supaya booking baru mengirim Konfirmasi Booking biasa.',
    syarat: [
      'Booking baru single-session dan bukan sesi lampau',
      'Checkbox "Kirim Konfirmasi Booking" di wizard booking tidak dicentang',
      'Nomor WhatsApp klien sudah diisi',
    ],
    tips: 'Biarkan checkbox tetap dicentang untuk Konfirmasi Booking biasa; matikan hanya bila booking perlu memakai template Walk-in Confirmation.',
  },
  slot_moved: {
    status: 'belum-aktif',
    cerita:
      'Template internal untuk memberi tahu psikolog atau staf kalau jadwal mereka digeser oleh admin. ' +
      'Berbeda dengan reschedule klien — ini khusus notif ke tim internal. ' +
      'Belum tersambung ke sistem, jadi belum aktif.',
    syarat: ['Fitur auto-trigger belum tersedia', 'Sementara bisa dikirim manual'],
  },
  welcome: {
    status: 'auto',
    cerita:
      'Pesan sambutan yang langsung dikirim saat admin mendaftarkan klien baru ke sistem. ' +
      'Momen pertama kali klien "kenal" Althea lewat WA — jadi kesan pertama sangat penting. ' +
      'Pastikan pesannya hangat dan informatif.',
    syarat: [
      'Admin selesai membuat data klien baru',
      'Nomor WhatsApp klien diisi saat pendaftaran',
    ],
    tips: 'Kalau klien tidak dapat WA welcome, cek apakah nomor HP diisi sebelum klik Simpan — sistem hanya kirim saat pertama kali data dibuat.',
  },
  clinic_info: {
    status: 'manual',
    cerita:
      'Template serbaguna untuk mengirim informasi umum tentang klinik ke klien. ' +
      'Tidak ada trigger otomatis — admin kirim kapan saja dianggap perlu, ' +
      'misalnya saat klien baru mau mulai terapi atau ada perubahan jadwal operasional klinik.',
    syarat: ['Nomor WhatsApp klien sudah diisi', 'Admin kirim manual via Send Test'],
  },
  psikolog_info: {
    status: 'auto',
    cerita:
      'Dikirim otomatis saat klien untuk pertama kalinya booking dengan psikolog tertentu. ' +
      'Isinya profil singkat psikolog — nama, gelar, spesialisasi. ' +
      'Tujuannya agar klien lebih percaya dan tidak canggung sebelum sesi pertama.',
    syarat: [
      'Ini booking pertama klien dengan psikolog tersebut',
      'Nomor WhatsApp klien sudah diisi',
      'Profil psikolog sudah dilengkapi di menu Psikolog (nama, gelar, spesialisasi)',
    ],
    tips: 'Kalau variabel profil kosong di WA, berarti data psikolog belum lengkap — minta psikolog mengisi profilnya di /psikolog/profile.',
  },
  invoice: {
    status: 'manual',
    cerita:
      'Invoice (tagihan) dikirim ke klien saat admin menekan "Kirim WA" di modul Pembayaran ' +
      '(atau centang "Kirim ke WhatsApp klien" saat buat dokumen). Klien menerima link halaman invoice.',
    syarat: [
      'Invoice sudah dibuat di menu Pembayaran / kolom Pembayaran Daftar Jadwal',
      'Nomor WhatsApp klien sudah diisi',
    ],
    tips: 'Teks di sini adalah isi pesan WA invoice yang benar-benar dikirim ke klien — edit di sini langsung mengubah pesannya. Variabel: {{nama_klien}}, {{layanan}}, {{total}}, {{nomor}}, {{terbayar}}, {{belum_terbayar}}, {{link_invoice}}.',
  },
  receipt: {
    status: 'auto',
    cerita:
      'Bukti pembayaran (receipt) dikirim ke klien setelah pembayaran dicatat di modul Pembayaran. ' +
      'Praktis karena klien tidak perlu datang ke klinik hanya untuk ambil kwitansi.',
    syarat: [
      'Pembayaran sudah dicatat di detail booking / menu Pembayaran',
      'Nomor WhatsApp klien sudah diisi',
    ],
    tips: 'Teks di sini adalah isi pesan WA bukti pembayaran yang benar-benar dikirim ke klien — edit di sini langsung mengubah pesannya. Variabel: {{nama_klien}}, {{layanan}}, {{total}}, {{metode}}, {{link_receipt}}.',
  },
};

export const STATUS_LABEL: Record<TriggerMeta['status'], string> = {
  auto: 'Otomatis',
  cron: 'Terjadwal',
  manual: 'Manual',
  'paket-full': 'Paket Full',
  'belum-aktif': 'Belum aktif',
};

export const STATUS_PILL_STYLE: Record<TriggerMeta['status'], string> = {
  auto: 'bg-sage-100 text-sage-800',
  cron: 'bg-blue-100 text-blue-900',
  manual: 'bg-cream-200 text-teal-800',
  'paket-full': 'bg-amber-100 text-amber-900',
  'belum-aktif': 'bg-rose-100 text-rose-900',
};

export const EMPTY_TEMPLATE: CreateTemplateInput = {
  name: '',
  category: 'pengingat',
  triggerEvent: '',
  body: '',
  recipients: ['klien'],
  isActive: true,
};
