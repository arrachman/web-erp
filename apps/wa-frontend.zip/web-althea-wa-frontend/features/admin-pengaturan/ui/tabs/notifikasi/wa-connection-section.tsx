'use client';

import Link from 'next/link';
import { useState } from 'react';
import { RefreshCw, Smartphone } from 'lucide-react';
import type { UpdateSettingsInput } from '../../../api/settings.api';
import { FieldRow } from '../../shared/field-row';
import { Toggle } from '../../shared/toggle';
import { useWaDeviceStatus } from '../../../hooks/use-wa-device-status';
import { useWaDeviceList } from '../../../hooks/use-wa-devices';
import { WaDevicePairingDrawer } from './wa-device-pairing-drawer';
import { WaDeviceEditDrawer } from './wa-device-edit-drawer';

/**
 * Bagian "Koneksi WhatsApp" + master toggle "Aktifkan kirim WA".
 * Status device di-fetch real-time dari SentiWA via GET /clinic/settings/wa-status.
 */
export function WaConnectionSection({
  form,
  set,
  showNotifWaLink = true,
}: {
  form: UpdateSettingsInput;
  set: <K extends keyof UpdateSettingsInput>(
    key: K,
    value: UpdateSettingsInput[K],
  ) => void;
  showNotifWaLink?: boolean;
}) {
  const { data: deviceStatus, isLoading, refetch } = useWaDeviceStatus();
  const { data: deviceList, refetch: refetchDeviceList } = useWaDeviceList();
  const [pairingOpen, setPairingOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);

  // Ada device terdaftar → hanya boleh EDIT (rename / ganti nomor / reconnect).
  // Belum ada device (0 device) → boleh pairing device pertama.
  //
  // PENTING: pakai daftar device akun (`useWaDeviceList`), bukan cuma
  // `deviceStatus.devicePhone`. Saat device DISCONNECT, SentiWA `/device`
  // balas kosong → `deviceStatus.devicePhone` undefined → dulu salah
  // jatuh ke tombol "Tambah device WA". Daftar akun tetap berisi device
  // walau terputus, jadi tombol benar tetap "Edit device WA".
  const hasDevice =
    (deviceList?.devices.length ?? 0) > 0 || !!deviceStatus?.devicePhone;

  // Device aktif dari daftar akun (GET /wa-devices). Ini sumber status yang ANDAL:
  // endpoint wa-status (SentiWA `/device` per-token) sering kena "rate limit" →
  // balas connected:false walau device sebenarnya `connect`. get-devices (account
  // token) melaporkan status/quota/nomor per-device dengan akurat → pakai sebagai
  // sumber utama, deviceStatus (wa-status) cuma fallback.
  const activeListDevice = deviceList?.devices.find((d) => d.isActive) ?? null;
  const listConnected = (activeListDevice?.status ?? '').toLowerCase() === 'connect';
  const effectivePhone = deviceStatus?.devicePhone ?? activeListDevice?.device;
  const effectiveQuota = deviceStatus?.quota ?? activeListDevice?.quota;
  const effectiveExpired =
    deviceStatus?.expired ?? activeListDevice?.expiredDate ?? activeListDevice?.expired;

  // Nomor WA pengirim yang aktual. Utamakan nomor live dari gateway
  // (effectivePhone), fallback ke nomor tersimpan di ClinicSettings
  // (form.waSenderNumber). Null bila belum ada device sama sekali.
  const senderDigits = (effectivePhone ?? form.waSenderNumber ?? '').replace(/[^0-9]/g, '');
  const senderNumber = senderDigits ? `+${senderDigits}` : null;

  // Status koneksi device murni dari SentiWA — TIDAK di-gate master toggle
  // "Aktifkan kirim WA". Toggle itu cuma menonaktifkan notif otomatis;
  // device tetap bisa tersambung & dipakai untuk edit/pairing/send test.
  // Utamakan get-devices (listConnected); fallback ke wa-status.
  const isConnected = listConnected || (deviceStatus?.connected ?? false);
  const showConnected = isConnected;

  return (
    <>
      <FieldRow
        label="Koneksi WhatsApp"
        hint="API resmi — semua notif kirim dari nomor ini"
      >
        <div className="flex flex-col gap-2" style={{ maxWidth: 580 }}>
          <div
            className="flex items-center gap-2"
            style={{
              padding: '10px 14px',
              background: showConnected ? 'var(--success-soft)' : 'var(--cream-100, #f3f0e8)',
              border: showConnected ? '1px solid #c8e0ce' : '1px solid var(--sage-200)',
              borderRadius: 8,
            }}
          >
            {isLoading ? (
              <RefreshCw
                className="w-3.5 h-3.5 animate-spin shrink-0"
                style={{ color: 'var(--sage-400)' }}
              />
            ) : (
              <span
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: 999,
                  background: showConnected ? 'var(--success)' : 'var(--sage-400, #8aaa91)',
                  boxShadow: showConnected ? '0 0 0 4px rgba(79,140,91,0.18)' : 'none',
                  flexShrink: 0,
                }}
              />
            )}
            <span
              style={{
                fontSize: 13,
                fontWeight: 600,
                color: showConnected ? 'var(--success)' : 'var(--teal-500, #3a6b6b)',
                flex: 1,
              }}
            >
              {isLoading
                ? 'Mengecek status...'
                : isConnected
                  ? 'Tersambung'
                  : 'Perangkat terputus'}{' '}
            </span>
            <div className="flex items-center gap-2 shrink-0">
              {deviceStatus && (
                <span
                  className={showConnected ? 'badge badge-success' : 'badge badge-neutral'}
                >
                  {showConnected ? 'terverifikasi' : 'tidak terhubung'}
                </span>
              )}
              <button
                type="button"
                onClick={() => {
                  void refetch();
                  void refetchDeviceList();
                }}
                title="Refresh status"
                style={{ padding: 4, borderRadius: 4, color: 'var(--sage-500)' }}
              >
                <RefreshCw size={12} />
              </button>
            </div>
          </div>

          {senderNumber && (
            <span
              className="flex items-center gap-1.5"
              style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--teal-700)' }}
            >
              <Smartphone size={13} style={{ color: 'var(--sage-600)' }} />
              Nomor pengirim: {senderNumber}
            </span>
          )}

          {effectiveQuota !== undefined && (
            <span className="caption" style={{ fontSize: 11, color: 'var(--teal-500)' }}>
              Gateway: SentiWA
              {effectiveExpired ? ` · Aktif hingga ${effectiveExpired}` : ''}
            </span>
          )}

          {isConnected && !form.waSendEnabled && (
            <span className="caption" style={{ fontSize: 11, color: 'var(--teal-500)' }}>
              Kirim WA otomatis sedang nonaktif. Device tetap tersambung — edit & kirim test tetap bisa.
            </span>
          )}

          <div className="flex items-center gap-3 flex-wrap" style={{ marginTop: 2 }}>
            <button
              type="button"
              onClick={() => (hasDevice ? setEditOpen(true) : setPairingOpen(true))}
              className="btn btn-ghost btn-sm"
              style={{
                fontSize: 11.5,
                padding: '6px 10px',
                color: 'var(--sage-700)',
                borderRadius: 6,
                border: '1px solid var(--sage-200)',
                background: '#fff',
              }}
            >
              <Smartphone size={12} />
              {hasDevice ? 'Sambungkan device WA' : 'Tambah device WA'}
            </button>

            {showNotifWaLink && (
              <Link
                href="/admin/notif-wa"
                className="caption"
                style={{
                  color: 'var(--sage-700)',
                  cursor: 'pointer',
                  fontSize: 11.5,
                }}
              >
                Buka halaman Notifikasi WA · Log & template untuk edit isi pesan →
              </Link>
            )}
          </div>
        </div>
      </FieldRow>

      <FieldRow
        label="Aktifkan kirim WA"
        hint="Master toggle. Kalau off, semua dispatch di-skip dan ditandai gagal."
      >
        <Toggle
          on={form.waSendEnabled ?? false}
          label={form.waSendEnabled ? 'Aktif' : 'Nonaktif'}
          onChange={(v) => set('waSendEnabled', v)}
        />
      </FieldRow>

      <WaDevicePairingDrawer
        open={pairingOpen}
        onClose={() => {
          setPairingOpen(false);
          refetch();
        }}
      />

      <WaDeviceEditDrawer
        open={editOpen}
        onClose={() => {
          setEditOpen(false);
          refetch();
        }}
      />
    </>
  );
}
