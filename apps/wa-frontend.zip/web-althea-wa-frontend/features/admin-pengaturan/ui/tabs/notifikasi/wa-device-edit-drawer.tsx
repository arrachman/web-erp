'use client';

/**
 * Drawer (RE)CONNECT device WA existing — QR langsung (keputusan 18 Jun 2026).
 *
 * Dipakai saat sudah ada device aktif. Drawer **langsung menampilkan QR** untuk
 * di-scan, tanpa form edit nama/nomor lagi (form "Edit nama/label" dihapus —
 * keputusan 18 Jun 2026: admin hanya butuh QR).
 *
 *   - Device DISCONNECT → QR reconnect biasa (force=false).
 *   - Device CONNECT    → QR tetap ditampilkan, tapi backend **disconnect device
 *     dulu** (force=true) karena Fonnte tidak bisa generate QR untuk device yang
 *     sedang connect ("device already connect"). Konsekuensi: membuka drawer saat
 *     device tersambung akan MEMUTUS koneksi WA aktif demi menampilkan QR baru.
 *
 * Setelah (re)connect berhasil, **nomor WA device yang sebenarnya di-persist** ke
 * `ClinicSettings.waSenderNumber` (via /activate) supaya DB menyimpan nomor sender
 * aktual sebagai informasi, lalu drawer tampilkan panel "Tersambung".
 *
 * Tidak ada flow "tambah device baru" di sini — itu hanya tersedia saat 0 device
 * (lihat WaDevicePairingDrawer). Sesuai keputusan 15 Jun 2026: device aktif hanya
 * boleh di-(re)connect, bukan diganti dengan spawn device baru.
 */

import { useEffect, useMemo, useRef, useState } from 'react';
import { CheckCircle2, Loader2, Smartphone, X } from 'lucide-react';
import { toast } from 'sonner';
import {
  useActivateWaDevice,
  useCheckWaDevice,
  useWaDeviceList,
  useWaDeviceQr,
} from '../../../hooks/use-wa-devices';
import { ScanStep, STATUS_POLL_INTERVAL_MS } from './scan-step';

type View = 'scan' | 'done';

export function WaDeviceEditDrawer({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const [view, setView] = useState<View>('scan');
  const [qrUrl, setQrUrl] = useState<string | null>(null);
  // `forceChange` = device sedang connect → backend disconnect dulu baru generate
  // QR (Fonnte tidak bisa /qr untuk device connect). `false` = reconnect biasa
  // (device sudah disconnect).
  const [forceChange, setForceChange] = useState(false);
  const pollTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const decidedRef = useRef(false);
  // QR sudah berhasil dimuat? (dipakai loop polling untuk memutuskan retry).
  const qrLoadedRef = useRef(false);
  // Pesan error terakhir — supaya toast tidak spam tiap retry interval.
  const lastErrRef = useRef('');

  const deviceList = useWaDeviceList({ enabled: open });
  const qrMut = useWaDeviceQr();
  const checkMut = useCheckWaDevice();
  const activateMut = useActivateWaDevice();

  // Device target untuk (re)connect & sumber token /qr. Utamakan yang `isActive`
  // (sedang jadi sender), tapi FALLBACK ke device pertama di daftar bila belum ada
  // yang aktif — mis. device sudah ditambah tapi belum pernah connect/activate
  // (token belum tersimpan di ClinicSettings). Tanpa fallback ini drawer dead-end
  // "tidak ada device aktif" padahal device-nya ada; dengan fallback, QR tetap
  // tampil supaya admin bisa menyelesaikan koneksi.
  const activeDevice = useMemo(
    () =>
      deviceList.data?.devices.find((d) => d.isActive) ??
      deviceList.data?.devices[0] ??
      null,
    [deviceList.data],
  );
  const deviceToken = activeDevice?.token ?? null;
  const isConnected = (activeDevice?.status ?? '').toLowerCase() === 'connect';

  // Keputusan sekali per buka, setelah daftar device ter-resolve: selalu masuk
  // view 'scan' (QR langsung). `forceChange` = isConnected → device connect butuh
  // disconnect dulu supaya QR bisa di-generate. `decidedRef` jaga supaya refetch
  // device-list (yang mengubah activeDevice saat (re)connect berhasil) tidak
  // mem-bounce keputusan force.
  useEffect(() => {
    if (!open) {
      decidedRef.current = false;
      return;
    }
    if (decidedRef.current || deviceList.isLoading) return;
    decidedRef.current = true;
    setQrUrl(null);
    setForceChange(isConnected);
    setView('scan');
  }, [open, deviceList.isLoading, isConnected]);

  // Persist nomor WA device aktual ke DB (ClinicSettings.waSenderNumber) lewat
  // /activate. Nomor SentiWA fixed ke token; ini menyimpannya sebagai info sender.
  // /activate butuh device dalam status `connect` — dipanggil hanya saat reconnect
  // berhasil. Best-effort: kegagalan sinkron tidak menggagalkan reconnect.
  async function persistCurrentNumber(phoneToSave?: string) {
    if (!deviceToken) return;
    try {
      await activateMut.mutateAsync({
        deviceToken,
        devicePhone: phoneToSave || activeDevice?.device || undefined,
        removePrevious: false,
      });
    } catch {
      // diamkan — sinkron nomor sender gagal, reconnect tetap dianggap sukses
    }
  }

  // Polling saat masuk view "scan". Tiap interval memantau dua hal:
  //  1) status koneksi device (POST /check) → begitu connect, lanjut ke 'done'.
  //  2) QR. Fetch pertama bisa GAGAL / "belum siap" saat sesi WA masih "dingin"
  //     (Baileys butuh beberapa detik untuk QR pertama, kadang melewati deadline
  //     backend). Karena itu QR di-fetch ULANG tiap interval sampai termuat, lalu
  //     di-refresh berkala supaya tidak basi (Baileys merotasi QR ~tiap menit).
  //     Tanpa retry ini, kegagalan fetch pertama membuat spinner "Memuat QR"
  //     menggantung selamanya — inti bug "QR tidak tampil".
  useEffect(() => {
    if (view !== 'scan' || !deviceToken) return;

    let cancelled = false;
    let ticks = 0;
    qrLoadedRef.current = false;
    lastErrRef.current = '';

    const goConnected = async (phone?: string, alreadyConnected = false) => {
      if (pollTimer.current) clearInterval(pollTimer.current);
      await persistCurrentNumber(phone);
      toast.success(alreadyConnected ? 'Device sudah tersambung.' : 'Device tersambung.');
      setForceChange(false);
      setView('done');
      void deviceList.refetch();
    };

    const fetchQr = async () => {
      try {
        const res = await qrMut.mutateAsync({ deviceToken, force: forceChange });
        if (cancelled) return;
        if (res.alreadyConnected) {
          await goConnected(undefined, true);
          return;
        }
        if (res.qrUrl) {
          setQrUrl(res.qrUrl);
          qrLoadedRef.current = true;
          lastErrRef.current = '';
        }
      } catch (err) {
        // Jangan spam toast tiap retry — tampilkan sekali per pesan unik.
        const msg = err instanceof Error ? err.message : 'Gagal generate QR';
        if (!cancelled && lastErrRef.current !== msg) {
          lastErrRef.current = msg;
          toast.error(msg);
        }
      }
    };
    void fetchQr();

    const tick = async () => {
      ticks += 1;
      // 1) cek koneksi
      try {
        const res = await checkMut.mutateAsync({ deviceToken });
        if (!cancelled && res.connected) {
          await goConnected(res.devicePhone);
          return;
        }
      } catch {
        // diamkan, retry interval berikutnya
      }
      // 2) QR belum termuat → terus coba; sudah termuat → refresh tiap ~8 dtk.
      //    Baileys merotasi QR tiap ~20 dtk (ref sekali pakai — scan QR basi =
      //    "Invalid QR code" di HP); backend hanya menyajikan QR segar, jadi
      //    makin rapat refresh makin pendek umur QR yang tampil di layar.
      if (!cancelled && (!qrLoadedRef.current || ticks % 2 === 0)) {
        void fetchQr();
      }
    };
    pollTimer.current = setInterval(tick, STATUS_POLL_INTERVAL_MS);
    return () => {
      cancelled = true;
      if (pollTimer.current) clearInterval(pollTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view, deviceToken, forceChange]);

  async function handleRefreshQr() {
    if (!deviceToken) return;
    setQrUrl(null);
    qrLoadedRef.current = false;
    try {
      const res = await qrMut.mutateAsync({ deviceToken, force: forceChange });
      if (res.qrUrl) {
        setQrUrl(res.qrUrl);
        qrLoadedRef.current = true;
      } else if (res.alreadyConnected) {
        toast.success('Device sudah tersambung.');
        setForceChange(false);
        setView('done');
        void deviceList.refetch();
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Gagal refresh QR');
    }
  }

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-label="Sambungkan Device WhatsApp"
    >
      <div
        className="absolute inset-0 bg-black/40"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        className="relative flex flex-col bg-[var(--cream-50)] shadow-xl"
        style={{ width: '100%', maxWidth: 520, height: '100%', zIndex: 1 }}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between shrink-0"
          style={{
            padding: '16px 22px',
            borderBottom: '1px solid var(--sage-100)',
            background: '#fff',
          }}
        >
          <div className="flex items-center gap-2">
            <Smartphone size={18} style={{ color: 'var(--sage-600)' }} />
            <span style={{ fontSize: 15, fontWeight: 700, color: 'var(--teal-800)' }}>
              {view === 'done' ? 'Device Tersambung' : 'Sambungkan Device WhatsApp'}
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="btn btn-ghost btn-sm"
            style={{ padding: '6px 8px' }}
            aria-label="Tutup"
          >
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div style={{ overflowY: 'auto', flex: 1, padding: '20px 22px 32px' }}>
          {deviceList.isLoading ? (
            <div
              className="flex items-center gap-2"
              style={{ color: 'var(--teal-500)', fontSize: 13 }}
            >
              <Loader2 size={16} className="animate-spin" /> Memuat data device...
            </div>
          ) : !deviceToken ? (
            <div
              style={{
                padding: '12px 14px',
                background: 'var(--cream-100, #f3f0e8)',
                border: '1px solid var(--sage-200)',
                borderRadius: 8,
                fontSize: 13,
                color: 'var(--teal-700)',
                lineHeight: 1.55,
              }}
            >
              Tidak ada device aktif. Device aktif mungkin sudah dihapus dari akun
              SentiWA. Tutup panel ini lalu pair device baru.
            </div>
          ) : view === 'done' ? (
            <div className="flex flex-col items-center gap-3" style={{ padding: '24px 8px' }}>
              <CheckCircle2 size={48} style={{ color: 'var(--success)' }} />
              <span style={{ fontSize: 15, fontWeight: 700, color: 'var(--teal-800)' }}>
                Device tersambung
              </span>
              {activeDevice?.device && (
                <span style={{ fontSize: 13, color: 'var(--teal-600)' }}>
                  +{activeDevice.device}
                </span>
              )}
              <span
                style={{
                  fontSize: 12,
                  color: 'var(--teal-500)',
                  textAlign: 'center',
                  lineHeight: 1.55,
                  maxWidth: 320,
                }}
              >
                WhatsApp siap dipakai untuk kirim notifikasi. Anda bisa menutup
                panel ini.
              </span>
              <button
                type="button"
                onClick={onClose}
                className="btn btn-primary btn-sm"
                style={{ marginTop: 4 }}
              >
                Selesai
              </button>
            </div>
          ) : (
            <ScanStep
              qrUrl={qrUrl}
              devicePhone={activeDevice?.device ?? null}
              loading={qrMut.isPending && !qrUrl}
              onBack={onClose}
              onRefreshQr={handleRefreshQr}
              refreshing={qrMut.isPending}
              notice={
                forceChange ? (
                  <div
                    style={{
                      padding: '10px 14px',
                      background: 'var(--warning-soft, #fdf3e7)',
                      border: '1px solid #f0d9b5',
                      borderRadius: 8,
                      fontSize: 12,
                      color: 'var(--teal-800)',
                      lineHeight: 1.55,
                    }}
                  >
                    <strong>Device lama diputus dulu.</strong> Device yang sedang
                    tersambung harus diputus agar QR bisa dibuat. Bila ingin pakai
                    WhatsApp lain: di HP lama buka WhatsApp →{' '}
                    <strong>Perangkat tertaut</strong> → pilih perangkat Althea →{' '}
                    <strong>Keluar</strong>, lalu scan QR di bawah dengan WhatsApp
                    baru.
                  </div>
                ) : undefined
              }
            />
          )}
        </div>
      </div>
    </div>
  );
}
