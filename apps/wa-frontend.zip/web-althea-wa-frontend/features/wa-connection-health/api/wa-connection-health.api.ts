import { apiClient } from "@/lib/api-client";
import type { WaConnectionHealth } from "../model/types";

export const waConnectionHealthApi = {
  get: () => apiClient.get<WaConnectionHealth>("/wa/connection-health"),
};
