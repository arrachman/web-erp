"use client";

import Link from "next/link";
import { AlertTriangle } from "lucide-react";
import { useWaConnectionHealth } from "../hooks/use-wa-connection-health";
import type { WaBannerRole } from "../model/types";

export function WaDisconnectedBanner({ role }: { role: WaBannerRole }) {
  const query = useWaConnectionHealth(role);
  if (query.data?.status !== "disconnected") return null;

  const isAdmin = role === "admin";
  return (
    <div
      role="alert"
      aria-live="polite"
      className="flex items-start gap-3 border-y px-4 py-3 sm:items-center sm:px-6"
      style={{
        background: "var(--danger-soft, #f5dfd9)",
        borderColor:
          "color-mix(in srgb, var(--danger, #b3493b) 35%, transparent)",
        color: "var(--danger, #b3493b)",
      }}
    >
      <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 sm:mt-0" aria-hidden />
      <div className="min-w-0 flex-1">
        <p className="text-sm font-bold">WhatsApp terputus</p>
        <p className="text-xs leading-relaxed sm:text-sm">
          Pesan otomatis mungkin tidak terkirim.{" "}
          {isAdmin
            ? "Sambungkan kembali perangkat di Pengaturan Notifikasi WA."
            : "Hubungi admin untuk menyambungkan kembali perangkat."}
        </p>
      </div>
      {isAdmin && (
        <Link
          href="/admin/notif-wa"
          className="shrink-0 rounded-md border px-3 py-1.5 text-xs font-bold transition-colors hover:bg-white/50 sm:text-sm"
          style={{ borderColor: "currentColor" }}
        >
          Periksa koneksi
        </Link>
      )}
    </div>
  );
}
