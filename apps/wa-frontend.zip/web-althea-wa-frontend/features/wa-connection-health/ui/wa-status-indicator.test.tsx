import { render, screen } from "@testing-library/react";
import { vi } from "vitest";
import { WaStatusIndicator } from "./wa-status-indicator";
import { useWaConnectionHealth } from "../hooks/use-wa-connection-health";

vi.mock("../hooks/use-wa-connection-health", () => ({
  useWaConnectionHealth: vi.fn(),
}));

const mockedUseHealth = vi.mocked(useWaConnectionHealth);

function mockStatus(
  status: "unknown" | "connected" | "disconnected" | undefined,
) {
  mockedUseHealth.mockReturnValue({
    data: status ? { status } : undefined,
  } as ReturnType<typeof useWaConnectionHealth>);
}

describe("WaStatusIndicator", () => {
  it("shows a connected badge", () => {
    mockStatus("connected");
    render(<WaStatusIndicator role="admin" />);
    expect(screen.getByRole("status").textContent).toContain("WA aktif");
  });

  it("shows a disconnected badge", () => {
    mockStatus("disconnected");
    render(<WaStatusIndicator role="resepsionis" />);
    expect(screen.getByRole("status").textContent).toContain("WA terputus");
  });

  it.each(["unknown", undefined] as const)(
    "renders nothing while status is %s",
    (status) => {
      mockStatus(status);
      const { container } = render(<WaStatusIndicator role="admin" />);
      expect(container.innerHTML).toBe("");
    },
  );

  it("hides the label but keeps an accessible name in compact mode", () => {
    mockStatus("disconnected");
    render(<WaStatusIndicator role="admin" compact />);

    const badge = screen.getByRole("status");
    expect(badge.textContent).toBe("");
    expect(badge.getAttribute("aria-label")).toContain("WhatsApp terputus");
  });
});
