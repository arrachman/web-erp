import { render, screen } from "@testing-library/react";
import { vi } from "vitest";
import { WaDisconnectedBanner } from "./wa-disconnected-banner";
import { useWaConnectionHealth } from "../hooks/use-wa-connection-health";

vi.mock("../hooks/use-wa-connection-health", () => ({
  useWaConnectionHealth: vi.fn(),
}));

const mockedUseHealth = vi.mocked(useWaConnectionHealth);

function mockStatus(status: "unknown" | "connected" | "disconnected") {
  mockedUseHealth.mockReturnValue({ data: { status } } as ReturnType<
    typeof useWaConnectionHealth
  >);
}

describe("WaDisconnectedBanner", () => {
  it.each(["unknown", "connected"] as const)(
    "renders nothing while status is %s",
    (status) => {
      mockStatus(status);
      const { container } = render(<WaDisconnectedBanner role="admin" />);
      expect(container.innerHTML).toBe("");
    },
  );

  it("shows an actionable alert for admin", () => {
    mockStatus("disconnected");
    render(<WaDisconnectedBanner role="admin" />);

    expect(screen.getByRole("alert").textContent).toContain(
      "WhatsApp terputus",
    );
    expect(
      screen
        .getByRole("link", { name: "Periksa koneksi" })
        .getAttribute("href"),
    ).toBe("/admin/notif-wa");
    expect(screen.queryByRole("button")).toBeNull();
  });

  it("tells resepsionis to contact admin without exposing admin route", () => {
    mockStatus("disconnected");
    render(<WaDisconnectedBanner role="resepsionis" />);

    expect(screen.getByRole("alert").textContent).toContain("Hubungi admin");
    expect(screen.queryByRole("link")).toBeNull();
  });
});
