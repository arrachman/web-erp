"use client";

import { useWaConnectionHealth } from "../hooks/use-wa-connection-health";
import type { WaBannerRole, WaConnectionStatus } from "../model/types";

const TONE: Record<
  Exclude<WaConnectionStatus, "unknown">,
  {
    dot: string;
    text: string;
    bg: string;
    border: string;
    label: string;
    title: string;
  }
> = {
  connected: {
    dot: "var(--success, #4f8c5b)",
    text: "var(--success, #4f8c5b)",
    bg: "var(--success-soft, #e1efe2)",
    border: "#c8e0ce",
    label: "WA aktif",
    title: "WhatsApp tersambung — notifikasi otomatis berjalan",
  },
  disconnected: {
    dot: "var(--danger, #b3493b)",
    text: "var(--danger, #b3493b)",
    bg: "var(--danger-soft, #f5dfd9)",
    border: "#e6c4bc",
    label: "WA terputus",
    title: "WhatsApp terputus — notifikasi otomatis mungkin tidak terkirim",
  },
};

/**
 * Indikator status koneksi WhatsApp di topbar.
 * Hanya untuk role yang boleh membaca status (admin & resepsionis); role lain
 * tidak memicu query sama sekali. Selama status masih `unknown` (fetch pertama
 * belum selesai) indikator tidak dirender supaya tidak berkedip.
 *
 * `compact` = mobile (dot saja, slot topbar sempit).
 */
export function WaStatusIndicator({
  role,
  compact = false,
}: {
  role: WaBannerRole;
  compact?: boolean;
}) {
  const query = useWaConnectionHealth(role);
  const status = query.data?.status;
  if (status !== "connected" && status !== "disconnected") return null;

  const tone = TONE[status];
  const dot = (
    <span
      className="inline-block shrink-0 rounded-full"
      style={{
        width: 8,
        height: 8,
        background: tone.dot,
        boxShadow:
          status === "connected"
            ? "0 0 0 3px rgba(79,140,91,0.16)"
            : "0 0 0 3px rgba(179,73,59,0.16)",
      }}
    />
  );

  if (compact) {
    return (
      <span
        className="flex h-9 w-9 items-center justify-center rounded-full"
        style={{ background: tone.bg, border: `1px solid ${tone.border}` }}
        title={tone.title}
        aria-label={tone.title}
        role="status"
      >
        {dot}
      </span>
    );
  }

  return (
    <span
      className="flex items-center gap-2 rounded-full"
      style={{
        padding: "5px 12px",
        background: tone.bg,
        border: `1px solid ${tone.border}`,
        fontSize: 12,
        fontWeight: 700,
        color: tone.text,
      }}
      title={tone.title}
      role="status"
    >
      {dot}
      {tone.label}
    </span>
  );
}
