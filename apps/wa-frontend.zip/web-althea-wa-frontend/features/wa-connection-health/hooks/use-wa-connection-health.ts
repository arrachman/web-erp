"use client";

import { useQuery } from "@tanstack/react-query";
import { waConnectionHealthApi } from "../api/wa-connection-health.api";
import type { WaBannerRole, WaConnectionHealth } from "../model/types";

export function useWaConnectionHealth(role: WaBannerRole) {
  const enabled = role === "admin" || role === "resepsionis";
  return useQuery<WaConnectionHealth>({
    queryKey: ["clinic", "wa", "connection-health"],
    queryFn: waConnectionHealthApi.get,
    enabled,
    staleTime: 15_000,
    refetchInterval: enabled ? 30_000 : false,
    refetchIntervalInBackground: true,
    retry: 1,
  });
}
