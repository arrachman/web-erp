export type WaConnectionStatus = "unknown" | "connected" | "disconnected";
export type WaDeviceStatus = "connecting" | "connect" | "disconnect";

export interface WaConnectionHealth {
  status: WaConnectionStatus;
  reason: string | null;
  disconnectedSince: string | null;
  lastCheckedAt: string | null;
  devices: Array<{
    name: string;
    phone?: string;
    status: WaDeviceStatus;
  }>;
}

export type WaBannerRole = "admin" | "resepsionis" | "owner" | "psikolog";
