import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Request,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '../common/swagger';
import { SkipThrottle } from '@nestjs/throttler';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import type { AuthRequest } from '../auth/types/auth-request';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { AuditAction } from '../clinic-audit/decorators/audit-action.decorator';
import { AuditResource } from '../clinic-audit/decorators/audit-resource.decorator';
import { ClinicSettingsService } from './clinic-settings.service';
import { UpdateSettingsDto } from './dto/clinic-settings.dto';
import {
  ActivateWaDeviceDto,
  CreateWaDeviceDto,
  UpdateWaDeviceDto,
  WaDeviceQrDto,
} from './dto/wa-device.dto';

@ApiTags('Clinic — Settings')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('clinic/settings')
export class ClinicSettingsController {
  constructor(private readonly service: ClinicSettingsService) {}

  @Get()
  @Roles('clinic-admin', 'clinic-owner', 'clinic-psikolog', 'clinic-resepsionis')
  @SkipThrottle()
  @ApiOperation({
    summary: 'Get clinic settings (single row, read-only untuk semua clinic role)',
    description:
      'Semua clinic-* role butuh baca settings: admin/owner (CRUD/dashboard), psikolog (set jadwal availability — perlu lihat slot), resepsionis (booking wizard — perlu lihat slot). Hanya admin yang boleh PATCH.',
  })
  get() {
    return this.service.get();
  }

  @Patch()
  @Roles('clinic-admin')
  @AuditResource('clinic.settings')
  @AuditAction('update_clinic_settings')
  @ApiOperation({ summary: 'Update clinic settings (partial)' })
  update(@Body() dto: UpdateSettingsDto, @Request() req: AuthRequest) {
    return this.service.update(dto, req.user?.sub ?? req.user?.id);
  }

  @Get('wa-status')
  @Roles('clinic-admin')
  @ApiOperation({ summary: 'Cek status koneksi device SentiWA secara real-time' })
  getWaStatus() {
    return this.service.getWaDeviceStatus();
  }

  // ── WA device pairing endpoints (admin-only, butuh SENTIWA_ACCOUNT_TOKEN) ──

  @Get('wa-devices')
  @Roles('clinic-admin')
  @ApiOperation({
    summary: 'List semua device WA di akun SentiWA (mark device yang aktif di app)',
  })
  listWaDevices() {
    return this.service.listDevices();
  }

  @Post('wa-devices')
  @Roles('clinic-admin')
  @AuditResource('clinic.wa_device')
  @AuditAction('add_wa_device')
  @ApiOperation({
    summary: 'Tambah device WA baru di akun SentiWA. Return device token untuk pairing /qr.',
  })
  addWaDevice(@Body() dto: CreateWaDeviceDto) {
    return this.service.addDevice(dto);
  }

  @Post('wa-devices/qr')
  @Roles('clinic-admin')
  @AuditResource('clinic.wa_device')
  @AuditAction('request_wa_qr')
  @ApiOperation({
    summary: 'Ambil payload QR SentiWA untuk scan via WhatsApp Linked Devices',
  })
  getWaDeviceQr(@Body() dto: WaDeviceQrDto) {
    return this.service.getDeviceQr(dto);
  }

  @Post('wa-devices/check')
  @Roles('clinic-admin')
  @AuditResource('clinic.wa_device')
  @AuditAction('check_wa_device')
  @ApiOperation({
    summary: 'Cek status connect device (polling-friendly, tidak hit /qr SentiWA)',
  })
  checkWaDevice(@Body() dto: WaDeviceQrDto) {
    return this.service.checkDeviceConnected(dto);
  }

  @Post('wa-devices/activate')
  @Roles('clinic-admin')
  @AuditResource('clinic.wa_device')
  @AuditAction('activate_wa_device')
  @ApiOperation({
    summary: 'Set device sebagai active sender (simpan token & nomor ke ClinicSettings)',
  })
  activateWaDevice(@Body() dto: ActivateWaDeviceDto, @Request() req: AuthRequest) {
    return this.service.activateDevice(dto, req.user?.sub ?? req.user?.id);
  }

  @Post('wa-devices/update')
  @Roles('clinic-admin')
  @AuditResource('clinic.wa_device')
  @AuditAction('update_wa_device')
  @ApiOperation({
    summary: 'Edit nama & nomor device existing (SentiWA /update-device). Tidak bikin device baru.',
  })
  updateWaDevice(@Body() dto: UpdateWaDeviceDto, @Request() req: AuthRequest) {
    return this.service.updateDevice(dto, req.user?.sub ?? req.user?.id);
  }

  @Delete('wa-devices/:devicePhone')
  @Roles('clinic-admin')
  @AuditResource('clinic.wa_device')
  @AuditAction('remove_wa_device')
  @ApiOperation({
    summary: 'Disconnect + delete device dari akun SentiWA (slot device akun kembali bebas)',
  })
  removeWaDevice(@Param('devicePhone') devicePhone: string, @Request() req: AuthRequest) {
    return this.service.removeDevice(devicePhone, req.user?.sub ?? req.user?.id);
  }
}
