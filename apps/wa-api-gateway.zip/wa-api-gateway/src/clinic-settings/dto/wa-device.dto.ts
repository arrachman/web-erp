import { ApiProperty, ApiPropertyOptional } from '../../common/swagger';
import {
  IsBoolean,
  IsIn,
  IsOptional,
  IsString,
  Matches,
  MaxLength,
  MinLength,
} from 'class-validator';

/**
 * DTOs untuk admin endpoint /clinic/settings/wa-devices.
 *
 * Pairing flow:
 *  1. POST /wa-devices            → addDevice (return device token)
 *  2. POST /wa-devices/qr         → ambil payload QR untuk scan
 *  3. POST /wa-devices/activate   → set sebagai device aktif (simpan token ke DB)
 *  4. DELETE /wa-devices          → disconnect + delete dari SentiWA
 */

export class CreateWaDeviceDto {
  @ApiProperty({
    description: 'Nama device di SentiWA (tampil di dashboard akun).',
    example: 'Althea Klinik',
  })
  @IsString()
  @MinLength(1)
  @MaxLength(60)
  name!: string;

  @ApiProperty({
    description:
      'Nomor WhatsApp device (format bebas — boleh +62..., 62..., 08...). Akan jadi sender nomor.',
    example: '6282211008899',
  })
  @IsString()
  @MinLength(8)
  @MaxLength(20)
  phone!: string;

  @ApiPropertyOptional({
    description:
      'Mode autoread (SentiWA mark inbound message as read). Default off untuk klinis (jaga riwayat chat).',
    enum: ['on', 'off'],
    default: 'off',
  })
  @IsOptional()
  @IsIn(['on', 'off'])
  autoread?: 'on' | 'off';
}

export class WaDeviceQrDto {
  @ApiProperty({
    description: 'Device token (per-device) yang baru dibuat via POST /wa-devices.',
    example: 'ecUetm8Bzpx6sfTqEKPb',
  })
  @IsString()
  @MinLength(8)
  @MaxLength(120)
  deviceToken!: string;

  @ApiPropertyOptional({
    description:
      'Paksa generate QR walau device sedang `connect` (untuk GANTI device/nomor). ' +
      'Backend akan disconnect dulu lalu generate QR baru. Tanpa flag ini, device ' +
      'yang sudah connect dibalas `alreadyConnected: true` (tidak diputus).',
    default: false,
  })
  @IsOptional()
  @IsBoolean()
  force?: boolean;
}

export class ActivateWaDeviceDto {
  @ApiProperty({
    description:
      'Device token (per-device) yang dipakai untuk /send. Disimpan ke ClinicSettings.waActiveDeviceToken.',
    example: 'ecUetm8Bzpx6sfTqEKPb',
  })
  @IsString()
  @MinLength(8)
  @MaxLength(120)
  deviceToken!: string;

  @ApiPropertyOptional({
    description:
      'Nomor WhatsApp device — disimpan ke ClinicSettings.waSenderNumber supaya tampil di UI. Format SentiWA standar (62xxx atau +62xxx).',
    example: '+6282211008899',
  })
  @IsOptional()
  @IsString()
  @MaxLength(30)
  devicePhone?: string;

  @ApiPropertyOptional({
    description:
      'Auto-hapus device lama dari akun SentiWA (disconnect + delete-device). Default true.',
    default: true,
  })
  @IsOptional()
  @IsBoolean()
  removePrevious?: boolean;
}

export class UpdateWaDeviceDto {
  @ApiProperty({
    description:
      'Device token (per-device) milik device yang mau di-edit. Wajib token device, BUKAN account token.',
    example: 'ecUetm8Bzpx6sfTqEKPb',
  })
  @IsString()
  @MinLength(8)
  @MaxLength(120)
  deviceToken!: string;

  @ApiProperty({
    description: 'Nama device baru (SentiWA: min 2 max 30).',
    example: 'WA Klinik Althea',
  })
  @IsString()
  @MinLength(2)
  @MaxLength(30)
  name!: string;

  @ApiProperty({
    description:
      'Nomor device baru (SentiWA: min 8 max 15, unik antar device). Format bebas — boleh +62..., 62..., 08...',
    example: '6282211008899',
  })
  @IsString()
  @MinLength(8)
  @MaxLength(15)
  phone!: string;
}

export class DeleteWaDeviceDto {
  @ApiProperty({
    description:
      'Phone device yang mau dihapus (sesuai field `device` di /get-devices, mis. "6285735248244").',
    example: '6285735248244',
  })
  @IsString()
  @Matches(/^[0-9+]{8,20}$/)
  devicePhone!: string;
}
