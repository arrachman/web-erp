import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClinicWaMonitorController } from './clinic-wa-monitor.controller';
import { WaConnectionMonitorService } from './wa-connection-monitor.service';
import { WaDisconnectAlertMailerService } from './wa-disconnect-alert-mailer.service';

@Module({
  imports: [ConfigModule],
  controllers: [ClinicWaMonitorController],
  providers: [WaConnectionMonitorService, WaDisconnectAlertMailerService],
  exports: [WaConnectionMonitorService],
})
export class ClinicWaMonitorModule {}
