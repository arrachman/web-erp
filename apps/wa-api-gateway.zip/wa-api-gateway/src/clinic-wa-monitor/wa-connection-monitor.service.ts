import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Cron, CronExpression } from '@nestjs/schedule';
import { waEnv } from '../clinic-wa/wa-env.util';
import { WaDisconnectAlertMailerService } from './wa-disconnect-alert-mailer.service';
import type {
  WaConnectionHealthResponse,
  WaGatewayHealth,
  WaGatewayHealthDevice,
  WaMonitorReason,
  WaMonitorState,
} from './wa-monitor.types';

const HEALTH_TIMEOUT_MS = 5_000;
const DEFAULT_ALERT_AFTER_MS = 5 * 60 * 1000;
const DEVICE_STATUSES = new Set(['connecting', 'connect', 'disconnect']);

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}

function isHealthDevice(value: unknown): value is WaGatewayHealthDevice {
  if (!isRecord(value)) return false;
  return (
    typeof value['token'] === 'string' &&
    typeof value['name'] === 'string' &&
    (value['phone'] === undefined || typeof value['phone'] === 'string') &&
    typeof value['status'] === 'string' &&
    DEVICE_STATUSES.has(value['status']) &&
    typeof value['reconnectAttempts'] === 'number' &&
    typeof value['idleMs'] === 'number'
  );
}

function isGatewayHealth(value: unknown): value is WaGatewayHealth {
  if (!isRecord(value)) return false;
  return (
    typeof value['status'] === 'boolean' &&
    typeof value['service'] === 'string' &&
    typeof value['degraded'] === 'boolean' &&
    Array.isArray(value['devices']) &&
    value['devices'].every(isHealthDevice) &&
    typeof value['ts'] === 'number'
  );
}

@Injectable()
export class WaConnectionMonitorService implements OnModuleInit {
  private readonly logger = new Logger(WaConnectionMonitorService.name);
  private checking = false;
  private state: WaMonitorState = {
    status: 'unknown',
    reason: null,
    disconnectedSince: null,
    lastCheckedAt: null,
    lastConnectedAt: null,
    alertSentAt: null,
    devices: [],
  };

  constructor(
    private readonly config: ConfigService,
    private readonly mailer: WaDisconnectAlertMailerService,
  ) {}

  onModuleInit(): void {
    void this.checkConnection();
  }

  @Cron(CronExpression.EVERY_MINUTE, { name: 'wa-connection-monitor' })
  async checkConnection(now = new Date()): Promise<void> {
    if (this.checking) return;
    this.checking = true;
    try {
      const result = await this.fetchHealth();
      if (result.health) {
        await this.applyHealth(result.health, now);
      } else {
        await this.applyDisconnected(result.reason, [], now);
      }
    } finally {
      this.checking = false;
    }
  }

  getPublicState(): WaConnectionHealthResponse {
    return {
      status: this.state.status,
      reason: this.state.reason,
      disconnectedSince: this.state.disconnectedSince?.toISOString() ?? null,
      lastCheckedAt: this.state.lastCheckedAt?.toISOString() ?? null,
      devices: this.state.devices.map((device) => ({ ...device })),
    };
  }

  private async fetchHealth(): Promise<
    { health: WaGatewayHealth; reason: 'connected' } | { health: null; reason: WaMonitorReason }
  > {
    const apiUrl = (waEnv(this.config, 'API_URL') ?? 'http://localhost:3204').replace(/\/$/, '');
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), HEALTH_TIMEOUT_MS);
    try {
      const response = await fetch(`${apiUrl}/health`, { signal: controller.signal });
      if (!response.ok) return { health: null, reason: 'gateway_unreachable' };
      const payload: unknown = await response.json();
      if (!isGatewayHealth(payload)) {
        return { health: null, reason: 'invalid_health_response' };
      }
      return { health: payload, reason: 'connected' };
    } catch (error) {
      this.logger.warn(
        `Pengecekan koneksi WA gagal: ${error instanceof Error ? error.name : 'unknown error'}`,
      );
      return { health: null, reason: 'gateway_unreachable' };
    } finally {
      clearTimeout(timeout);
    }
  }

  private async applyHealth(health: WaGatewayHealth, now: Date): Promise<void> {
    const devices = health.devices.map(({ name, phone, status }) => ({ name, phone, status }));
    if (devices.length === 0) {
      await this.applyDisconnected('no_devices', devices, now);
      return;
    }

    const disconnected = devices.some((device) => device.status === 'disconnect');
    const connecting = devices.some((device) => device.status === 'connecting');
    if (health.degraded || disconnected || connecting) {
      await this.applyDisconnected(
        disconnected ? 'device_disconnected' : 'device_connecting',
        devices,
        now,
      );
      return;
    }

    this.state = {
      status: 'connected',
      reason: 'connected',
      disconnectedSince: null,
      lastCheckedAt: now,
      lastConnectedAt: now,
      alertSentAt: null,
      devices,
    };
  }

  private async applyDisconnected(
    reason: WaMonitorReason,
    devices: WaMonitorState['devices'],
    now: Date,
  ): Promise<void> {
    const disconnectedSince = this.state.disconnectedSince ?? now;
    this.state = {
      ...this.state,
      status: 'disconnected',
      reason,
      disconnectedSince,
      lastCheckedAt: now,
      devices,
    };

    const alertAfterMs = Number(
      this.config.get<string>('WA_DISCONNECT_ALERT_AFTER_MS') ?? DEFAULT_ALERT_AFTER_MS,
    );
    if (
      this.state.alertSentAt ||
      now.getTime() - disconnectedSince.getTime() < alertAfterMs ||
      !this.mailer.isEnabled() ||
      !this.mailer.isConfigured()
    ) {
      return;
    }

    try {
      await this.mailer.sendDisconnectAlert({ disconnectedSince, checkedAt: now, reason, devices });
      this.state.alertSentAt = now;
      this.logger.log('Email peringatan koneksi WA terputus berhasil dikirim');
    } catch (error) {
      this.logger.warn(
        `Email peringatan koneksi WA gagal; akan dicoba lagi: ${error instanceof Error ? error.name : 'unknown error'}`,
      );
    }
  }
}
