import { ConfigService } from '@nestjs/config';
import { WaConnectionMonitorService } from './wa-connection-monitor.service';
import type { WaGatewayHealth } from './wa-monitor.types';

const HEALTHY: WaGatewayHealth = {
  status: true,
  service: 'wa-gateway',
  degraded: false,
  devices: [
    {
      token: 'abc123…',
      name: 'Althea Klinik',
      phone: '6285700000000',
      status: 'connect',
      reconnectAttempts: 0,
      idleMs: 100,
    },
  ],
  ts: 1,
};

function response(payload: unknown, ok = true): Response {
  return { ok, json: jest.fn().mockResolvedValue(payload) } as unknown as Response;
}

function setup(alertAfterMs = 300_000) {
  const values: Record<string, string> = {
    FONNTE_API_URL: 'http://localhost:3204',
    WA_DISCONNECT_ALERT_AFTER_MS: String(alertAfterMs),
  };
  const config = {
    get: jest.fn((key: string) => values[key]),
  } as unknown as ConfigService;
  const mailer = {
    isEnabled: jest.fn().mockReturnValue(true),
    isConfigured: jest.fn().mockReturnValue(true),
    sendDisconnectAlert: jest.fn().mockResolvedValue(undefined),
  };
  const service = new WaConnectionMonitorService(config, mailer as any);
  return { service, mailer };
}

function mockHealth(payload: unknown, ok = true) {
  return jest.spyOn(global, 'fetch').mockResolvedValue(response(payload, ok));
}

describe('WaConnectionMonitorService', () => {
  afterEach(() => jest.restoreAllMocks());

  it('reports connected for a healthy gateway', async () => {
    const { service } = setup();
    mockHealth(HEALTHY);

    await service.checkConnection(new Date('2026-07-29T01:00:00Z'));

    expect(service.getPublicState().status).toBe('connected');
  });

  it('shows disconnected immediately but waits five minutes before email', async () => {
    const { service, mailer } = setup();
    mockHealth({
      ...HEALTHY,
      degraded: true,
      devices: [{ ...HEALTHY.devices[0], status: 'disconnect' }],
    });

    await service.checkConnection(new Date('2026-07-29T01:00:00Z'));
    await service.checkConnection(new Date('2026-07-29T01:04:59Z'));

    expect(service.getPublicState()).toMatchObject({
      status: 'disconnected',
      reason: 'device_disconnected',
      disconnectedSince: '2026-07-29T01:00:00.000Z',
    });
    expect(mailer.sendDisconnectAlert).not.toHaveBeenCalled();
  });

  it('sends exactly one email after five continuous minutes', async () => {
    const { service, mailer } = setup();
    mockHealth({
      ...HEALTHY,
      degraded: true,
      devices: [{ ...HEALTHY.devices[0], status: 'connecting' }],
    });

    await service.checkConnection(new Date('2026-07-29T01:00:00Z'));
    await service.checkConnection(new Date('2026-07-29T01:05:00Z'));
    await service.checkConnection(new Date('2026-07-29T01:06:00Z'));

    expect(mailer.sendDisconnectAlert).toHaveBeenCalledTimes(1);
    expect(mailer.sendDisconnectAlert).toHaveBeenCalledWith(
      expect.objectContaining({ reason: 'device_connecting' }),
    );
  });

  it('retries email after failure and resets after reconnect', async () => {
    const { service, mailer } = setup();
    mockHealth({
      ...HEALTHY,
      degraded: true,
      devices: [{ ...HEALTHY.devices[0], status: 'disconnect' }],
    });
    mailer.sendDisconnectAlert.mockRejectedValueOnce(new Error('SMTP down'));

    await service.checkConnection(new Date('2026-07-29T01:00:00Z'));
    await service.checkConnection(new Date('2026-07-29T01:05:00Z'));
    await service.checkConnection(new Date('2026-07-29T01:06:00Z'));
    expect(mailer.sendDisconnectAlert).toHaveBeenCalledTimes(2);

    mockHealth(HEALTHY);
    await service.checkConnection(new Date('2026-07-29T01:07:00Z'));
    expect(service.getPublicState().status).toBe('connected');
  });

  it.each([
    [{ ...HEALTHY, devices: [] }, 'no_devices'],
    [{ invalid: true }, 'invalid_health_response'],
  ])('treats invalid health condition as disconnected', async (payload, reason) => {
    const { service } = setup();
    mockHealth(payload);

    await service.checkConnection(new Date('2026-07-29T01:00:00Z'));

    expect(service.getPublicState()).toMatchObject({ status: 'disconnected', reason });
  });

  it('treats an unreachable gateway as disconnected', async () => {
    const { service } = setup();
    jest.spyOn(global, 'fetch').mockRejectedValue(new Error('ECONNREFUSED'));

    await service.checkConnection(new Date('2026-07-29T01:00:00Z'));

    expect(service.getPublicState()).toMatchObject({
      status: 'disconnected',
      reason: 'gateway_unreachable',
    });
  });

  it('ignores an overlapping check', async () => {
    const { service } = setup();
    let release!: (value: Response) => void;
    jest.spyOn(global, 'fetch').mockReturnValue(
      new Promise<Response>((resolve) => {
        release = resolve;
      }),
    );

    const first = service.checkConnection(new Date('2026-07-29T01:00:00Z'));
    await service.checkConnection(new Date('2026-07-29T01:01:00Z'));
    expect(global.fetch).toHaveBeenCalledTimes(1);
    release(response(HEALTHY));
    await first;
  });
});
