import { Controller, Get, UseGuards } from '@nestjs/common';
import { SkipThrottle } from '@nestjs/throttler';
import { ApiBearerAuth, ApiOperation, ApiTags } from '../common/swagger';
import { Roles } from '../auth/decorators/roles.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { WaConnectionMonitorService } from './wa-connection-monitor.service';

@ApiTags('Clinic — WhatsApp Monitor')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('clinic/wa')
export class ClinicWaMonitorController {
  constructor(private readonly monitor: WaConnectionMonitorService) {}

  @Get('connection-health')
  @Roles('clinic-admin', 'clinic-resepsionis')
  @SkipThrottle()
  @ApiOperation({ summary: 'Status koneksi WA terpantau untuk banner operasional' })
  getConnectionHealth() {
    return this.monitor.getPublicState();
  }
}
