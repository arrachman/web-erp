export type WaDeviceConnectionStatus = 'connecting' | 'connect' | 'disconnect';

export interface WaGatewayHealthDevice {
  token: string;
  name: string;
  phone?: string;
  status: WaDeviceConnectionStatus;
  reconnectAttempts: number;
  idleMs: number;
}

export interface WaGatewayHealth {
  status: boolean;
  service: string;
  degraded: boolean;
  devices: WaGatewayHealthDevice[];
  ts: number;
}

export type WaMonitorStatus = 'unknown' | 'connected' | 'disconnected';

export type WaMonitorReason =
  | 'connected'
  | 'device_connecting'
  | 'device_disconnected'
  | 'no_devices'
  | 'gateway_unreachable'
  | 'invalid_health_response';

export interface WaSafeDeviceSummary {
  name: string;
  phone?: string;
  status: WaDeviceConnectionStatus;
}

export interface WaMonitorState {
  status: WaMonitorStatus;
  reason: WaMonitorReason | null;
  disconnectedSince: Date | null;
  lastCheckedAt: Date | null;
  lastConnectedAt: Date | null;
  alertSentAt: Date | null;
  devices: WaSafeDeviceSummary[];
}

export interface WaConnectionHealthResponse {
  status: WaMonitorStatus;
  reason: WaMonitorReason | null;
  disconnectedSince: string | null;
  lastCheckedAt: string | null;
  devices: WaSafeDeviceSummary[];
}

export interface WaDisconnectAlertInput {
  disconnectedSince: Date;
  checkedAt: Date;
  reason: WaMonitorReason;
  devices: WaSafeDeviceSummary[];
}
