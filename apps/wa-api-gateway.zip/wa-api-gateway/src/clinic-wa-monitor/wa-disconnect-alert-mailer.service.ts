import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import nodemailer, { type Transporter } from 'nodemailer';
import type { WaDisconnectAlertInput, WaMonitorReason } from './wa-monitor.types';

const REASON_LABEL: Record<WaMonitorReason, string> = {
  connected: 'Tersambung',
  device_connecting: 'Perangkat terus mencoba menyambung',
  device_disconnected: 'Perangkat terputus',
  no_devices: 'Tidak ada perangkat terdaftar',
  gateway_unreachable: 'Layanan WhatsApp gateway tidak dapat dijangkau',
  invalid_health_response: 'Respons status WhatsApp tidak valid',
};

function parseBoolean(value: string | undefined, fallback: boolean): boolean {
  if (value === undefined || value.trim() === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(value.toLowerCase());
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>'"]/g, (char) => {
    const entities: Record<string, string> = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;',
    };
    return entities[char] ?? char;
  });
}

@Injectable()
export class WaDisconnectAlertMailerService {
  private readonly logger = new Logger(WaDisconnectAlertMailerService.name);
  private transporter?: Transporter;

  constructor(private readonly config: ConfigService) {}

  isEnabled(): boolean {
    return parseBoolean(this.config.get<string>('WA_DISCONNECT_ALERT_ENABLED'), true);
  }

  isConfigured(): boolean {
    return Boolean(
      this.config.get<string>('SMTP_HOST') &&
      this.config.get<string>('SMTP_USER') &&
      this.config.get<string>('SMTP_PASS') &&
      this.config.get<string>('SMTP_FROM') &&
      this.config.get<string>('WA_DISCONNECT_ALERT_TO'),
    );
  }

  async sendDisconnectAlert(input: WaDisconnectAlertInput): Promise<void> {
    if (!this.isEnabled()) return;
    if (!this.isConfigured()) {
      this.logger.warn('Alert email WA nonaktif: konfigurasi SMTP/recipient belum lengkap');
      return;
    }

    const recipient = this.config.getOrThrow<string>('WA_DISCONNECT_ALERT_TO');
    const from = this.config.getOrThrow<string>('SMTP_FROM');
    const elapsedMinutes = Math.max(
      1,
      Math.floor((input.checkedAt.getTime() - input.disconnectedSince.getTime()) / 60_000),
    );
    const reason = REASON_LABEL[input.reason];
    const devices = input.devices.length
      ? input.devices
          .map(
            (device) =>
              `${device.name}${device.phone ? ` (${device.phone})` : ''}: ${device.status}`,
          )
          .join('\n')
      : 'Tidak ada perangkat yang terdeteksi.';
    const adminUrl = `${this.config.get<string>('WEB_ALTHEA_URL') ?? 'https://admin.altheapsychology.co.id'}/admin/notif-wa`;

    const text = [
      'Koneksi WhatsApp Althea terputus.',
      '',
      `Mulai terdeteksi: ${input.disconnectedSince.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB`,
      `Durasi: sekitar ${elapsedMinutes} menit`,
      `Kondisi: ${reason}`,
      `Pengecekan terakhir: ${input.checkedAt.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB`,
      '',
      'Perangkat:',
      devices,
      '',
      `Periksa dan sambungkan kembali perangkat: ${adminUrl}`,
    ].join('\n');

    await this.getTransporter().sendMail({
      from,
      to: recipient,
      subject: '[Althea] WhatsApp terputus lebih dari 5 menit',
      text,
      html: `<h2>Koneksi WhatsApp Althea terputus</h2>
<p><strong>Durasi:</strong> sekitar ${elapsedMinutes} menit<br>
<strong>Kondisi:</strong> ${escapeHtml(reason)}</p>
<pre>${escapeHtml(devices)}</pre>
<p><a href="${escapeHtml(adminUrl)}">Periksa koneksi WhatsApp</a></p>`,
    });
  }

  private getTransporter(): Transporter {
    if (this.transporter) return this.transporter;

    const port = Number(this.config.get<string>('SMTP_PORT') ?? '465');
    this.transporter = nodemailer.createTransport({
      host: this.config.getOrThrow<string>('SMTP_HOST'),
      port,
      secure: parseBoolean(this.config.get<string>('SMTP_SECURE'), port === 465),
      auth: {
        user: this.config.getOrThrow<string>('SMTP_USER'),
        pass: this.config.getOrThrow<string>('SMTP_PASS'),
      },
    });
    return this.transporter;
  }
}
