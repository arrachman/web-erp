import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ClinicSettingsService } from '../../clinic-settings/clinic-settings.service';
import { normalizePhoneId } from '../../common/utils/phone.util';
import {
  DeliveryStatus,
  SendMediaParams,
  SendMessageParams,
  SendResult,
  WAProvider,
} from '../wa.interface';
import { waEnv } from '../wa-env.util';

/**
 * SentiWA WhatsApp Gateway provider.
 *
 * Default endpoint: https://api.fonnte.com/send (Fonnte-compatible wire format —
 * override via SENTIWA_API_URL untuk arahkan ke gateway self-host).
 * Auth: header `Authorization: <TOKEN>`
 *
 * Token resolution (lihat ClinicSettingsService.getActiveDeviceToken):
 *   1. DB `clinic_settings.wa_active_device_token` (di-set via pairing flow)
 *   2. env SENTIWA_API_TOKEN (fallback legacy)
 *
 * Phone format: E.164 atau dengan country code (+62...). Gateway handle baik.
 *
 * See ADR 004 untuk strategi.
 */
@Injectable()
export class SentiWaProvider implements WAProvider {
  readonly name = 'sentiwa';
  private readonly logger = new Logger(SentiWaProvider.name);
  private readonly apiUrl: string;
  private readonly deviceId?: string;

  constructor(
    config: ConfigService,
    private readonly settings: ClinicSettingsService,
  ) {
    this.apiUrl = waEnv(config, 'API_URL') || 'https://api.fonnte.com';
    this.deviceId = waEnv(config, 'DEVICE_ID');
  }

  async send(params: SendMessageParams): Promise<SendResult> {
    const token = await this.settings.getActiveDeviceToken();
    if (!token) {
      this.logger.warn(
        'No active SentiWA device token (DB & env empty). Pair device via /admin/notif-wa atau set SENTIWA_API_TOKEN.',
      );
      return {
        messageId: `sentiwa_unconfigured_${Date.now()}`,
        status: 'failed',
        errorReason: 'No active SentiWA device token configured',
      };
    }

    const body = params.body || `[template:${params.templateId}]`;
    // Normalize phone — Indonesia shorthand stays `62xxx`, while explicit
    // foreign country codes stay E.164 (`+country...`). Webhook fallback handles
    // plus/no-plus variants for international senders.
    const targetPhone = normalizePhoneId(params.toPhone) ?? params.toPhone;
    const formData = new URLSearchParams();
    formData.set('target', targetPhone);
    formData.set('message', body);
    if (this.deviceId) formData.set('device', this.deviceId);
    if (params.callbackUrl) formData.set('webhook', params.callbackUrl);

    try {
      const response = await fetch(`${this.apiUrl}/send`, {
        method: 'POST',
        headers: {
          Authorization: token,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData.toString(),
      });

      const json = (await response.json()) as {
        status?: boolean;
        // Gateway kembalikan id sebagai number/string/array (per target).
        id?: number | string | Array<number | string>;
        reason?: string;
        detail?: string;
      };

      if (!response.ok || json.status === false) {
        return {
          messageId: `sentiwa_fail_${Date.now()}`,
          status: 'failed',
          errorReason: json.reason || json.detail || `HTTP ${response.status}`,
          providerResponse: json,
        };
      }

      // Normalisasi ke string — schema Prisma `messageId String?` reject number.
      const rawId = Array.isArray(json.id) ? json.id[0] : json.id;
      const messageId =
        rawId !== undefined && rawId !== null ? String(rawId) : `sentiwa_${Date.now()}`;
      return {
        messageId,
        status: 'sent',
        providerResponse: json,
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      this.logger.error(`SentiWA send failed: ${message}`);
      return {
        messageId: `sentiwa_error_${Date.now()}`,
        status: 'failed',
        errorReason: message,
      };
    }
  }

  async sendMedia(params: SendMediaParams): Promise<SendResult> {
    const token = await this.settings.getActiveDeviceToken();
    if (!token) {
      return {
        messageId: `sentiwa_unconfigured_${Date.now()}`,
        status: 'failed',
        errorReason: 'No active SentiWA device token configured',
      };
    }
    const targetPhone = normalizePhoneId(params.toPhone) ?? params.toPhone;
    const payload = {
      target: targetPhone,
      file: params.data.toString('base64'),
      filename: params.fileName,
      mimetype: params.mimetype || 'application/pdf',
      caption: params.caption || '',
    };
    try {
      const response = await fetch(`${this.apiUrl}/send-media`, {
        method: 'POST',
        headers: {
          Authorization: token,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });
      const json = (await response.json()) as {
        status?: boolean;
        id?: number | string | Array<number | string>;
        reason?: string;
        detail?: string;
      };
      if (!response.ok || json.status === false) {
        return {
          messageId: `sentiwa_fail_${Date.now()}`,
          status: 'failed',
          errorReason: json.reason || json.detail || `HTTP ${response.status}`,
          providerResponse: json,
        };
      }
      const rawId = Array.isArray(json.id) ? json.id[0] : json.id;
      const messageId =
        rawId !== undefined && rawId !== null ? String(rawId) : `sentiwa_${Date.now()}`;
      return { messageId, status: 'sent', providerResponse: json };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      this.logger.error(`SentiWA sendMedia failed: ${message}`);
      return { messageId: `sentiwa_error_${Date.now()}`, status: 'failed', errorReason: message };
    }
  }

  async getDeliveryStatus(_messageId: string): Promise<DeliveryStatus | null> {
    // Gateway tidak provide simple polling endpoint untuk status — pakai webhook.
    // Caller sebaiknya rely pada webhook callback untuk update status di clinic_wa_log.
    return null;
  }
}
