import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { BullModule } from '@nestjs/bullmq';
import { ClinicSettingsModule } from '../clinic-settings/clinic-settings.module';
import { PrismaModule } from '../prisma/prisma.module';
import { ClinicWaController } from './clinic-wa.controller';
import { ClinicWaService } from './clinic-wa.service';
import { WaResendService } from './wa-resend.service';
import { SentiWaProvider } from './providers/sentiwa.provider';
import { MockWAProvider } from './providers/mock.provider';
import { WA_PROVIDER } from './wa.tokens';
import { WA_QUEUE_NAME } from './queue/wa-queue.constants';
import { WaQueueProcessor } from './queue/wa-queue.processor';
import { waEnv } from './wa-env.util';

export { WA_PROVIDER };

function parseRedisUrl(url: string | undefined) {
  if (!url) return { host: 'localhost', port: 6379 };
  try {
    const u = new URL(url);
    return {
      host: u.hostname || 'localhost',
      port: Number(u.port || 6379),
      password: u.password || undefined,
      username: u.username || undefined,
    };
  } catch {
    return { host: 'localhost', port: 6379 };
  }
}

/**
 * WhatsApp gateway module.
 *
 * Provider switch:
 * - SENTIWA_API_TOKEN set → use SentiWaProvider (real WA gateway)
 * - else → use MockWAProvider (no-op, for dev/testing)
 *
 * Queue mode:
 * - WA_QUEUE_ENABLED=true → enqueue to BullMQ (Redis), worker retries 3× with 5min backoff
 * - else → sync send via dispatchRaw fallback
 *
 * Exports `ClinicWaService` untuk dipakai modul lain (e.g., booking event hooks).
 */
@Module({
  imports: [
    ConfigModule,
    PrismaModule,
    ClinicSettingsModule,
    BullModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (config: ConfigService) => ({
        connection: parseRedisUrl(config.get<string>('REDIS_URL')),
      }),
      inject: [ConfigService],
    }),
    BullModule.registerQueue({ name: WA_QUEUE_NAME }),
  ],
  controllers: [ClinicWaController],
  providers: [
    MockWAProvider,
    SentiWaProvider,
    {
      // Pilih SentiWaProvider bila ada salah satu token (env SENTIWA_API_TOKEN
      // sebagai fallback lama, atau SENTIWA_ACCOUNT_TOKEN supaya pairing flow
      // bisa di-aktifkan dari UI tanpa env API token). SentiWaProvider sendiri
      // baca token aktif dari DB via ClinicSettingsService (lihat sentiwa.provider.ts).
      provide: WA_PROVIDER,
      useFactory: (config: ConfigService, mock: MockWAProvider, sentiwa: SentiWaProvider) => {
        const apiToken = waEnv(config, 'API_TOKEN');
        const accountToken = waEnv(config, 'ACCOUNT_TOKEN');
        return apiToken || accountToken ? sentiwa : mock;
      },
      inject: [ConfigService, MockWAProvider, SentiWaProvider],
    },
    ClinicWaService,
    WaResendService,
    WaQueueProcessor,
  ],
  exports: [WA_PROVIDER, ClinicWaService, WaResendService],
})
export class ClinicWaModule {}
