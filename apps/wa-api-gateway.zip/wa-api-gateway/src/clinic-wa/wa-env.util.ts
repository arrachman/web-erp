import type { ConfigService } from '@nestjs/config';

/**
 * Baca env SentiWA dengan fallback ke nama lama `FONNTE_*`.
 *
 * Konteks: rebrand Fonnte → SentiWA (19 Jun 2026) mengganti semua env
 * `FONNTE_*` → `SENTIWA_*`. Tapi container api-gateway produksi tidak punya
 * file `.env` — secret hanya hidup di container yang berjalan, dan
 * `scripts/deploy-be.sh` meng-capture env dari container lama (masih `FONNTE_*`)
 * lalu meneruskannya ke container baru. Tanpa fallback ini, redeploy sebelum env
 * di-rename → semua key `SENTIWA_*` undefined → provider jatuh ke MockWAProvider
 * → WA berhenti kirim **secara senyap**.
 *
 * Hapus fallback ini setelah env container produksi benar-benar dimigrasi ke
 * `SENTIWA_*` (lihat memory althea-deploy-procedure).
 */
export function waEnv(config: ConfigService, key: string): string | undefined {
  return config.get<string>(`SENTIWA_${key}`) ?? config.get<string>(`FONNTE_${key}`);
}

/** Varian tanpa ConfigService (untuk konteks yang hanya punya `process.env`). */
export function waEnvRaw(key: string): string | undefined {
  return process.env[`SENTIWA_${key}`] ?? process.env[`FONNTE_${key}`];
}
