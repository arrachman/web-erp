import { Inject, Logger } from '@nestjs/common';
import { Processor, WorkerHost } from '@nestjs/bullmq';
import type { Job } from 'bullmq';
import { PrismaService } from '../../prisma/prisma.service';
import type { WAProvider } from '../wa.interface';
import { WA_PROVIDER } from '../wa.tokens';
import { waEnvRaw } from '../wa-env.util';
import {
  WA_JITTER,
  WA_JOB_SEND,
  WA_QUEUE_NAME,
  WA_THROTTLE,
  type WaSendJobData,
} from './wa-queue.constants';

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

@Processor(WA_QUEUE_NAME, {
  // Anti-ban: serial (concurrency 1) + plafon keras lewat limiter.
  concurrency: WA_THROTTLE.concurrency,
  limiter: { max: WA_THROTTLE.max, duration: WA_THROTTLE.durationMs },
})
export class WaQueueProcessor extends WorkerHost {
  private readonly logger = new Logger(WaQueueProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    @Inject(WA_PROVIDER) private readonly wa: WAProvider,
  ) {
    super();
  }

  /**
   * Jeda acak antar pesan (jitter) supaya interval kirim tidak seragam/robotik.
   * Karena worker concurrency = 1, sleep ini langsung jadi spasi antar job.
   */
  private async jitterDelay(): Promise<void> {
    const { minMs, maxMs } = WA_JITTER;
    if (maxMs <= 0 || maxMs < minMs) return;
    const ms = minMs + Math.floor(Math.random() * (maxMs - minMs + 1));
    this.logger.debug(`Jitter ${ms}ms sebelum job WA berikutnya`);
    await sleep(ms);
  }

  async process(job: Job<WaSendJobData>): Promise<{ messageId?: string; status: string }> {
    if (job.name !== WA_JOB_SEND) {
      throw new Error(`Unknown job name: ${job.name}`);
    }
    const { logId, recipientPhone, body, metadata } = job.data;
    const attempt = job.attemptsMade + 1;

    this.logger.log(
      `Processing WA job ${job.id} (logId=${logId}) attempt ${attempt}/${job.opts.attempts ?? 1}`,
    );

    const result = await this.wa.send({
      toPhone: recipientPhone,
      body,
      callbackUrl: waEnvRaw('WEBHOOK_URL'),
      metadata: { logId, attempt, ...metadata },
    });

    if (result.status === 'failed') {
      await this.prisma.clinicWaLog.update({
        where: { id: logId },
        data: {
          retryCount: attempt,
          status: attempt >= (job.opts.attempts ?? 1) ? 'gagal' : 'queued',
          errorReason: result.errorReason ?? null,
          failedAt: attempt >= (job.opts.attempts ?? 1) ? new Date() : null,
        },
      });
      throw new Error(result.errorReason ?? 'WA provider failed');
    }

    const status = result.status === 'sent' ? 'terkirim' : 'queued';
    await this.prisma.clinicWaLog.update({
      where: { id: logId },
      data: {
        messageId: result.messageId,
        status,
        retryCount: attempt,
        sentAt: result.status === 'sent' ? new Date() : null,
        errorReason: null,
      },
    });

    // Spasi acak sebelum job berikutnya (anti-ban). Hanya setelah kirim sukses;
    // kegagalan sudah punya backoff retry 5 menit sendiri.
    await this.jitterDelay();

    return { messageId: result.messageId, status };
  }
}
