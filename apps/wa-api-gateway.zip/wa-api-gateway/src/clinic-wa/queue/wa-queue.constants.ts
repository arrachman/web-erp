export const WA_QUEUE_NAME = 'clinic-wa';

export const WA_JOB_SEND = 'send-message';

export type WaSendJobData = {
  logId: number;
  recipientPhone: string;
  body: string;
  metadata: Record<string, unknown>;
};

export const WA_JOB_DEFAULTS = {
  attempts: 3,
  backoff: { type: 'fixed' as const, delay: 5 * 60 * 1000 },
  removeOnComplete: { age: 7 * 24 * 3600, count: 1000 },
  removeOnFail: { age: 30 * 24 * 3600 },
};

/**
 * Anti-ban: throttle (plafon keras) + jitter (spasi acak) untuk kirim WA.
 * Baileys = protokol WA Web tidak resmi → hindari pola burst/robotik.
 *
 * - throttle: BullMQ limiter, maksimal `max` job per `durationMs` (jaring
 *   pengaman saat fan-out besar mis. reminder massal).
 * - concurrency: tetap 1 → pesan diproses serial, urutan terjaga.
 * - jitter: sleep acak `minMs..maxMs` setelah tiap kirim sukses → interval
 *   antar pesan tidak seragam (mirip manusia). Set min=max=0 untuk nonaktif.
 *
 * Semua nilai dari env supaya bisa ditune tanpa rebuild.
 */
export const WA_THROTTLE = {
  max: Number(process.env.WA_THROTTLE_MAX ?? 20),
  durationMs: Number(process.env.WA_THROTTLE_WINDOW_MS ?? 60_000),
  concurrency: Number(process.env.WA_WORKER_CONCURRENCY ?? 1),
};

export const WA_JITTER = {
  minMs: Number(process.env.WA_JITTER_MIN_MS ?? 4_000),
  maxMs: Number(process.env.WA_JITTER_MAX_MS ?? 10_000),
};
