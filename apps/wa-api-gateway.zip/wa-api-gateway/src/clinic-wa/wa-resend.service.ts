import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { Prisma, type ClinicWaLog } from '@prisma/client';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { PrismaService } from '../prisma/prisma.service';
import {
  WA_JOB_DEFAULTS,
  WA_JOB_SEND,
  WA_QUEUE_NAME,
  type WaSendJobData,
} from './queue/wa-queue.constants';

/** Status log yang boleh di-resend — hanya yang benar-benar tidak sampai. */
const RESENDABLE_STATUS = ['gagal', 'queued'];

/**
 * Resend WA log yang gagal terkirim (mis. saat device WA sempat disconnect,
 * sehingga seluruh batch reminder pagi jatuh ke status `gagal`).
 *
 * Desain:
 * - Body dipakai **verbatim** dari log lama (`clinic_wa_log.body` menyimpan
 *   pesan yang sudah ter-render penuh), jadi resend tidak perlu template dan
 *   tetap bekerja untuk log free-text yang `templateId`-nya null.
 * - Selalu membuat **baris log baru**, tidak menimpa yang lama. Alasannya dua:
 *   riwayat kegagalan harus tetap terlihat untuk audit, dan `jobId` BullMQ
 *   (`wa-log-<id>`) masih tersimpan di Redis sampai 30 hari — re-enqueue dengan
 *   id lama akan di-dedupe diam-diam dan pesan tidak pernah terkirim.
 * - Relasi ke log asal disimpan di `metadata.resendOfLogId` supaya rantai
 *   percobaan bisa ditelusuri dari UI/query.
 *
 * Sengaja **bypass** master kill-switch `waSendEnabled`: ini aksi manual admin,
 * sama seperti sendTest dan invoice "Kirim via WA".
 */
@Injectable()
export class WaResendService {
  private readonly logger = new Logger(WaResendService.name);

  constructor(
    private readonly prisma: PrismaService,
    @InjectQueue(WA_QUEUE_NAME) private readonly waQueue: Queue<WaSendJobData>,
  ) {}

  /** Resend satu log. Melempar bila log tidak ada / statusnya sudah terkirim. */
  async resendOne(logId: number, actorId?: number) {
    const src = await this.prisma.clinicWaLog.findUnique({ where: { id: logId } });
    if (!src) throw new NotFoundException(`WA log ${logId} tidak ditemukan`);
    if (!RESENDABLE_STATUS.includes(src.status)) {
      throw new BadRequestException(
        `WA log ${logId} berstatus '${src.status}' — hanya ${RESENDABLE_STATUS.join('/')} yang bisa dikirim ulang`,
      );
    }
    return this.enqueueCopy(src, actorId);
  }

  /**
   * Resend banyak log sekaligus. Log yang tidak memenuhi syarat dilewati dan
   * dilaporkan di `skipped`, bukan membatalkan seluruh batch.
   */
  async resendMany(logIds: number[], actorId?: number) {
    const rows = await this.prisma.clinicWaLog.findMany({ where: { id: { in: logIds } } });
    const found = new Map(rows.map((r) => [r.id, r]));

    const resent: Array<{ sourceLogId: number; newLogId: number }> = [];
    const skipped: Array<{ logId: number; reason: string }> = [];

    for (const id of logIds) {
      const src = found.get(id);
      if (!src) {
        skipped.push({ logId: id, reason: 'tidak ditemukan' });
        continue;
      }
      if (!RESENDABLE_STATUS.includes(src.status)) {
        skipped.push({ logId: id, reason: `status '${src.status}'` });
        continue;
      }
      try {
        const out = await this.enqueueCopy(src, actorId);
        resent.push({ sourceLogId: id, newLogId: out.data.logId });
      } catch (e) {
        skipped.push({ logId: id, reason: (e as Error).message });
      }
    }

    return {
      success: true,
      data: { resent, skipped },
      message: `${resent.length} pesan di-antrikan ulang, ${skipped.length} dilewati`,
    };
  }

  /** Buat log baru dari log lama lalu enqueue ke BullMQ. */
  private async enqueueCopy(src: ClinicWaLog, actorId?: number) {
    const srcMeta = (src.metadata ?? {}) as Record<string, unknown>;
    // reminderFlag sengaja dibawa: scheduler memakainya untuk dedupe, jadi
    // menyalinnya mencegah cron mengirim reminder ketiga untuk booking yang sama.
    const metadata: Record<string, unknown> = {
      ...srcMeta,
      resendOfLogId: src.id,
      resendAttempt: Number(srcMeta.resendAttempt ?? 0) + 1,
      resendBy: actorId ?? null,
    };

    const log = await this.prisma.clinicWaLog.create({
      data: {
        templateId: src.templateId,
        recipientType: src.recipientType,
        recipientPhone: src.recipientPhone,
        // verbatim — pesan sudah ter-render saat percobaan pertama.
        body: src.body,
        bookingId: src.bookingId,
        metadata: metadata as Prisma.InputJsonValue,
        status: 'queued',
        createdBy: actorId ?? null,
      },
    });

    await this.waQueue.add(
      WA_JOB_SEND,
      {
        logId: log.id,
        recipientPhone: log.recipientPhone,
        body: log.body,
        metadata,
      },
      { ...WA_JOB_DEFAULTS, jobId: `wa-log-${log.id}` },
    );

    this.logger.log(`Resend WA log ${src.id} → log baru ${log.id} (${log.recipientPhone})`);

    return {
      success: true,
      data: { logId: log.id, sourceLogId: src.id, status: 'queued' },
      message: 'Enqueued for resend',
    };
  }
}
